-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: ses_gold
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ses_gold`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ses_gold` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ses_gold`;

--
-- Table structure for table `agent_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `agent_cat` varchar(100) DEFAULT NULL,
  `time_stamp` varchar(50) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_category`
--

INSERT INTO `agent_category` (`ID`, `agent_cat`, `time_stamp`, `user_id`) VALUES (2,'A','04/06/2010 3:28:51 PM','b'),(3,'AA','04/06/2010 4:01:12 PM','b'),(4,'AAA','11/15/2010 15:32:28','sandip'),(5,'Midum','11/15/2010 15:34:34','sandip'),(6,'Special',NULL,NULL);

--
-- Table structure for table `agent_cust`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_cust` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(50) DEFAULT NULL,
  `agent_id` varchar(50) DEFAULT NULL,
  `sdf` int(11) DEFAULT 0,
  `sdu` int(11) DEFAULT 0,
  `status` int(11) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_cust`
--


--
-- Table structure for table `agent_customer_relation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_customer_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `agent_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `agent_customer_relation_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE,
  CONSTRAINT `agent_customer_relation_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_customer_relation`
--


--
-- Table structure for table `agent_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_master` (
  `agent_id` varchar(50) NOT NULL,
  `agent_name` varchar(100) DEFAULT NULL,
  `short_name` varchar(50) DEFAULT NULL,
  `agent_category_id` int(11) DEFAULT NULL,
  `agent_address` varchar(255) DEFAULT NULL,
  `agent_phone` varchar(25) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `inforce` tinyint(4) DEFAULT 1,
  `max_gold_limit` double DEFAULT 50,
  `show_in_commission` int(11) DEFAULT 1,
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_master`
--

INSERT INTO `agent_master` (`agent_id`, `agent_name`, `short_name`, `agent_category_id`, `agent_address`, `agent_phone`, `time_stamp`, `user_id`, `inforce`, `max_gold_limit`, `show_in_commission`) VALUES ('AG2004','Sidharta Dhara','SIDH',2,'Barrackpore','9088666222','2015-06-13 00:00:00','sanjoy',1,125,1),('AG2006','Mr.Arabinda Karmakar ','ARKA',2,'East Chandmari','9088555333','2010-11-15 15:36:17','sandip',1,300,1),('AG2010','Samiran Majumdar','SAMA',2,'BKP','9088444999','2014-12-13 00:00:00','sanjoy',1,250,1),('AG2014','Suman Ghosh','SUGH',2,'bkp','9088222666','2014-12-13 00:00:00','sanjoy',1,200,1),('AG2016','Anupam Rakshit','ANRA',2,'Bkp','0000000000','2015-05-12 00:00:00','debasish',1,150,1),('AG2018','Counter Agent','CA',2,'Barrackpore','033 2535 7777',NULL,'raja',1,50,0),('AG2020','Arindam Biswas','ARBI',2,'bkp','9088555999','2015-08-13 00:00:00','sanjoy',1,150,1),('AG2022','Vivekananda Ghosh','VIGH',2,'bkp','9088666888','2016-06-29 00:00:00','sanjoy',1,550,0),('AG2023','Surojit Dhara','SUDH',2,'bkp','9088444666','2017-05-09 00:00:00','sanjoy',1,250,1),('AG2024','Subham Kundu','SUKU',2,'bkp','0000000000','2019-07-30 00:00:00','sanjoy',1,125,1),('AG2025','Anup Paul','ANPA',2,'bkp','0000000000','2019-07-30 00:00:00','sanjoy',1,0,0),('AG2026','Arindam Ghosh','ARGH',2,'bkp','8697888515','2022-02-07 00:00:00','Arindam',1,500,1);

--
-- Table structure for table `agent_salaries`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` varchar(50) DEFAULT NULL,
  `year_number` int(11) DEFAULT NULL,
  `month_number` int(11) DEFAULT NULL,
  `salary` int(11) DEFAULT 0,
  `ta` int(11) DEFAULT 0,
  `commission` int(11) DEFAULT 0,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_id` (`agent_id`,`year_number`,`month_number`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_salaries`
--

INSERT INTO `agent_salaries` (`id`, `agent_id`, `year_number`, `month_number`, `salary`, `ta`, `commission`, `inforce`, `created_at`, `updated_at`) VALUES (46,'AG2004',2022,6,0,0,6480,1,NULL,NULL),(47,'AG2006',2022,6,0,0,28800,1,NULL,NULL),(48,'AG2010',2022,6,0,0,32010,1,NULL,NULL),(49,'AG2014',2022,6,0,0,26715,1,NULL,NULL),(50,'AG2016',2022,6,0,0,24360,1,NULL,NULL),(51,'AG2020',2022,6,0,0,16770,1,NULL,NULL),(52,'AG2023',2022,6,0,0,26715,1,NULL,NULL),(53,'AG2024',2022,6,0,0,9990,1,NULL,NULL),(54,'AG2004',2022,8,0,0,8910,1,NULL,NULL),(55,'AG2006',2022,8,0,0,27870,1,NULL,NULL),(56,'AG2010',2022,8,0,0,24165,1,NULL,NULL),(57,'AG2014',2022,8,0,0,17730,1,NULL,NULL),(58,'AG2016',2022,8,0,0,8910,1,NULL,NULL),(59,'AG2020',2022,8,0,0,8370,1,NULL,NULL),(60,'AG2023',2022,8,0,0,21750,1,NULL,NULL),(61,'AG2024',2022,8,0,0,4860,1,NULL,NULL),(62,'AG2004',2022,5,0,0,1620,1,NULL,NULL),(63,'AG2006',2022,5,0,0,32670,1,NULL,NULL),(64,'AG2010',2022,5,0,0,21960,1,NULL,NULL),(65,'AG2014',2022,5,0,0,32880,1,NULL,NULL),(66,'AG2016',2022,5,0,0,13230,1,NULL,NULL),(67,'AG2020',2022,5,0,0,18675,1,NULL,NULL),(68,'AG2023',2022,5,0,0,8100,1,NULL,NULL),(69,'AG2024',2022,5,0,0,9180,1,NULL,NULL),(70,'AG2004',2022,10,0,0,8640,1,NULL,NULL),(71,'AG2006',2022,10,0,0,34650,1,NULL,NULL),(72,'AG2010',2022,10,0,0,6480,1,NULL,NULL),(73,'AG2014',2022,10,0,0,22995,1,NULL,NULL),(74,'AG2016',2022,10,0,0,10260,1,NULL,NULL),(75,'AG2020',2022,10,0,0,11070,1,NULL,NULL),(76,'AG2023',2022,10,0,0,41625,1,NULL,NULL),(77,'AG2024',2022,10,0,0,12150,1,NULL,NULL),(86,'AG2004',2022,11,0,0,8910,1,NULL,NULL),(87,'AG2006',2022,11,0,0,35910,1,NULL,NULL),(88,'AG2010',2022,11,0,0,15540,1,NULL,NULL),(89,'AG2014',2022,11,0,0,17730,1,NULL,NULL),(90,'AG2016',2022,11,0,0,19350,1,NULL,NULL),(91,'AG2020',2022,11,0,0,5130,1,NULL,NULL),(92,'AG2023',2022,11,0,0,27210,1,NULL,NULL),(93,'AG2024',2022,11,0,0,540,1,NULL,NULL),(94,'AG2026',2022,11,0,0,1620,1,NULL,NULL);

--
-- Table structure for table `agent_salary_withdrawals`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_salary_withdrawals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `year_number` int(11) NOT NULL,
  `month_number` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_salary_withdrawl_ibfk_1` (`agent_id`),
  CONSTRAINT `agent_salary_withdrawl_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_salary_withdrawals`
--

INSERT INTO `agent_salary_withdrawals` (`id`, `agent_id`, `year_number`, `month_number`, `amount`, `created_at`, `updated_at`) VALUES (3,'AG2004',2022,6,6480,'2022-07-01 08:13:57','2022-07-01 08:13:57'),(4,'AG2020',2022,6,16770,'2022-07-01 08:14:16','2022-07-01 08:14:16'),(5,'AG2016',2022,6,24360,'2022-07-01 08:14:31','2022-07-01 08:14:31'),(6,'AG2014',2022,6,26715,'2022-07-01 08:14:43','2022-07-01 08:14:43'),(7,'AG2010',2022,6,32010,'2022-07-01 08:14:57','2022-07-01 08:14:57'),(8,'AG2006',2022,6,28800,'2022-07-01 08:15:09','2022-07-01 08:15:09'),(9,'AG2024',2022,6,9990,'2022-07-01 08:15:21','2022-07-01 08:15:21'),(10,'AG2023',2022,6,26715,'2022-07-01 08:15:43','2022-07-01 08:15:43'),(11,NULL,2022,6,100,'2022-07-07 04:57:41','2022-07-07 04:57:41'),(12,NULL,2022,7,100,'2022-08-02 07:55:28','2022-08-02 07:55:28'),(13,NULL,2022,7,100,'2022-08-02 07:55:31','2022-08-02 07:55:31'),(14,'AG2004',2022,8,8910,'2022-09-01 13:05:10','2022-09-01 13:05:10'),(15,'AG2006',2022,8,27870,'2022-09-01 13:05:18','2022-09-01 13:05:18'),(16,'AG2010',2022,8,24165,'2022-09-01 13:05:24','2022-09-01 13:05:24'),(17,'AG2014',2022,8,17730,'2022-09-01 13:05:33','2022-09-01 13:05:33'),(18,'AG2016',2022,8,8910,'2022-09-01 13:05:39','2022-09-01 13:05:39'),(19,'AG2020',2022,8,8370,'2022-09-01 13:05:49','2022-09-01 13:05:49'),(20,'AG2023',2022,8,21750,'2022-09-01 13:05:58','2022-09-01 13:05:58'),(21,'AG2024',2022,8,4860,'2022-09-01 13:06:03','2022-09-01 13:06:03');

--
-- Table structure for table `agent_to_customer`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `agent_to_customer` (
  `cust_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `agent_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `tr_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  UNIQUE KEY `cust_id_2` (`cust_id`),
  KEY `cust_id` (`cust_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `agent_to_customer_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`),
  CONSTRAINT `agent_to_customer_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_to_customer`
--

INSERT INTO `agent_to_customer` (`cust_id`, `agent_id`, `tr_time`) VALUES ('S121','AG2010','2017-03-24 06:04:09'),('S68','AG2023','2017-07-04 12:08:48'),('S77','AG2023','2017-07-05 11:14:08'),('s18','AG2006','2017-03-24 06:09:17'),('S65','AG2010','2017-03-24 06:07:13'),('S66','AG2010','2017-03-24 06:07:20'),('s4','AG2006','2017-03-24 06:07:59'),('s5','AG2006','2017-03-24 06:08:06'),('s6','AG2006','2017-03-24 06:08:11'),('s7','AG2006','2017-03-24 06:08:16'),('s8','AG2006','2017-03-24 06:08:22'),('s9','AG2006','2017-03-24 06:08:28'),('s10','AG2006','2017-03-24 06:08:33'),('s11','AG2006','2017-03-24 06:08:39'),('s12','AG2022','2017-11-18 13:51:19'),('s13','AG2006','2017-03-24 06:08:50'),('s14','AG2006','2017-03-24 06:08:57'),('S15','AG2023','2017-07-04 12:05:39'),('s16','AG2016','2020-10-13 05:46:21'),('s17','AG2006','2017-03-24 06:09:12'),('S19','AG2023','2017-07-04 12:05:51'),('S20','AG2023','2017-07-04 12:05:24'),('S21','AG2023','2017-07-04 12:04:58'),('S22','AG2023','2017-07-04 12:06:25'),('S23','AG2023','2017-07-04 12:05:58'),('S24','AG2023','2017-07-04 12:05:32'),('S25','AG2023','2017-07-04 12:05:08'),('S26','AG2023','2017-07-04 12:06:36'),('S27','AG2014','2021-03-01 04:23:25'),('S28','AG2014','2021-03-02 14:37:06'),('s29','AG2014','2021-03-01 07:48:33'),('s30','AG2020','2017-03-24 06:10:21'),('s116','AG2010','2017-03-27 06:56:24'),('S177','AG2024','2020-11-10 13:54:13'),('s44','AG2020','2017-03-24 13:00:36'),('s45','AG2020','2017-03-24 13:00:41'),('s128','AG2014','2017-03-24 13:25:17'),('S173','AG2004','2017-07-04 12:23:42'),('s92','AG2010','2017-03-24 13:41:59'),('s99','AG2010','2017-03-24 13:42:13'),('S175','AG2004','2017-07-04 12:24:07'),('s78','AG2010','2017-03-25 03:53:40'),('s79','AG2010','2017-03-25 03:53:46'),('s106','AG2010','2017-03-25 03:58:19'),('s107','AG2010','2017-03-25 03:58:23'),('s143','AG2014','2017-03-25 03:59:09'),('s149','AG2014','2017-03-25 03:59:17'),('s86','AG2010','2017-03-25 04:03:38'),('S49','AG2020','2017-03-25 12:32:23'),('s52','AG2020','2017-03-25 12:34:24'),('s53','AG2020','2017-03-25 12:34:28'),('s50','AG2020','2017-03-25 12:40:19'),('S178','AG2004','2017-07-04 12:24:57'),('S179','AG2023','2017-07-25 12:45:59'),('s182','AG2010','2017-11-13 09:27:06'),('s183','AG2010','2017-11-13 09:27:13'),('s88','AG2016','2020-10-20 07:57:44'),('s89','AG2010','2017-03-27 03:52:30'),('s90','AG2006','2020-10-15 04:50:02'),('s91','AG2010','2017-03-27 03:52:39'),('s130','AG2014','2017-03-27 04:22:00'),('s131','AG2014','2017-03-27 04:22:05'),('s132','AG2014','2017-03-27 04:22:10'),('s133','AG2014','2017-03-27 04:22:14'),('s135','AG2014','2017-03-27 05:06:42'),('s136','AG2014','2017-03-27 05:06:47'),('s137','AG2014','2017-03-27 05:06:51'),('s138','AG2014','2017-03-27 05:06:56'),('s139','AG2014','2017-03-27 05:07:00'),('s140','AG2014','2017-03-27 05:07:06'),('s141','AG2014','2017-03-27 06:10:25'),('s142','AG2014','2017-03-27 06:10:30'),('S144','AG2010','2017-08-31 04:05:18'),('s145','AG2014','2017-03-27 06:11:28'),('s146','AG2016','2020-10-15 05:23:47'),('s147','AG2016','2020-10-18 05:19:28'),('s148','AG2014','2017-03-27 06:11:54'),('s150','AG2014','2017-03-27 06:12:05'),('s151','AG2004','2017-03-27 06:12:49'),('s152','AG2004','2017-03-27 06:12:54'),('s153','AG2004','2017-03-27 06:12:59'),('s154','AG2004','2017-03-27 06:13:04'),('S155','AG2004','2019-09-30 14:54:33'),('S156','AG2023','2017-07-12 05:38:30'),('s157','AG2006','2019-06-04 14:14:05'),('S158','AG2023','2017-07-14 04:54:01'),('S159','AG2023','2017-07-04 12:11:46'),('s160','AG2024','2020-09-01 11:58:34'),('S161','AG2023','2017-07-04 12:11:53'),('S162','AG2023','2017-07-14 04:53:21'),('S163','AG2023','2017-07-04 12:12:19'),('S164','AG2004','2018-03-09 14:29:32'),('S165','AG2004','2017-07-04 12:22:16'),('S166','AG2004','2017-07-04 12:22:41'),('S167','AG2004','2017-07-04 12:22:35'),('s168','AG2014','2017-11-13 09:27:34'),('S169','AG2004','2017-07-04 12:23:10'),('S170','AG2004','2017-07-04 12:23:15'),('S171','AG2004','2017-07-04 12:23:28'),('S172','AG2010','2018-10-09 04:04:39'),('S174','AG2004','2017-07-04 12:24:00'),('S176','AG2004','2017-07-04 12:23:48'),('S67','AG2023','2017-07-04 12:08:41'),('S69','AG2023','2017-07-04 12:09:55'),('S70','AG2023','2017-07-04 12:09:02'),('S71','AG2023','2017-07-04 12:08:55'),('s72','AG2010','2017-03-27 06:18:00'),('S73','AG2016','2020-08-10 04:31:30'),('S74','AG2006','2020-07-06 11:34:18'),('s75','AG2010','2017-03-27 06:19:05'),('s76','AG2010','2017-03-27 06:19:10'),('S94','AG2020','2017-05-05 14:20:03'),('S194','AG2024','2020-09-29 11:17:02'),('S197','AG2024','2020-12-01 04:26:32'),('s198','AG2022','2017-11-18 14:00:04'),('S199','AG2023','2017-07-14 04:55:42'),('s200','AG2004','2018-03-26 06:08:34'),('S201','AG2024','2020-10-09 05:14:27'),('s202','AG2006','2017-03-27 06:21:23'),('s203','AG2014','2017-03-27 06:21:35'),('s204','AG2014','2022-07-08 08:54:43'),('s205','AG2016','2020-10-09 08:10:31'),('s122','AG2014','2017-03-27 06:22:26'),('s123','AG2014','2017-03-27 06:22:31'),('S124','AG2016','2020-09-01 04:09:58'),('s125','AG2014','2017-03-27 06:22:41'),('s126','AG2022','2017-11-18 14:01:00'),('s127','AG2014','2018-08-04 13:43:52'),('S129','AG2006','2020-08-22 04:59:23'),('s134','AG2014','2017-03-27 06:23:27'),('s184','AG2014','2017-03-27 06:24:26'),('S57','AG2004','2022-12-02 11:09:30'),('s185','AG2004','2022-07-08 08:54:32'),('s186','AG2023','2020-07-01 04:56:38'),('S31','AG2022','2020-11-24 07:53:02'),('s188','AG2022','2017-11-18 13:58:34'),('S189','AG2004','2017-07-04 12:22:48'),('s2','AG2006','2017-03-27 06:29:41'),('s190','AG2022','2017-03-27 06:30:03'),('S191','AG2016','2020-09-29 11:21:50'),('S192','AG2024','2020-12-12 04:08:54'),('s32','AG2020','2017-03-27 06:30:40'),('s33','AG2020','2017-03-27 06:30:44'),('s35','AG2020','2017-03-27 06:30:54'),('s36','AG2020','2017-03-27 06:30:58'),('s37','AG2020','2017-03-27 06:31:03'),('s38','AG2020','2017-03-27 06:31:23'),('s39','AG2020','2017-03-27 06:31:31'),('s193','AG2020','2017-03-27 06:32:11'),('s195','AG2016','2020-08-06 10:56:39'),('s196','AG2022','2017-11-18 13:52:54'),('s112','AG2010','2017-03-27 06:33:07'),('s80','AG2010','2017-03-27 06:33:45'),('s81','AG2010','2017-03-27 06:34:05'),('S82','AG2010','2018-11-16 04:45:17'),('S83','AG2016','2020-09-23 04:24:10'),('s84','AG2010','2017-03-27 06:34:18'),('s85','AG2010','2017-03-27 06:34:22'),('s87','AG2022','2017-11-18 13:54:11'),('s206','AG2010','2017-03-27 06:35:33'),('s207','AG2023','2018-10-05 12:32:04'),('s208','AG2014','2017-03-27 06:35:55'),('s209','AG2024','2020-08-03 11:14:19'),('s93','AG2022','2017-11-18 13:55:09'),('s211','AG2024','2022-07-08 08:55:28'),('s212','AG2004','2022-07-08 08:53:46'),('S40','AG2020','2017-04-24 10:53:54'),('s228','AG2006','2017-03-27 06:37:22'),('S214','AG2004','2017-07-04 12:23:04'),('s215','AG2024','2022-07-08 08:54:54'),('s95','AG2010','2017-03-27 06:38:11'),('s96','AG2010','2017-03-27 06:38:16'),('s97','AG2010','2017-03-27 06:38:22'),('s98','AG2010','2017-03-27 06:38:27'),('s216','AG2004','2021-08-09 14:41:10'),('s187','AG2022','2017-03-27 06:39:57'),('s217','AG2022','2017-03-27 06:40:22'),('s218','AG2022','2017-03-27 06:40:26'),('s219','AG2022','2017-03-27 06:40:30'),('s220','AG2022','2017-03-27 06:40:34'),('s101','AG2010','2017-03-27 06:40:51'),('S102','AG2016','2020-08-18 04:18:39'),('s103','AG2010','2017-03-27 06:41:02'),('s104','AG2014','2020-10-07 11:27:05'),('s100','AG2010','2017-03-27 06:41:25'),('s105','AG2010','2017-03-27 06:41:42'),('s210','AG2024','2020-09-29 11:38:30'),('s41','AG2020','2017-03-27 06:42:10'),('s42','AG2020','2017-03-27 06:42:14'),('s43','AG2020','2017-03-27 06:42:18'),('S221','AG2020','2019-12-03 11:49:37'),('s223','AG2020','2022-07-08 08:55:06'),('s224','AG2020','2017-03-27 06:43:06'),('s108','AG2010','2017-03-27 06:43:16'),('s225','AG2023','2022-07-08 08:55:39'),('s226','AG2006','2020-11-01 13:58:51'),('s46','AG2020','2017-03-27 06:45:12'),('s47','AG2020','2017-03-27 06:45:17'),('s48','AG2020','2017-03-27 06:45:21'),('s51','AG2020','2017-03-27 06:45:40'),('S227','AG2016','2020-10-17 05:07:49'),('s109','AG2010','2017-03-27 06:47:01'),('S54','AG2020','2021-03-02 14:37:26'),('s55','AG2024','2020-10-12 12:52:20'),('s213','AG2020','2017-03-27 06:47:37'),('s110','AG2010','2017-03-27 06:48:03'),('s111','AG2010','2017-03-27 06:48:09'),('S56','AG2004','2018-10-05 05:10:12'),('S61','AG2023','2017-08-05 06:49:08'),('S113','AG2023','2017-07-04 12:06:44'),('s229','AG2024','2020-09-23 14:06:30'),('S1','AG2004','2017-07-04 12:24:27'),('S180','AG2006','2017-07-18 14:43:05'),('S181','AG2004','2017-07-04 12:25:04'),('S222','AG2004','2017-07-04 12:24:51'),('S230','AG2022','2020-11-24 07:53:02'),('s3','AG2006','2017-03-27 06:51:15'),('s58','AG2014','2022-07-08 06:34:57'),('s59','AG2020','2017-03-27 06:51:35'),('s60','AG2023','2017-07-29 13:24:48'),('s62','AG2016','2022-06-16 05:19:41'),('s63','AG2016','2020-10-07 11:28:38'),('s120','AG2010','2017-03-27 06:52:14'),('s231','AG2014','2017-03-27 06:52:34'),('S232','AG2023','2017-07-04 12:12:11'),('S233','AG2023','2017-07-04 12:12:26'),('s114','AG2010','2017-03-27 06:56:03'),('s115','AG2010','2017-03-27 06:56:07'),('S117','AG2024','2020-10-16 05:08:27'),('s118','AG2010','2017-03-27 06:56:33'),('s119','AG2010','2017-03-27 06:56:40'),('S34','AG2024','2020-11-03 05:58:18'),('S234','AG2004','2018-03-26 06:07:24'),('s64','AG2020','2017-03-27 06:57:25'),('S235','AG2006','2017-03-27 09:55:43'),('S236','AG2023','2017-07-04 12:06:59'),('S1217','AG2022','2020-11-24 07:53:02'),('S237','AG2023','2017-07-04 12:06:14'),('s238','AG2006','2017-04-12 05:57:46'),('S239','AG2023','2017-07-04 12:05:15'),('S240','AG2026','2022-12-02 11:36:56'),('S248','AG2014','2019-07-31 07:21:05'),('S252','AG2004','2017-07-04 12:22:55'),('S243','AG2004','2020-07-07 05:33:01'),('s241','AG2016','2020-09-29 11:38:12'),('s246','AG2016','2020-08-03 11:15:03'),('S250','AG2024','2020-08-14 14:12:01'),('S242','AG2024','2020-08-25 10:15:26'),('s251','AG2004','2022-07-08 08:55:19'),('s247','AG2004','2022-07-08 08:53:54'),('S244','AG2004','2017-07-04 12:24:20'),('s245','AG2024','2020-09-29 11:38:50'),('s249','AG2024','2021-03-23 07:53:53'),('S253','AG2004','2017-04-19 13:21:16'),('S254','AG2004','2017-04-26 15:10:21'),('s255','AG2016','2021-03-10 14:04:53'),('S256','AG2020','2017-06-02 05:26:57'),('S257','AG2020','2017-06-06 12:17:03'),('s258','AG2006','2020-11-04 08:09:14'),('s259','AG2023','2017-08-24 13:18:20'),('S260','AG2024','2020-10-06 05:32:29'),('S261','AG2025','2019-08-03 12:57:22'),('S262','AG2016','2020-09-29 04:31:08'),('S263','AG2023','2017-10-23 11:12:53'),('S264','AG2014','2017-11-06 10:48:54'),('S265','AG2004','2018-10-05 14:49:41'),('s266','AG2014','2017-11-16 13:16:41'),('s267','AG2023','2017-12-04 06:52:42'),('S268','AG2022','2018-01-27 12:37:40'),('s269','AG2014','2022-07-08 06:34:03'),('S270','AG2010','2018-02-01 05:34:28'),('s271','AG2020','2018-02-08 07:04:51'),('s272','AG2020','2018-02-08 07:04:55'),('S273','AG2004','2018-02-12 12:13:28'),('S274','AG2004','2018-02-14 06:36:07'),('S275','AG2026','2022-12-02 11:37:19'),('S276','AG2023','2018-04-16 05:11:18'),('S277','AG2004','2018-04-16 05:15:28'),('s278','AG2023','2018-08-04 05:22:09'),('S279','AG2020','2018-11-04 13:30:37'),('s280','AG2006','2018-11-28 04:21:00'),('s281','AG2016','2021-03-23 07:54:19'),('s282','AG2016','2021-03-23 07:54:24'),('s283','AG2006','2019-01-31 05:22:08'),('s284','AG2010','2019-03-19 11:36:27'),('s285','AG2014','2019-03-28 10:28:57'),('S286','AG2010','2019-05-18 12:36:52'),('s287','AG2022','2020-11-24 07:53:02'),('S288','AG2026','2022-12-02 11:37:09'),('S289','AG2026','2022-12-02 11:37:37'),('S291','AG2004','2020-11-25 06:03:21'),('S292','AG2024','2020-12-01 06:42:57'),('s293','AG2006','2020-12-03 04:37:31'),('s294','AG2024','2021-01-11 08:04:22'),('s295','AG2016','2021-01-28 10:13:24'),('s296','AG2025','2021-04-12 08:07:05'),('S297','AG2016','2021-03-12 04:08:28'),('s298','AG2020','2021-03-17 04:06:42'),('s299','AG2024','2021-04-13 08:13:48'),('s300','AG2016','2021-04-21 04:30:11'),('S301','AG2020','2021-06-22 05:04:51'),('S302','AG2026','2022-12-02 11:37:29'),('s303','AG2014','2021-07-07 12:50:27'),('S304','AG2014','2021-07-10 06:29:31'),('s305','AG2016','2021-09-13 11:31:13'),('S306','AG2024','2021-10-30 14:26:07'),('s307','AG2006','2021-11-15 12:27:13'),('S308','AG2024','2021-11-15 12:27:23'),('S309','AG2024','2021-11-26 14:01:18'),('S310','AG2024','2021-11-26 14:01:25'),('S316','AG2014','2022-08-05 04:38:31'),('S315','AG2004','2022-08-06 04:41:52'),('s312','AG2010','2022-08-06 09:39:48'),('s313','AG2023','2022-08-10 05:44:47'),('s311','AG2006','2022-08-11 06:19:21'),('S317','AG2006','2022-09-19 05:19:11'),('S318','AG2006','2022-09-19 05:21:23'),('s319','AG2010','2022-09-21 07:35:30'),('s320','AG2006','2022-09-21 07:46:36'),('s321','AG2006','2022-09-23 08:32:57'),('s314','AG2022','2022-11-18 08:14:56'),('s322','AG2026','2022-11-18 08:14:14'),('s323','AG2004','2022-12-07 11:12:02');

--
-- Table structure for table `assets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `assets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assets_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `opening_balance` decimal(8,2) NOT NULL DEFAULT 0.00,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `assets_name`, `opening_balance`, `inforce`, `created_at`, `updated_at`) VALUES (1,'Cash',0.00,1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(2,'Bank',0.00,1,'2021-11-03 07:30:59','2021-11-03 07:30:59');

--
-- Table structure for table `balance_table`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `balance_table` (
  `machine_name` varchar(20) NOT NULL DEFAULT '',
  `balance` double DEFAULT 0,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_table`
--


--
-- Table structure for table `bill_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `bill_details` (
  `bill_details_id` varchar(25) NOT NULL,
  `bill_no` varchar(20) DEFAULT '0',
  `job_id` int(11) DEFAULT 0,
  `tag` varchar(20) DEFAULT NULL,
  `model_no` varchar(12) DEFAULT '0',
  `price_code` varchar(4) DEFAULT '0',
  `gold_wt` double DEFAULT 0 COMMENT 'Actual used',
  `gross_wt` double DEFAULT 0,
  `price_method` varchar(20) DEFAULT 'Regular',
  `wastage_percentage` double DEFAULT 0,
  `wastage` double DEFAULT 0,
  `total_gold` double DEFAULT 0 COMMENT 'gold_wt + markup',
  `gold_quality` double DEFAULT 0,
  `fine_gold` double DEFAULT 0,
  `qty` int(11) DEFAULT 0,
  `size` varchar(15) DEFAULT '0',
  `ploss` double DEFAULT 0,
  `labour_charge` double DEFAULT 0,
  `markup_value` double DEFAULT 0,
  PRIMARY KEY (`bill_details_id`),
  KEY `fk_BillID` (`bill_no`),
  KEY `bill_id` (`bill_no`),
  CONSTRAINT `bill_details_ibfk_1` FOREIGN KEY (`bill_no`) REFERENCES `bill_master` (`bill_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_details`
--


--
-- Table structure for table `bill_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `bill_master` (
  `bill_no` varchar(20) NOT NULL DEFAULT '',
  `bill_date` int(11) DEFAULT 41640,
  `cust_id` varchar(50) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  `bill_gold` double DEFAULT 0,
  `gold_cleared` double DEFAULT 0,
  `gold_completed` double DEFAULT 0,
  `bill_labour_charge` double DEFAULT 0,
  `Cash_cleared` double DEFAULT 0,
  `cash_completed` double DEFAULT 0,
  `agent_id` varchar(50) DEFAULT 'AG2018',
  `comments` varchar(255) DEFAULT 'NONE',
  `tr_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `emp_id` int(11) DEFAULT NULL,
  `total_lc_inward` varchar(150) DEFAULT NULL,
  `discount` int(11) DEFAULT 0,
  PRIMARY KEY (`bill_no`),
  UNIQUE KEY `Uni_key_BillNo` (`bill_no`),
  KEY `agent_id` (`agent_id`),
  KEY `cust_id` (`cust_id`),
  KEY `order_id` (`order_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `bill_master_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`) ON UPDATE CASCADE,
  CONSTRAINT `bill_master_ibfk_2` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE,
  CONSTRAINT `bill_master_ibfk_3` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_master`
--


--
-- Table structure for table `business_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `business_status` (
  `consolidated_gold` double DEFAULT NULL,
  `consolidated_lc` int(11) DEFAULT NULL,
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `material_valuation` double DEFAULT 0,
  `cash_in_hand` bigint(20) DEFAULT 0,
  `customer_lc` bigint(20) DEFAULT 0,
  `customer_gold` double DEFAULT 0,
  `stock_gold` double DEFAULT 0,
  `stock_lc` int(11) DEFAULT 0,
  `job_gold` double DEFAULT 0,
  `job_lc` int(11) DEFAULT 0,
  `qty` int(10) unsigned DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_status`
--


--
-- Table structure for table `cash_book`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cash_book` (
  `cash_book_id` varchar(20) NOT NULL DEFAULT '',
  `employee_id` int(11) DEFAULT NULL,
  `inward` int(11) DEFAULT 0,
  `outward` int(11) DEFAULT 0,
  `particulars` varchar(255) DEFAULT NULL,
  `reference_no` varchar(20) DEFAULT NULL,
  `reference_table` varchar(100) DEFAULT NULL,
  `record_time` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`cash_book_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_book`
--


--
-- Table structure for table `cash_transaction_between_employees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cash_transaction_between_employees` (
  `cash_transaction_id` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `payee_id` int(11) NOT NULL,
  `payer_id` int(11) NOT NULL,
  `cash` int(11) NOT NULL,
  `tr_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `comment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cash_transaction_id`),
  KEY `payee_id` (`payee_id`),
  KEY `payer_id` (`payer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_transaction_between_employees`
--


--
-- Table structure for table `chapters`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `chapters` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `chapter_name` varchar(50) DEFAULT NULL,
  `content` varchar(100) DEFAULT NULL,
  `controller` varchar(50) DEFAULT 'site',
  `visible` int(11) DEFAULT 1,
  `orders` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `fk_subject_id` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `subject_id`, `chapter_name`, `content`, `controller`, `visible`, `orders`) VALUES (0,5,'Agents','agent_due_report_facade','customer_controller',1,0),(3,5,'Customers','customer_master_facade','customer_controller',1,0),(4,6,'Receipts Record','customer_wise_receipt_facade','report_controller',1,0),(5,5,'Customer Dues','customer_due_report_facade','customer_controller',1,0),(6,5,'Delete Bill','bill_delete_facade','customer_controller',1,0),(8,6,'Customer Due list','customer_aggregate_due_report_facade','report_controller',1,1),(9,6,'Gold Receipts','gold_receipt_report_facade','customer_controller',1,0),(10,6,'Agentwise Search','find_dues_as_agent_facade','report_controller',1,0),(11,6,'Daily Gold Receipt','gold_receipt_report_facade','report_controller',1,0),(12,6,'Gold Receipt by Date','gold_receipt_report_by_date_facade','report_controller',1,0),(13,6,'Cash Receipt by Date','cash_receipt_report_by_date_action','report_controller',1,0),(14,6,'Job History','job_history_facade','report_controller',1,0),(15,6,'Nitrick Return','mathakata_and_nitickReturn_facade','report_controller',1,0),(16,6,'All Due List','all_due_list_facade','report_controller',1,0),(17,6,'Sales Report','sales_report_facade','report_controller',1,0),(18,7,'Job Change','Job_change_facade','transaction_controller',1,0),(19,8,'Agent Sales','agent_sales_facade','admin_controller',1,0),(20,7,'Gold Received','gold_received_all_facade','transaction_controller',1,0),(21,7,'GOLD Price','change_gold_price_facade','transaction_controller',1,0),(22,8,'Gold at JOB','job_history_for_gold_in_workshop_facade','report_controller',1,0),(23,8,'unadjusted gold','adjust_advance_gold_by_cust_id_facade','transaction_controller',1,0),(24,8,'Cust Last Sale','get_customer_last_bill_in_days_facade','admin_controller',1,0),(25,8,'Last Sale Report','last_sale_report_facade','admin_controller',1,0),(26,8,'Duplicate Bill','show_duplicate_bill_facade','report_controller',1,0),(27,8,'Customer Status','customer_status_facade','admin_controller',1,0),(28,6,'JOB PRINT','show_job_status_facade','report_controller',1,0),(29,7,'Order','job_order_facade','transaction_controller',1,0),(30,8,'Customer Setting','customer_settings_facade','admin_controller',1,0),(31,7,'TOPUP Gold','topup_gold_facade','transaction_controller',1,0),(32,7,'TOPUP PAN','topup_pan_facade','transaction_controller',1,0),(33,8,'Stock Transfer','stock_to_employee_facade','admin_controller',1,0),(34,8,'closing Stock','create_rm_master_pivot_table','report_controller',1,0),(36,8,'todays report','show_transactions_facade','report_controller',1,0),(37,8,'Add Bill','add_extra_bill_facade','admin_controller',1,0),(38,6,'Dues by Bill','get_due_bills_facade','report_controller',1,0),(39,8,'Unadjusted LC','adjust_advance_lc_by_cust_id_facade','transaction_controller',1,0),(40,8,'Adjust all Unadjusted','adjust_all_unadjusted_gold','transaction_controller',1,0),(41,6,'Receipt Print','show_lc_receipt_facade','report_controller',1,0),(42,5,'Products','product_master_facade','product_controller',1,0),(43,6,'New Cust Dues','new_customer_dues_report_facade','report_controller',1,0),(44,8,'Order Block','order_block_customers_facade','admin_controller',1,0),(45,6,'Working Report','pos_working_report_facade','report_controller',1,0),(46,8,'Daily Report','all_daily_reports_facade','admin_controller',1,0),(47,9,'Create Graph','create_graph','super_controller',1,0),(48,6,'Papai','essential_reports_facade','report_controller',1,0),(49,7,'LC Received','lc_received_all_facade','transaction_controller',1,0),(50,7,'Adjust LC','lc_adjustment_facade','transaction_controller',1,0),(51,9,'Adjust Bill','adjust_bill_master_against_bill_details_action','super_controller',1,0),(52,10,'Report','model_facade','report_second_controller',1,0);

--
-- Table structure for table `company_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `company_details` (
  `company_name` varchar(50) NOT NULL DEFAULT '',
  `mailing_name` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `land1` varchar(50) DEFAULT NULL,
  `land2` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `caption` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `pos` varchar(255) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `doc` date DEFAULT NULL,
  `sns` date DEFAULT NULL,
  `rm` date DEFAULT NULL,
  `oa` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`company_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_details`
--

INSERT INTO `company_details` (`company_name`, `mailing_name`, `address1`, `address2`, `land1`, `land2`, `mobile`, `caption`, `email`, `website`, `pos`, `brand_name`, `doc`, `sns`, `rm`, `oa`, `last_update`) VALUES ('CV','Srikrishna Bangle Jewellery Workshop','Sewli, P.O. - STP. (Baro Kanthaliya), Barrackpore','Dist. North 24 Parganas, Kol-121','033 2535 3727','','+91 9836444999','à¦à¦• à¦•à¦¦à¦® à¦à¦—à¦¿à§Ÿà§‡','bangle312@gmail.com','www.bengalibangle.com','Counter A@CV','CV','2023-12-02','2020-04-30','2019-08-31','2019-08-31','2022-06-30');

--
-- Table structure for table `configuration`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `inforce` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `configuration_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `configuration_group` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

INSERT INTO `configuration` (`id`, `group_id`, `key`, `value`, `inforce`) VALUES (1,3001,'42','90 Gini',1),(2,3001,'48','92 Gini',1),(3,3002,'48','92 Gini',1);

--
-- Table structure for table `configuration_group`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `configuration_group` (
  `id` int(11) NOT NULL DEFAULT 0,
  `group_name` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_group`
--

INSERT INTO `configuration_group` (`id`, `group_name`) VALUES (3001,'rm_gold_order'),(3002,'rm_gold_order_default');

--
-- Table structure for table `cust_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cust_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) DEFAULT NULL,
  `inforce` tinyint(4) DEFAULT 1,
  `visible` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_category`
--

INSERT INTO `cust_category` (`ID`, `category`, `inforce`, `visible`) VALUES (1,'# Base',1,1),(11,'General1',1,1),(12,'150 Less',1,1),(13,'50 Less',1,1),(14,'20 Less',1,1),(15,'30 Less',1,1),(16,'50%',1,1),(17,'100 Less',1,1),(18,'NIL LC',1,1);

--
-- Table structure for table `custom_vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `custom_vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `voucher_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_counter` bigint(20) NOT NULL DEFAULT 1,
  `accounting_year` int(11) NOT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suffix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delimiter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/',
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `custom_vouchers_voucher_name_accounting_year_unique` (`voucher_name`,`accounting_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_vouchers`
--


--
-- Table structure for table `customer_balance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `customer_balance` (
  `cust_id` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `opening_gold` double DEFAULT 0,
  `opening_lc` int(11) DEFAULT 0,
  `billed_gold` double DEFAULT 0,
  `billed_lc` int(11) DEFAULT 0,
  `received_gold` double DEFAULT 0,
  `received_lc` int(11) DEFAULT 0,
  `op_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`cust_id`),
  CONSTRAINT `customer_balance_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_balance`
--

INSERT INTO `customer_balance` (`cust_id`, `opening_gold`, `opening_lc`, `billed_gold`, `billed_lc`, `received_gold`, `received_lc`, `op_date`) VALUES ('S1',9.491,12520,0,0,0,0,'2022-12-13 17:11:04'),('S10',27.556,9370,0,0,0,0,'2022-12-13 17:11:04'),('S100',9.661,19930,0,0,0,0,'2022-12-13 17:11:04'),('S101',7.17,4807,0,0,0,0,'2022-12-13 17:11:04'),('S102',0.257,1590,0,0,0,0,'2022-12-13 17:11:04'),('S103',60.01,106970,0,0,0,0,'2022-12-13 17:11:04'),('S104',15.798,4060,0,0,0,0,'2022-12-13 17:11:04'),('S105',10.753,20,0,0,0,0,'2022-12-13 17:11:04'),('S106',24.524,46520,0,0,0,0,'2022-12-13 17:11:04'),('S107',30.365,129720,0,0,0,0,'2022-12-13 17:11:04'),('S108',5.299,0,0,0,0,0,'2022-12-13 17:11:04'),('S109',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S11',8.985,3590,0,0,0,0,'2022-12-13 17:11:04'),('S110',3.363,3120,0,0,0,0,'2022-12-13 17:11:04'),('S111',0,560,0,0,0,0,'2022-12-13 17:11:04'),('S112',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S113',54.43,80129,0,0,0,0,'2022-12-13 17:11:04'),('S114',1.03,760,0,0,0,0,'2022-12-13 17:11:04'),('S115',36.679,11290,0,0,0,0,'2022-12-13 17:11:04'),('S116',14.032,13020,0,0,0,0,'2022-12-13 17:11:04'),('S117',0.053,7430,0,0,0,0,'2022-12-13 17:11:04'),('S118',4.306,2460,0,0,0,0,'2022-12-13 17:11:04'),('S119',13.138,1680,0,0,0,0,'2022-12-13 17:11:04'),('S12',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S120',7.852,3550,0,0,0,0,'2022-12-13 17:11:04'),('S121',4.691,800,0,0,0,0,'2022-12-13 17:11:04'),('S1217',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S122',4.417,13840,0,0,0,0,'2022-12-13 17:11:04'),('S123',2.172,0,0,0,0,0,'2022-12-13 17:11:04'),('S124',0.488,400,0,0,0,0,'2022-12-13 17:11:04'),('S125',6.821,10240,0,0,0,0,'2022-12-13 17:11:04'),('S126',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S127',0.252,23472,0,0,0,0,'2022-12-13 17:11:04'),('S128',28.039,11860,0,0,0,0,'2022-12-13 17:11:04'),('S129',0.078,3500,0,0,0,0,'2022-12-13 17:11:04'),('S13',13.575,13175,0,0,0,0,'2022-12-13 17:11:04'),('S130',6.53,0,0,0,0,0,'2022-12-13 17:11:04'),('S131',4.353,0,0,0,0,0,'2022-12-13 17:11:04'),('S132',22.98,42260,0,0,0,0,'2022-12-13 17:11:04'),('S133',5.593,0,0,0,0,0,'2022-12-13 17:11:04'),('S134',0,634,0,0,0,0,'2022-12-13 17:11:04'),('S135',5.418,3722,0,0,0,0,'2022-12-13 17:11:04'),('S136',0,5500,0,0,0,0,'2022-12-13 17:11:04'),('S137',32.949,18970,0,0,0,0,'2022-12-13 17:11:04'),('S138',1.696,6080,0,0,0,0,'2022-12-13 17:11:04'),('S139',33.04,12340,0,0,0,0,'2022-12-13 17:11:04'),('S14',5.033,2530,0,0,0,0,'2022-12-13 17:11:04'),('S140',13.69,15040,0,0,0,0,'2022-12-13 17:11:04'),('S141',8.825,9628,0,0,0,0,'2022-12-13 17:11:04'),('S142',0.53,160,0,0,0,0,'2022-12-13 17:11:04'),('S143',18.215,24170,0,0,0,0,'2022-12-13 17:11:04'),('S144',15.656,20180,0,0,0,0,'2022-12-13 17:11:04'),('S145',4.95,0,0,0,0,0,'2022-12-13 17:11:04'),('S146',0,3600,0,0,0,0,'2022-12-13 17:11:04'),('S147',60.95,172284,0,0,0,0,'2022-12-13 17:11:04'),('S148',12.476,4932,0,0,0,0,'2022-12-13 17:11:04'),('S149',46.37,8240,0,0,0,0,'2022-12-13 17:11:04'),('S15',21.081,18410,0,0,0,0,'2022-12-13 17:11:04'),('S150',5.542,1400,0,0,0,0,'2022-12-13 17:11:04'),('S151',10.728,27160,0,0,0,0,'2022-12-13 17:11:04'),('S152',6.478,1860,0,0,0,0,'2022-12-13 17:11:04'),('S153',1.229,5990,0,0,0,0,'2022-12-13 17:11:04'),('S154',3.879,0,0,0,0,0,'2022-12-13 17:11:04'),('S155',4.525,1980,0,0,0,0,'2022-12-13 17:11:04'),('S156',14.714,440,0,0,0,0,'2022-12-13 17:11:04'),('S157',61.856,650,0,0,0,0,'2022-12-13 17:11:04'),('S158',1.314,2850,0,0,0,0,'2022-12-13 17:11:04'),('S159',8.162,11760,0,0,0,0,'2022-12-13 17:11:04'),('S16',0.064,7360,0,0,0,0,'2022-12-13 17:11:04'),('S160',0.133,7510,0,0,0,0,'2022-12-13 17:11:04'),('S161',0.688,3990,0,0,0,0,'2022-12-13 17:11:04'),('S162',3.915,1820,0,0,0,0,'2022-12-13 17:11:04'),('S163',42.166,50540,0,0,0,0,'2022-12-13 17:11:04'),('S164',4.5,7720,0,0,0,0,'2022-12-13 17:11:04'),('S165',4.598,3610,0,0,0,0,'2022-12-13 17:11:04'),('S166',-0,20870,0,0,0,0,'2022-12-13 17:11:04'),('S167',7.29,1720,0,0,0,0,'2022-12-13 17:11:04'),('S168',3.375,0,0,0,0,0,'2022-12-13 17:11:04'),('S169',9.688,480,0,0,0,0,'2022-12-13 17:11:04'),('S17',22.835,0,0,0,0,0,'2022-12-13 17:11:04'),('S170',3.816,1360,0,0,0,0,'2022-12-13 17:11:04'),('S171',2.985,910,0,0,0,0,'2022-12-13 17:11:04'),('S172',15.154,2980,0,0,0,0,'2022-12-13 17:11:04'),('S173',4.621,1450,0,0,0,0,'2022-12-13 17:11:04'),('S174',0,140,0,0,0,0,'2022-12-13 17:11:04'),('S175',-0.283,2420,0,0,0,0,'2022-12-13 17:11:04'),('S176',8.491,1177,0,0,0,0,'2022-12-13 17:11:04'),('S177',7.505,16680,0,0,0,0,'2022-12-13 17:11:04'),('S178',1.409,860,0,0,0,0,'2022-12-13 17:11:04'),('S179',0.27,1120,0,0,0,0,'2022-12-13 17:11:04'),('S18',5.129,11420,0,0,0,0,'2022-12-13 17:11:04'),('S180',7.531,8883,0,0,0,0,'2022-12-13 17:11:04'),('S181',3.746,2300,0,0,0,0,'2022-12-13 17:11:04'),('S182',12.56,2020,0,0,0,0,'2022-12-13 17:11:04'),('S183',0.015,60,0,0,0,0,'2022-12-13 17:11:04'),('S184',0.09,1400,0,0,0,0,'2022-12-13 17:11:04'),('S185',6.957,3384,0,0,0,0,'2022-12-13 17:11:04'),('S186',-0,690,0,0,0,0,'2022-12-13 17:11:04'),('S187',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S188',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S189',6.17,11730,0,0,0,0,'2022-12-13 17:11:04'),('S19',8.68,21817,0,0,0,0,'2022-12-13 17:11:04'),('S190',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S191',0.005,4890,0,0,0,0,'2022-12-13 17:11:04'),('S192',9.99,16820,0,0,0,0,'2022-12-13 17:11:04'),('S193',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S194',0,171,0,0,0,0,'2022-12-13 17:11:04'),('S195',12.422,90300,0,0,0,0,'2022-12-13 17:11:04'),('S196',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S197',3.88,4390,0,0,0,0,'2022-12-13 17:11:04'),('S198',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S199',4.107,0,0,0,0,0,'2022-12-13 17:11:04'),('S2',0.988,1700,0,0,0,0,'2022-12-13 17:11:04'),('S20',10.661,11592,0,0,0,0,'2022-12-13 17:11:04'),('S200',2.385,0,0,0,0,0,'2022-12-13 17:11:04'),('S201',1.411,1960,0,0,0,0,'2022-12-13 17:11:04'),('S202',0.695,0,0,0,0,0,'2022-12-13 17:11:04'),('S203',4.266,0,0,0,0,0,'2022-12-13 17:11:04'),('S204',0,760,0,0,0,0,'2022-12-13 17:11:04'),('S205',14.047,14140,0,0,0,0,'2022-12-13 17:11:04'),('S206',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S207',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S208',0.09,0,0,0,0,0,'2022-12-13 17:11:04'),('S209',14.646,24015,0,0,0,0,'2022-12-13 17:11:04'),('S21',13.076,22840,0,0,0,0,'2022-12-13 17:11:04'),('S210',0.622,9110,0,0,0,0,'2022-12-13 17:11:04'),('S211',5.44,0,0,0,0,0,'2022-12-13 17:11:04'),('S212',0,320,0,0,0,0,'2022-12-13 17:11:04'),('S213',0.03,0,0,0,0,0,'2022-12-13 17:11:04'),('S214',5.746,10340,0,0,0,0,'2022-12-13 17:11:04'),('S215',1.814,330,0,0,0,0,'2022-12-13 17:11:04'),('S216',0.014,520,0,0,0,0,'2022-12-13 17:11:04'),('S217',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S218',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S219',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S22',68.882,400,0,0,0,0,'2022-12-13 17:11:04'),('S220',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S221',5.425,1960,0,0,0,0,'2022-12-13 17:11:04'),('S222',4.719,7171,0,0,0,0,'2022-12-13 17:11:04'),('S223',1.793,90,0,0,0,0,'2022-12-13 17:11:04'),('S224',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S225',6.893,840,0,0,0,0,'2022-12-13 17:11:04'),('S226',0,5280,0,0,0,0,'2022-12-13 17:11:04'),('S227',0.658,5060,0,0,0,0,'2022-12-13 17:11:04'),('S228',5.157,2200,0,0,0,0,'2022-12-13 17:11:04'),('S229',0.782,17530,0,0,0,0,'2022-12-13 17:11:04'),('S23',5.731,11310,0,0,0,0,'2022-12-13 17:11:04'),('S230',9.048,14540,0,0,0,0,'2022-12-13 17:11:04'),('S231',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S232',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S233',0.73,240,0,0,0,0,'2022-12-13 17:11:04'),('S234',3.805,0,0,0,0,0,'2022-12-13 17:11:04'),('S235',40.918,2560,0,0,0,0,'2022-12-13 17:11:04'),('S236',0,70,0,0,0,0,'2022-12-13 17:11:04'),('S237',1.481,760,0,0,0,0,'2022-12-13 17:11:04'),('S238',10.512,9050,0,0,0,0,'2022-12-13 17:11:04'),('S239',2.876,0,0,0,0,0,'2022-12-13 17:11:04'),('S24',8.909,37595,0,0,0,0,'2022-12-13 17:11:04'),('S240',4.692,4300,0,0,0,0,'2022-12-13 17:11:04'),('S241',2.63,240,0,0,0,0,'2022-12-13 17:11:04'),('S242',1.704,10628,0,0,0,0,'2022-12-13 17:11:04'),('S243',1.624,320,0,0,0,0,'2022-12-13 17:11:04'),('S244',1.245,120,0,0,0,0,'2022-12-13 17:11:04'),('S245',2.313,11593,0,0,0,0,'2022-12-13 17:11:04'),('S246',-0,5480,0,0,0,0,'2022-12-13 17:11:04'),('S247',1.916,0,0,0,0,0,'2022-12-13 17:11:04'),('S248',3.282,0,0,0,0,0,'2022-12-13 17:11:04'),('S249',13.896,26118,0,0,0,0,'2022-12-13 17:11:04'),('S25',0.477,0,0,0,0,0,'2022-12-13 17:11:04'),('S250',8.583,18040,0,0,0,0,'2022-12-13 17:11:04'),('S251',1.618,0,0,0,0,0,'2022-12-13 17:11:04'),('S252',3.019,960,0,0,0,0,'2022-12-13 17:11:04'),('S253',11.295,25550,0,0,0,0,'2022-12-13 17:11:04'),('S254',0.038,2770,0,0,0,0,'2022-12-13 17:11:04'),('S255',6.181,3100,0,0,0,0,'2022-12-13 17:11:04'),('S256',2.369,6960,0,0,0,0,'2022-12-13 17:11:04'),('S257',0,4560,0,0,0,0,'2022-12-13 17:11:04'),('S258',25.791,9810,0,0,0,0,'2022-12-13 17:11:04'),('S259',31.316,151502,0,0,0,0,'2022-12-13 17:11:04'),('S26',39.224,400,0,0,0,0,'2022-12-13 17:11:04'),('s260',0.754,2380,0,0,0,0,'2022-12-13 17:11:04'),('S261',0.108,60,0,0,0,0,'2022-12-13 17:11:04'),('S262',9.781,15408,0,0,0,0,'2022-12-13 17:11:04'),('S263',6.79,8900,0,0,0,0,'2022-12-13 17:11:04'),('S264',6.177,1680,0,0,0,0,'2022-12-13 17:11:04'),('S265',8.66,2230,0,0,0,0,'2022-12-13 17:11:04'),('S266',2.749,10540,0,0,0,0,'2022-12-13 17:11:04'),('S267',-0.006,1510,0,0,0,0,'2022-12-13 17:11:04'),('S268',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S269',6.045,22476,0,0,0,0,'2022-12-13 17:11:04'),('S27',32.196,7490,0,0,0,0,'2022-12-13 17:11:04'),('S270',13.863,13760,0,0,0,0,'2022-12-13 17:11:04'),('S271',1.86,640,0,0,0,0,'2022-12-13 17:11:04'),('S272',1,540,0,0,0,0,'2022-12-13 17:11:04'),('S273',0.186,2450,0,0,0,0,'2022-12-13 17:11:04'),('S274',0.037,136,0,0,0,0,'2022-12-13 17:11:04'),('S275',11.161,7140,0,0,0,0,'2022-12-13 17:11:04'),('S276',9.965,920,0,0,0,0,'2022-12-13 17:11:04'),('S277',0.019,710,0,0,0,0,'2022-12-13 17:11:04'),('S278',1.509,43020,0,0,0,0,'2022-12-13 17:11:04'),('S279',0,8105,0,0,0,0,'2022-12-13 17:11:04'),('S28',8.348,3810,0,0,0,0,'2022-12-13 17:11:04'),('S280',86.336,127889,0,0,0,0,'2022-12-13 17:11:04'),('S281',14.925,20560,0,0,0,0,'2022-12-13 17:11:04'),('S282',1.601,21710,0,0,0,0,'2022-12-13 17:11:04'),('S283',3.326,2040,0,0,0,0,'2022-12-13 17:11:04'),('S284',12.857,11280,0,0,0,0,'2022-12-13 17:11:04'),('S285',12.543,11020,0,0,0,0,'2022-12-13 17:11:04'),('S286',10.526,2140,0,0,0,0,'2022-12-13 17:11:04'),('S287',2.265,900,0,0,0,0,'2022-12-13 17:11:04'),('S288',17.962,28695,0,0,0,0,'2022-12-13 17:11:04'),('S289',13.269,8572,0,0,0,0,'2022-12-13 17:11:04'),('S29',8.936,11180,0,0,0,0,'2022-12-13 17:11:04'),('S291',-0,2442,0,0,0,0,'2022-12-13 17:11:04'),('S292',15.047,14540,0,0,0,0,'2022-12-13 17:11:04'),('S293',5.387,7650,0,0,0,0,'2022-12-13 17:11:04'),('S294',-0,820,0,0,0,0,'2022-12-13 17:11:04'),('S295',14.719,7600,0,0,0,0,'2022-12-13 17:11:04'),('S296',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S297',0.631,6620,0,0,0,0,'2022-12-13 17:11:04'),('S298',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S299',15.824,23980,0,0,0,0,'2022-12-13 17:11:04'),('S3',50.123,144990,0,0,0,0,'2022-12-13 17:11:04'),('S30',0,3042,0,0,0,0,'2022-12-13 17:11:04'),('S300',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S301',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S302',11.141,86741,0,0,0,0,'2022-12-13 17:11:04'),('S303',3.679,18703,0,0,0,0,'2022-12-13 17:11:04'),('S304',1.118,12493,0,0,0,0,'2022-12-13 17:11:04'),('S305',2.668,910,0,0,0,0,'2022-12-13 17:11:04'),('S306',0.141,4080,0,0,0,0,'2022-12-13 17:11:04'),('S307',6.21,17360,0,0,0,0,'2022-12-13 17:11:04'),('S308',0.083,16140,0,0,0,0,'2022-12-13 17:11:04'),('S309',0.01,3280,0,0,0,0,'2022-12-13 17:11:04'),('S31',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S310',0.024,2820,0,0,0,0,'2022-12-13 17:11:04'),('S311',-0,6169,0,0,0,0,'2022-12-13 17:11:04'),('S312',3.939,23760,0,0,0,0,'2022-12-13 17:11:04'),('S313',0.029,2360,0,0,0,0,'2022-12-13 17:11:04'),('S314',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S315',0,120,0,0,0,0,'2022-12-13 17:11:04'),('S316',0.882,220,0,0,0,0,'2022-12-13 17:11:04'),('S317',18.765,110,0,0,0,0,'2022-12-13 17:11:04'),('S318',4.069,1360,0,0,0,0,'2022-12-13 17:11:04'),('S319',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S32',1.108,420,0,0,0,0,'2022-12-13 17:11:04'),('S320',4.138,1000,0,0,0,0,'2022-12-13 17:11:04'),('S321',0.037,3170,0,0,0,0,'2022-12-13 17:11:04'),('S322',3.01,4520,0,0,0,0,'2022-12-13 17:11:04'),('S323',-3.295,1240,0,0,0,0,'2022-12-13 17:11:04'),('S33',1.256,0,0,0,0,0,'2022-12-13 17:11:04'),('S34',23.282,38140,0,0,0,0,'2022-12-13 17:11:04'),('S35',14.512,30341,0,0,0,0,'2022-12-13 17:11:04'),('S36',16.936,2820,0,0,0,0,'2022-12-13 17:11:04'),('S37',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S38',22.813,0,0,0,0,0,'2022-12-13 17:11:04'),('S39',-0.02,0,0,0,0,0,'2022-12-13 17:11:04'),('S4',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S40',-0,2353,0,0,0,0,'2022-12-13 17:11:04'),('S41',4.548,1440,0,0,0,0,'2022-12-13 17:11:04'),('S42',0,3420,0,0,0,0,'2022-12-13 17:11:04'),('S43',-0,580,0,0,0,0,'2022-12-13 17:11:04'),('S44',8.885,0,0,0,0,0,'2022-12-13 17:11:04'),('S45',26.352,15260,0,0,0,0,'2022-12-13 17:11:04'),('S46',-0,120,0,0,0,0,'2022-12-13 17:11:04'),('S47',-0,10,0,0,0,0,'2022-12-13 17:11:04'),('S48',2.367,4540,0,0,0,0,'2022-12-13 17:11:04'),('S49',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S5',39.717,9950,0,0,0,0,'2022-12-13 17:11:04'),('S50',0.019,6020,0,0,0,0,'2022-12-13 17:11:04'),('S51',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S52',11.034,1180,0,0,0,0,'2022-12-13 17:11:04'),('S53',0.598,5755,0,0,0,0,'2022-12-13 17:11:04'),('S54',7.035,13790,0,0,0,0,'2022-12-13 17:11:04'),('S55',-0.145,7500,0,0,0,0,'2022-12-13 17:11:04'),('S56',5.014,11020,0,0,0,0,'2022-12-13 17:11:04'),('S57',3.809,37458,0,0,0,0,'2022-12-13 17:11:04'),('S58',0.001,0,0,0,0,0,'2022-12-13 17:11:04'),('S59',2.879,8650,0,0,0,0,'2022-12-13 17:11:04'),('S6',16.917,12690,0,0,0,0,'2022-12-13 17:11:04'),('S60',0.704,1240,0,0,0,0,'2022-12-13 17:11:04'),('S61',29.88,41450,0,0,0,0,'2022-12-13 17:11:04'),('S62',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S63',1.642,6360,0,0,0,0,'2022-12-13 17:11:04'),('S64',-0,310,0,0,0,0,'2022-12-13 17:11:04'),('S65',26.249,22760,0,0,0,0,'2022-12-13 17:11:04'),('S66',1.431,6180,0,0,0,0,'2022-12-13 17:11:04'),('S67',2.853,0,0,0,0,0,'2022-12-13 17:11:04'),('S68',33.821,39660,0,0,0,0,'2022-12-13 17:11:04'),('S69',59.929,2900,0,0,0,0,'2022-12-13 17:11:04'),('S7',7.509,107339,0,0,0,0,'2022-12-13 17:11:04'),('S70',16.622,6425,0,0,0,0,'2022-12-13 17:11:04'),('S71',27.982,45870,0,0,0,0,'2022-12-13 17:11:04'),('S72',11.746,5990,0,0,0,0,'2022-12-13 17:11:04'),('S73',4.751,9070,0,0,0,0,'2022-12-13 17:11:04'),('S74',0.77,0,0,0,0,0,'2022-12-13 17:11:04'),('S75',13.438,620,0,0,0,0,'2022-12-13 17:11:04'),('S76',18.227,6340,0,0,0,0,'2022-12-13 17:11:04'),('S77',19.96,14310,0,0,0,0,'2022-12-13 17:11:04'),('S78',26.382,66000,0,0,0,0,'2022-12-13 17:11:04'),('S79',11.701,64450,0,0,0,0,'2022-12-13 17:11:04'),('S8',33.226,8730,0,0,0,0,'2022-12-13 17:11:04'),('S80',0.593,0,0,0,0,0,'2022-12-13 17:11:04'),('S81',10.177,3520,0,0,0,0,'2022-12-13 17:11:04'),('S82',4.608,2360,0,0,0,0,'2022-12-13 17:11:04'),('S83',8.847,11010,0,0,0,0,'2022-12-13 17:11:04'),('S84',14.04,2500,0,0,0,0,'2022-12-13 17:11:04'),('S85',5.568,1240,0,0,0,0,'2022-12-13 17:11:04'),('S86',9.829,8120,0,0,0,0,'2022-12-13 17:11:04'),('S87',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S88',1.686,14680,0,0,0,0,'2022-12-13 17:11:04'),('S89',14.765,4880,0,0,0,0,'2022-12-13 17:11:04'),('S9',14.639,34922,0,0,0,0,'2022-12-13 17:11:04'),('S90',5.112,18920,0,0,0,0,'2022-12-13 17:11:04'),('S91',52.894,17255,0,0,0,0,'2022-12-13 17:11:04'),('S92',15.893,7140,0,0,0,0,'2022-12-13 17:11:04'),('S93',0,0,0,0,0,0,'2022-12-13 17:11:04'),('S94',-0,560,0,0,0,0,'2022-12-13 17:11:04'),('S95',4.601,11060,0,0,0,0,'2022-12-13 17:11:04'),('S96',14.502,4440,0,0,0,0,'2022-12-13 17:11:04'),('S97',-0,0,0,0,0,0,'2022-12-13 17:11:04'),('S98',0,23120,0,0,0,0,'2022-12-13 17:11:04'),('S99',18.765,11300,0,0,0,0,'2022-12-13 17:11:04');

--
-- Table structure for table `customer_discount`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `customer_discount` (
  `customer_discount_id` varchar(15) NOT NULL,
  `cust_id` varchar(50) NOT NULL,
  `agent_id` varchar(50) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `gold` double NOT NULL,
  `inforce` int(11) NOT NULL DEFAULT 1,
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`customer_discount_id`),
  KEY `cust_id` (`cust_id`,`emp_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `customer_discount_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE,
  CONSTRAINT `customer_discount_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_discount`
--


--
-- Table structure for table `customer_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `customer_master` (
  `cust_id` varchar(50) NOT NULL,
  `cust_name` varchar(150) DEFAULT NULL,
  `mailing_name` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `cust_address` varchar(255) DEFAULT NULL,
  `cust_pin` varchar(20) DEFAULT NULL,
  `cust_phone` varchar(25) DEFAULT '0',
  `p_cat` int(11) DEFAULT 0,
  `gold_limit` double DEFAULT 0,
  `cash_limit` int(11) DEFAULT 0,
  `markup_value` double DEFAULT 0.111,
  `markuped` int(11) DEFAULT 0,
  `user_id` varchar(50) DEFAULT NULL,
  `order_inforce` int(11) NOT NULL DEFAULT 0,
  `bill_inforce` int(11) NOT NULL DEFAULT 0,
  `short_name` varchar(10) DEFAULT NULL,
  `lc_discount_percentage` double DEFAULT 10,
  PRIMARY KEY (`cust_id`),
  UNIQUE KEY `Uni_key_cust_name` (`cust_name`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`cust_id`, `cust_name`, `mailing_name`, `city`, `cust_address`, `cust_pin`, `cust_phone`, `p_cat`, `gold_limit`, `cash_limit`, `markup_value`, `markuped`, `user_id`, `order_inforce`, `bill_inforce`, `short_name`, `lc_discount_percentage`) VALUES ('S1','Angana Jewellers','M/s Angana Jewellers','Shyamnagar','364/8 Basudebpur Road , Writuja Complex,','0','9831397484,03325860066',1,500,5000,0.05,1,NULL,1,1,'AJ',10),('S10','Milan Kanak Sanj Jewellers','M/s Milan Kanak Sanj Jewellers','Baruipur','Kachari Bazar','0','943382305 , 24338894',1,500,5000,0.1,1,NULL,1,1,'MKSJ',10),('S100','Jewell Garden (Khardha)','M/s Jewell Garden ','Khardha','Khardha','0','33-25685776',1,500,5000,0,1,NULL,1,1,'JG(',10),('S101','K . C Choudhury & Sons Jewellers','M/s K . C Choudhury & Sons Jewellers','Khardha','Khardha','0','33-25636117',1,500,5000,0,1,NULL,1,1,'K.CC&SJ',10),('S102','New Anjali Jewellers','M/s New Anjali Jewellers','Uttarpara','50 Charakdanga Road, Hooghly, 712258','721158','9831033871/26641248',1,500,5000,0,1,NULL,1,1,'NAJ',10),('S103','Sukanya Jewellery House','M/s Sukanya Jewellery House','Khardha','Rahara','0','33-25681502',1,500,5000,0.2,1,NULL,1,1,'SJH',10),('S104','Subhasree Jewellers','M/s Subhasree Jewellers','Mecheda','Kakdihi, Mecheda, Puratan Bazar','0','7602429823/8167802629',1,500,5000,0.1,1,NULL,1,1,'SJ',10),('S105','S.S. Paul Jewellers','M/s S.S. Paul Jewellers','Dumdum','Nager Bazar, Dumdum','0','9830585936',1,500,5000,0.2,1,NULL,1,1,'AJL',10),('S106','Apan Jewellers','M/s Apan Jewellers','Madhyamgram','Madhyamgram','0','33-25386902',1,500,5000,0.025,1,NULL,1,1,'AJ',10),('S107','Venus Jewellers','M/s Venus Jewellers','Madhyamgram ','Madhyamgram ','0','33-25381675 , 9830512220',1,500,5000,0,1,NULL,1,1,'VJ',10),('S108','Swarna Tarangini Jewellers','M/s Swarna Tarangini Jewellers','Maldha','Maldha','0','8538877077',1,500,5000,0,1,NULL,1,1,'STJ',10),('S109','Sachidananda Jewellers','M/s Sachidananda Jewellers','Raniganj','Raniganj','0','9475173012',1,500,5000,0,1,NULL,1,1,'SJ',10),('S11','New Annapurna Jewellers','M/s New Annapurna Jewellers','Lakhsmikantapore','Lakhsmikantapore','00000','9088808465',1,500,5000,0,1,NULL,1,1,'SJPCPL',10),('S110','R . C Jewellers(sainthia)','M/s R . C Jewellers','Sainthia','Sainthia','0','9933999273',1,500,5000,0,1,NULL,1,1,'R.CJ',10),('S111','Rupashree Gold','M/s Rupashree Gold','Saltlake','Saltlake,4no Tank','0','33-2334920',1,500,5000,0,1,NULL,1,1,'RG',10),('S112','Maa Rakshakali Jewellers','M/s Maa Rakshakali Jewellers','Suri','Suri , Birbhum','0','9735136575',1,500,5000,0,1,NULL,1,1,'MRJ',10),('S113','Sathi Jewellers','M/s Sathi Jewellers','Shyambazar','Bidhan Sarani , Hatibagan','0','33-25305202 , 65219867',1,500,5000,0.05,1,NULL,1,1,'SJ',10),('S114','Das Jewellers (Srithi)','M/s Das Jewellers ','Srithi','Srithi More','0','9831612926',1,500,5000,0,1,NULL,1,1,'DJ',10),('S115','New Das Brothers Jewellers','M/s New Das Brothers Jewellers','Srithi','Alambazar','0','9831526285',1,500,5000,0.2,1,NULL,1,1,'NDBJ',10),('S116','Dey Brothers Jewellers','M/s Dey Brothers Jewellers','Srithi','Srithi More','0','33-25329343',1,500,5000,0.05,1,NULL,1,1,'DBJ',10),('S117','M. B. Gold Museum','M/s M. B. Gold Museum','Barrackpore','56/4 S. N. Banerjee Road','Kol-120','25452797',1,50,5000,0,1,NULL,1,1,'MBGM',10),('S118','Dutta Guinea Emporium','M/s Dutta Guinea Emporium','Srithi','Srithi More','0','9804036755',1,500,5000,0,1,NULL,1,1,'DGE',10),('S119','Rashiklal Jewellers','M/s Rashiklal Jewellers','Suri','Rabindranath Thakur Road','0','9732059280 , 346225731',1,500,5000,0.2,1,NULL,1,1,'RJ',10),('S12','Bishalaxmi Jewellers','M/s Bishalaxmi Jewellers','Diamond Hurber','Diamond Hurber','0','3174258300 , 9830800300',1,500,5000,0,1,NULL,1,1,'BJ',10),('S120','Maa Sarada Jewellers','M/s Maa Sarada Jewellers','Sodepur','Thakur Corner Marcket','0','9038206845',1,500,5000,0,1,NULL,1,1,'MSJ',10),('S121','Beauti Jewellers','M/s Beauti Jewellers','Belgharia','Belgharia','0','9830966022',1,500,5000,0,1,NULL,1,1,'BJ',10),('S1217','V Ghosh','M/S V Ghosh','Barrackpore','Barrackpore','0','9836444999',1,5000,500000,0,1,NULL,1,1,'VG',10),('S122','National Jewellery Palace','M/s National Jewellery Palace','Arambhag','Gourhati More','0','9474706159',1,500,5000,0,1,NULL,1,1,'NJP',10),('S123','Joy Jewellers','M/s Joy Jewellers','Arambagh','Gourhati More , Bazar Road','0','8001561333',1,500,5000,0,1,NULL,1,1,'JJ',10),('S124','Vaishanadevi Jewellers','M/s Vaishanadevi Jewellers','Birati','Birati','0','9330402013 ',1,500,5000,0,1,NULL,1,1,'CJ',10),('S125','Maya Jewellers','M/s Maya Jewellers','Arambagh','Gourhati More , Bazar Road','0','9851053029',1,500,5000,0,1,NULL,1,1,'MJ',10),('S126','Karukanchan Jewellers','M/s Karukanchan Jewellers','Barasat','Barasat','0','33-25520142',1,500,5000,0,1,NULL,1,1,'KJ',10),('S127','Uttam Jewellers','M/s Uttam Jewellers','Chandannagar','Chandannagar','0','9831625780',1,500,5000,0,1,NULL,1,1,'UJ',10),('S128','Pushpa Gahanalay Jewellers','M/s Pushpa Gahanalay Jewellers','Chandannagar','Chandannagar','0','9433828458',1,500,5000,0.05,1,NULL,1,1,'PGJ',10),('S129','Ashirbad Jewellers New Alipore','M/s Ashirbad Jewellers','New Alipore','New Alipore','0','7003274200',1,500,5000,0,1,NULL,1,1,'LGP',10),('S13','Paul Jewellers','M/s Paul Jewellers','Kolkata','Nabin Chand , Bowbazar','0','9231884352',1,500,5000,0.1,1,NULL,1,1,'PJ',10),('S130','B . K Jewellers','M/s B . K Jewellers','Chinsurah','Chinsurah','0','9331944102',1,500,5000,0,1,NULL,1,1,'B.KJ',10),('S131','S .M Jewellers','M/s S .M Jewellers','Chinsurah','Chinsurah','0','8013363767',1,500,5000,0,1,NULL,1,1,'S.J',10),('S132','Royco Jewellery ','M/s Royco Jewellery ','Chinsurah','Chinsurah','0','33-26811920 , 9874633306',1,500,5000,0,1,NULL,1,1,'RJ',10),('S133','Neha Jewellers','M/s Neha Jewellers','Chinsurah','Chinsurah','0','9903103553',1,500,5000,0,1,NULL,1,1,'NJ',10),('S134','S .R Jewellers','M/s S .R Jewellers','Domjur','Domjur , Amta Road','0','33-26704633 , 9748557593',1,500,5000,0,1,NULL,1,1,'S.J',10),('S135','New Parashmani Jewellers','M/s New Parashmani Jewellers','Durgapore','Benachity','0','7797762113',1,500,5000,0,1,NULL,1,1,'NPJ',10),('S136','Biswajit Jewellers','M/s Biswajit Jewellers','Durgapore','Benachity ','0','9153021470 ',1,500,5000,0,1,NULL,1,1,'BJ',10),('S137','Govind Jewellers','M/s Govind Jewellers','Durgapore','Benachity','0','9434061309',1,500,20000,0,1,NULL,1,1,'GJ',10),('S138','Dey Brothers Jewllers (Durgapore)','M/s Dey Brothers Jewllers ','Durgapore','Benachity','0','9434332591',1,500,5000,0,1,NULL,1,1,'DBJ(',10),('S139','R .C Chandra Jewellers','M/s R .C Chandra Jewellers','Durgapore','Benachity','0','9434444444',1,500,5000,0.2,1,NULL,1,1,'R.CJ',10),('S14','Joy Jagannath Jewellers','M/s Joy Jagannath Jewellers','Howrah','Kadamtala','0','9830295320',1,500,5000,0,1,NULL,1,1,'JJJ',10),('S140','Dutta Guinea Palace','M/s Dutta Guinea Palace','Durgapore','Benachity','0','9434014553',1,5000,5000,0.05,1,NULL,1,1,'DGP',10),('S141','Radha Gobinda Jewellers','M/s Radha Gobinda Jewellers','Sodepur','Thakur Corner Marcket','0','9038879778',1,500,5000,0,1,NULL,1,1,'RGJ',10),('S142','Gold Palace (Sodepur)','M/s Gold Palace ','Sodepur','Natagarh','0','9051817207',1,500,5000,0,1,NULL,1,1,'GP',10),('S143','Maa Kali Jewellers','M/s Maa Kali Jewellers','Mecheda','Purba Midnapore','0','9732538367',1,500,5000,0,1,NULL,1,1,'MKJ',10),('S144','R . C  Jewellers (Sodepur)','M/s R . C  Jewellers ','Sodepur','Thakur Corner Marcket','0','9830856286',1,5000,5000,0.1,1,NULL,1,1,'R.CJ(',10),('S145','Guinea Bhavan Jewellers','M/s Guinea Bhavan Jewellers','Sodepur','Thakur Corner Marcket ','0','9143237892',1,500,5000,0,1,NULL,1,1,'GBJ',10),('S146','Nandi Jewellery House','M/sNandi Jewellery House','Howrah','30a Narasingha Dutta Road, Kadamtala','How-1','9903751511',1,50,5000,0,1,NULL,1,1,'NJ',10),('S147','Nag Jewellery','M/S Nag Jewellery','Gariahat','212, Rasbehari Avenue, Gariahat Market, Kol -19','Kol-19','24401308/40014985',1,100,5000,0,1,NULL,1,1,'NJ',10),('S148','Rajrajeswari Jewellers','M/s Rajrajeswari Jewellers','Sodepur','Thakur Corner Marcket','0','8017282660 , 9830014395',1,500,5000,0,1,NULL,1,1,'RJ',10),('S149','Srikrishna Jewellers (Sodepur)','M/s Srikrishna Jewellers ','Sodepur','Thakur Corner Marcket','0','9830318457',1,500,10000,0,1,NULL,1,1,'SJ',10),('S15','Bhukta Jewellers Pvt. Ltd','M/s Bhukta Jewellers Pvt. Ltd','Shyambazar','137/1a , Bidhan Sarani','700004','9331033686 ',1,500,5000,0.1,1,NULL,1,1,'BJPL',10),('S150','Nilima Guinea Palace','M/s Nilima Guinea Palace','Tamluk','Sanakarara , Purba Midnapore','0','9609226794 , 9800519885',1,500,5000,0,1,NULL,1,1,'NGP',10),('S151','Alankar Jewellers','M/s Alankar Jewellers','Bangaon','Bangaon','0','9733901247',1,500,5000,0,1,NULL,1,1,'AJ',10),('S152','New Singha Jewellers','M/s New Singha Jewellers','Bangaon','Bangaon','0','9434102135',1,500,5000,0,1,NULL,1,1,'NSJ',10),('S153','Arati Jewellers','M/s Arati Jewellers','Bangaon','Hira Mahal Lane','0','9332245939',1,500,5000,0,1,NULL,1,1,'AJ',10),('S154','Laxmi Jewellers (Bangaon)','M/s Laxmi Jewellers','Bangaon','Bangaon','0','99326114744',1,500,5000,0,1,NULL,1,1,'LJ',10),('S155','Motiganj Singha Jewellers','M/s Motiganj Singha Jewellers','Bangaon','Bagdha Road','0','321-5257177 , 9735412009',1,500,5000,0,1,NULL,1,1,'MSJ',10),('S156','Matadi Jewellers','M/s Matadi Jewellers','Jodhpur','1/421 , Jodhpur Park ','700068','2483-8416 , 2351-0796',1,500,5000,0.2,1,NULL,1,1,'MJ',10),('S157','Dacca Jewellery House','M/s Dacca Jewellery House','Gariahut','Gariahut Chowmatha','0','9874173050',1,500,5000,0.2,1,NULL,1,1,'DJH',10),('S158','Erika Jewellers','M/s Erika Jewellers','Gariahut','South Kolkata , Dhakuria Busstop','700031','2414-4156',1,500,5000,0,1,NULL,1,1,'EJ',10),('S159','Sri Dhirendra Nath Dutta Jewellers Pvt. Ltd','M/s Sri Dhirendra Nath Dutta Jewellers Pvt. Ltd','Katwa','Katwa','0','3453-255068 , 9732293590',1,500,5000,0,1,NULL,1,1,'SDNDJPL',10),('S16','K.B. Paul Jewellers','M/s K.B. Paul Jewellers','Srirampur','109, N S Avenue, Sreerampur','0','7003202927',1,50,5000,0,1,NULL,1,1,'KBPJ',10),('S160','Dhar Jewellery Mansion','M/s Dhar Jewellery Mansion','Hind Motor','Hind Motor','0','9831580889',1,500,5000,0,1,NULL,1,1,'DJM',10),('S161','P .C Jewellers ','M/s P .C Jewellers ','Katwa','Katwa','0','9832113385 ,9333611026',1,500,5000,0,1,NULL,1,1,'P.J',10),('S162','Priyo Jewellery Palace','M/s Priyo Jewellery Palace','Laketown','Laketown','0','33-24221620',1,500,5000,0,1,NULL,1,1,'PJP',10),('S163','D. S Debnath Jewellers','M/s D. S Debnath Jewellers','Sonarpur','Sonarpur','0','9088516383 , 24340180',1,500,5000,0.05,1,NULL,1,1,'DSDJ',10),('S164','Modern Guinea Mansion','M/s Modern Guinea Mansion','Kobordanga','Kobordanga , Tollygunj Road','0','33-24637739 , 24383068',1,500,5000,0,1,NULL,1,1,'MGM',10),('S165','Raj Jewellers','M/s Raj Jewellers','Bandle','Bandle Station Road','0','8100805482',1,500,5000,0,1,NULL,1,1,'RJ',10),('S166','Singha Jewellers (Khoka)','M/s Singha Jewellers ','Barrackpore','Barrackpore Station Road , Opp Sbi','0','9830310524',1,500,5000,0,1,NULL,1,1,'SJ(',10),('S167','New Khulna Art ','M/s New Khulna Art ','Barrackpore','Wireless Para ','0','9831236195',1,500,5000,0,1,NULL,1,1,'NKA',10),('S168','Lokenath Jewellers','M/s Lokenath Jewellers','Chinsurah','Chinsurah','0','9833466079',1,500,5000,0,1,NULL,1,1,'LJ',10),('S169','Radharani Jewellers','M/s Radharani Jewellers','Ichapore','Ichapore ','0','9748188283 , 33-25948704',1,500,5000,0,1,NULL,1,1,'RJ',10),('S17','Kalika Prasad Gold','M/s Kalika Prasad Gold','Howrah','Tram Dipo More , Shibpur','0','9831016302 ',1,500,5000,0,1,NULL,1,1,'KPG',10),('S170','Ashirbad Jewellers','M/s Ashirbad Jewellers','Jagaddal','Jagaddal','0','9339369848',1,500,5000,0,1,NULL,1,1,'AJ',10),('S171','New Mathura Prasad Jewellers','M/s New Mathura Prasad Jewellers','Kanchrapara','74/a Station Road , Bagmore','0','33-25856659 ',1,500,5000,0,1,NULL,1,1,'NMPJ',10),('S172','National Mathura Prasad Jewellers','M/s National Mathura Prasad Jewellers','Kancharapara','Kancharapara Workshop Road','0','33-25859373',1,500,5000,0.2,1,NULL,1,1,'NMPJ',10),('S173','New Barman Jewellers','M/s New Barman Jewellers','Kankinara','Kankinara','0','9331884549',1,500,5000,0,1,NULL,1,1,'NBJ',10),('S174','Gold Palace (Kankinara)','M/s Gold Palace ','Kankinara','Kankinara','0','8961651009',1,500,5000,0,1,NULL,1,1,'GP',10),('S175','Janaki Jewellers','M/s Janaki Jewellers','Kankinara','Kankinara','0','9433213060',1,500,5000,0,1,NULL,1,1,'JJ',10),('S176','Barman Jewellers','M/s Barman Jewellers','Kankinara','Kankinara','0','9874110602',1,500,5000,0,1,NULL,1,1,'BJ',10),('S177','Roy & Sons Jewellers','M/s Roy & Sons Jewellers','Shyamnagar','Shyamnagar','0','9836386318',1,500,5000,0,1,NULL,1,1,'R&SJ',10),('S178','New Tara Maa Jewellers','M/s New Tara Maa Jewellers','Shyamnagar','Shyamnagar','0','9433191466 , 9051323040',1,500,5000,0,1,NULL,1,1,'NTMJ',10),('S179','Debnarayan Dhar and Jewellers','M/S Debnarayan Dhar and Jewellers','Katwa','Dhar Market, Kanchari Road, Katwa, Bardhaman','0','9434546464, 8389943246, 8',1,500,5000,0,1,NULL,1,1,'DDJ',10),('S18','Jewell Garden','M/s Jewell Garden','Howrah','G . T Road , Shibpur','0','7890279964 , 26371115',1,500,5000,0,1,NULL,1,1,'JG',10),('S180','Srikrishna Jewellers (Baduria)','M/s Srikrishna Jewellers','Baduria','Baduria, South 24 Pgs','0','9903652244',1,5000,50000,0.05,1,NULL,1,1,'MJ',10),('S181','Gourav Jewellers','M/s Gourav Jewellers','Shyamnagar','Shyamnagar','0','90883228167',1,500,5000,0,1,NULL,1,1,'GJ',10),('S182','N. P Jewellers','M/s N. P Jewellers','Titagarh','Titagarh','0','9339568587',1,500,5000,0,1,NULL,1,1,'NPJ',10),('S183','Laxmi Jewellers (Titagarh)','M/s Laxmi Jewellers ','Titagarh','Titagarh','0','9831084080',1,500,5000,0,1,NULL,1,1,'LJ',10),('S184','Mondol Jewellers','M/s Mondol Jewellers','Arambagh','Gourhati More , Bazar Road','0','9438503923 , 9153058299',1,500,5000,0,1,NULL,1,1,'MJ',10),('S185','Pelaram Jewellers','M/s Pelaram Jewellers','Bankura ','Lalbazar , Machantala ','0','9476212830 , 9748536947',1,500,5000,0,1,NULL,1,1,'PJ',10),('S186','Uttara Jewellers','M/s Uttara Jewellers','Barasat','32/2/1 K.B. Basu road , Kol -124','700126','9330481556',1,500,5000,0,1,NULL,1,1,'UJ',10),('S187','Dutta Jewellers Pvt. Ltd','M/s Dutta Jewellers Pvt. Ltd','Kalna','Sonapotti , Ambika Kalna , Burdawn','0','9264798157',1,500,5000,0,1,NULL,1,1,'DJPL',10),('S188','Roy Jewellery Palace','M/s Roy Jewellery Palace','Barrackpore','Near Barrackpore Station Road , Ganja Goli','0','25927047 , 9831000171',1,500,5000,0,1,NULL,1,1,'RJP',10),('S189','Adi Singha Jewellers','M/s Adi Singha Jewellers','Barrackpore','Central Road, Barrackpore','0','7003115370',1,50,5000,0,1,NULL,1,1,'ASJ',10),('S19','Dhar Jewellers','M/s Dhar Jewellers','Shyambazar','Vivekananda Park , Hedhua ,Bidhan Sarani ','0','22410549',1,500,5000,0,1,NULL,1,1,'DJ',10),('S190','P . C Jewellers (Bashirhut)','M/s P . C Jewellers ','Bashirhut','Bashirhut','0','9434116298',1,500,5000,0,1,NULL,1,1,'P.CJ',10),('S191','Shantisree Gini palace','M/s Shantisree Gini palace','Howrah','144, Narashingha Dutta Road, Kadamtala','711101','9830145619',1,50,5000,0,1,NULL,1,1,'FJ',10),('S192','Kalimata Jewellers','M/S Kalimata Jewellers','Shyamnagar','Nehru Market, Shyamnagar, 24 Parganas','0','9831929403',1,500,5000,0,1,NULL,1,1,'KJ',10),('S193','Monihar Jewellers','M/s Monihar Jewellers','Behala','Dimond Hurber Road','0','33-23983550 ',1,500,5000,0,1,NULL,1,1,'MJ',10),('S194','N. Das & Sons  Jewellers','M/s N. Das & Sons  Jewellers','Kanchrapara','16 Workshop Road, North 24 Parganas','0','9830503549',1,500,5000,0,1,NULL,1,1,'NDSJ',10),('S195','Promit Jewellers','M/s Promit Jewellers','Behala','Behala','0','0000000',1,500,5000,0,1,NULL,1,1,'PJ',10),('S196','New Modern Dutta Jewellers','M/s New Modern Dutta Jewellers','Beharampore','Khagra More','0','9475020403 , 348-2256544',1,500,5000,0,1,NULL,1,1,'NMDJ',10),('S197','Sandhya Gold Jewellers','M/s Sandhya Gold Jewellers','Bhawanipur','Ashutosh Mukharjee Road','0','33-65010066',1,500,5000,0.1,1,NULL,1,1,'SGJ',10),('S198','Nirodh Kumar Das','M/s Nirodh Kumar Das','Bhawanipur','Chowrangee Road ','0','33-22478497 , 9831034024',1,500,5000,0,1,NULL,1,1,'NKD',10),('S199','Biswanath Jewellers','M/s Biswanath Jewellers','Baruipore','Baripure Station Road, Near Kalitala','0','03324338747, 9007773474',1,500,5000,0,1,NULL,1,1,'DBJ',10),('S2','Bachaspati Guinea Bhavan','M/s Bachaspati Guinea Bhavan','Baruipur','Kachari Bazar','0','9239109717,64538623',1,500,5000,0,1,NULL,1,1,'BGB',10),('S20','Satyam Shivam Sundaram Jewellers','M/s Satyam Shivam Sundaram Jewellers','Shyambazar','Sukhia Street , Manikatala','0','9830105557 , 23542366',1,500,5000,0,1,NULL,1,1,'SSSJ',10),('S200','Pyne Brothers Jewellers','M/s Pyne Brothers Jewellers','Bhawanipur','Bhawanipur','0','33-2455774',1,500,5000,0,1,NULL,1,1,'PBJ',10),('S201','G . C Day Jewellery House','M/s G . C Day Jewellery House','Bhawanipur','Bhawanipur','0','9831039490',1,500,5000,0,1,NULL,1,1,'G.CDJH',10),('S202','Dutta Guinea Palace (Bowbazar)','M/s Dutta Guinea Palace ','Bowbazar','191/2 Bipin Bihari Ganguly Street , Near Bank Of India More','700012','9831950710',1,500,5000,0,1,NULL,1,1,'DGP(',10),('S203','Srodhanjoli Jewellers (Chakdaha)','M/s Srodhanjoli Jewellers ','Chakdaha','C . B Road , Lalpur','0','9734786705',1,500,5000,0,1,NULL,1,1,'SJ(',10),('S204','Royco Jewellers','M/s Royco Jewellers','Chandannagar','Chandannagar','0','9830956569',1,500,5000,0,1,NULL,1,1,'RJ',10),('S205','New Podder Jewellers','M/s New podderJewellers','Barrackpore','102 (77/A/A) J R R Road, East Kalianibas','700122','9062344050',1,50,5000,0,1,NULL,1,1,'NPJ',10),('S206','New P . Chandra Jewellers','M/s New P . Chandra Jewellers','Dumdum ','Cantonment ','0','9836786560',1,500,5000,0,1,NULL,1,1,'NP.CJ',10),('S207','S. K. Jewellers ','M/s  S. K. Jewellers ','Krishnanagar','Sonapatti','0','34000000',1,500,5000,0,1,NULL,1,1,'CJ(',10),('S208','New Gouri Jewellers','M/s New Gouri Jewellers','Barasat','50/A Pionear Park','700124','9231642617',1,50,5000,0,1,NULL,1,1,'NGJ',10),('S209','Radha Rani Jewellers','M/s Radha Rani Jewellers','Barrackpore','Harisava Road','700122','9875369125',1,500,5000,0,1,NULL,1,1,'RRJ',10),('S21','Fashion Jewellers','M/s Fashion Jewellers','Shyambazar','Bidhan Sarani ,Hatibagan','0','25555147',1,500,5000,0.15,1,NULL,1,1,'FJ',10),('S210','Dharco Jewellers','M/s Dharco Jewellers','Hindmotor','Hindmotor','0','9836690573',1,500,5000,0,1,NULL,1,1,'DJ',10),('S211','Swarnanjali Jewellers','M/s Swarnanjali Jewellers','Gariahut','Golpark','0','9051844133 , 24600147',1,500,5000,0,1,NULL,1,1,'SJ',10),('S212','New Anukul Jewellers','M/s New Anukul Jewellers','Haroa','Haroa','0','321-7248397 , 9143118831',1,500,5000,0,1,NULL,1,1,'NAJ',10),('S213','Laxmi Narayan Jewellers','M/s Laxmi Narayan Jewellers','Rishra','31/a/1b , N K Bannerjee Charbati','0','9874334760',1,500,5000,0,1,NULL,1,1,'LNJ',10),('S214','New Radharani Jewellers','M/s New Radharani Jewellers','Ichapore','Ichapore Store Bazar ','0','0000000000',1,500,5000,0,1,NULL,1,1,'NRJ',10),('S215','Sandhya Gold Jewellers (Jadavpur)','M/s Sandhya Gold Jewellers ','Jadavpur','12a Jadavpur Station Road','700032','2412-6800 , 65555204',1,500,5000,0,1,NULL,1,1,'SGJ(',10),('S216','Swarnaniketan Jewellers ','M/s Swarnaniketan Jewellers','Shyamnagar','Shyamnagar','00000','9038684069',1,50,5000,0,1,NULL,1,1,'SJ',10),('S217','Sri Laxmi Narasingha Jewellers','M/s Sri Laxmi Narasingha Jewellers','Kharagpur','Kharagpur','0','7501926842',1,500,5000,0,1,NULL,1,1,'SLNJ',10),('S218','Sree Jeweller','M/s Sree Jeweller','Kharagpur','Kharagpur','0','9333296693',1,500,5000,0,1,NULL,1,1,'SJ',10),('S219','Das Jewellers (Kharagpur)','M/s Das Jewellers ','Kharagpur','Maloncho Bazar','0','9434205479',1,500,5000,0,1,NULL,1,1,'DJ',10),('S22','Manikanchan Jewellers Pvt. Ltd','M/s Manikanchan Jewellers Pvt. Ltd','Shyambazar','Bidhan Sarani , Hatibagan','0','9830327808',1,500,5000,0.2,1,NULL,1,1,'MJPL',10),('S220','Gold & Silvar','M/s Gold & Silvar','Kharagpur','Gole Bazar','0','9434008667 , 3222-255699',1,500,5000,0,1,NULL,1,1,'G&S',10),('S221','Hira Jewellers (Rajarhat )','M/s Hira Jewellers','Rajarhat','Rajarhat','0','000000',1,500,5000,0,1,NULL,1,1,'HJ',10),('S222','New Matri Jewellers','M/s New Matri Jewellers','Shyamnagar','Shyamnagar','0','0000000000',1,500,5000,0,1,NULL,1,1,'NMJ',10),('S223','Sonar Taree Jewellers','M/s Sonar Taree Jewellers','Madhyamgram','Madhyamgram Station Road','0','7685091560',1,500,5000,0,1,NULL,1,1,'STJ',10),('S224','Ram Thakur Jewellers','M/s Ram Thakur Jewellers','Madhyamgram','Madhyamgram','0','9804506476',1,500,5000,0,1,NULL,1,1,'RTJ',10),('S225','Swarnarupa Jewellers','M/s Swarnarupa Jewellers','Nabadwip ','Telipara','0','9332195251',1,500,5000,0,1,NULL,1,1,'SJ',10),('S226','Ria Jewellers','M/s Ria Jewellers','Kolkata','26/A 39 Mondal Para Lane','Kol-90','9830194883',1,50,5000,0,1,NULL,1,1,'RJ',10),('S227','Bharati Gold Corner','M/s Bharati Gold Corner','Ramrajatala','Bakultala Lane, ','0','9830877049',1,50,5000,0,1,NULL,1,1,'BGC',10),('S228','Sohani Jewellers','M/s Sohani Jewellers','Prativa Nagar','Prativa Nagar, South 24 Parganas','0','9167474025',1,500,5000,0,1,NULL,1,1,'SJ',10),('S229','Jee Narayan Jewellers','M/s Jee Narayan Jewellers','Howrah','93, G. T. Road, Op Sandhya Bazar Bus Stop','711101','9874393860/9007856933',1,50,5000,0,1,NULL,1,1,'JNJ',10),('S23','Rajlaxmi Guinea Mansion Jewellers','M/s Rajlaxmi Guinea Mansion Jewellers','Shyambazar','125/2 Bidhan Sarani','0','25548598',1,500,5000,0.05,1,NULL,1,1,'RGMJ',10),('S230','Kabita Das','M/s Kabita Das','Barrackpore','Barrackpore','0','9830288631',1,50,5000,0,1,NULL,1,1,'JMTJ',10),('S231','Bakshi Jewellers','M/S Bakshi Jewellers','Barasat','46, K.B. Basu Road','700124','8013242585',1,50,5000,0,1,NULL,1,1,'BJ',10),('S232','Subarna Shilpi Jewellers','M/s Subarna Shilpi Jewellers','Sonarpur','Sonarpur','0','9831796878',1,500,5000,0,1,NULL,1,1,'SSJ',10),('S233','Surovi Mansion Jewellers','M/s Surovi Mansion Jewellers','Sonarpur','Sonarpur','0','2434-9338',1,500,5000,0,1,NULL,1,1,'SMJ',10),('S234','G . C Day Jewellers','M/s G . C Day Jewellers','Tollygunge','Tollygunge','0','9830021962 , 33-24666871',1,500,5000,0,1,NULL,1,1,'G.CDJ',10),('S235','Howrah Jewellers','M/s Howrah Jewellers','Howrah','Howrah Maidan','0','9830280620 , 33-26411126',1,500,5000,0.2,1,NULL,1,1,'HJ',10),('S236','Maniratnam Jewellers','M/s Maniratnam Jewellers','Shyambazar','Bagbazar','0','9830233494',1,50,5000,0,1,NULL,1,1,'MJ',10),('S237','A . M Day Brothers Jewellers','M/s A . M Day Brothers Jewellers','Shyambazar','Bidhan Sarani Shyambazar','0','25550876',1,50,5000,0,1,NULL,1,1,'A.MDBJ',10),('S238','Bhabani Guine Palace','M/s Bhabani Guine Palace','Nimta','318 MB Road, Nimta','700049','9874222828',1,500,5000,0,1,NULL,1,1,'BGP',10),('S239','L. B Jewellers','M/s L. B Jewellers','Shyambazar','103 C Bidhan Sarani','700004','9830677454 , 25430715',1,50,5000,0,1,NULL,1,1,'LBJ',10),('S24','Ghosh Jewellers','M/s Ghosh Jewellers','Shyambazar','Bidhan Sarani , Hatibagan','0','9831125042',1,500,5000,0,1,NULL,1,1,'GJ',10),('S240','Anushka Jewellers (Andul)','M/s Anushka Jewellers ','Andul','Andul','0','9832148835',1,50,5000,0,1,NULL,1,1,'AJ',10),('S241','Anandamoyi Jewellers','M/s Anandamoi Jewellers','Howrah','1/2 Mahendra Bhattacharyya Road, Ghosh Para','Howra-4','9830945044',1,50,5000,0,1,NULL,1,1,'AJ',10),('S242','Narayan Jewellers','M/s Narayan  Jewellers','Titagarh','6 MG Road, Titagarh, Kolkata - 119','700119','6291134007',1,50,5000,0,1,NULL,1,1,'CJ&J',10),('S243','Sandhya Jewellers','M/s Sandhya Jewellers','Bhatpara','2nd No. East Ghosh Para road, North 24PGS','0','8910389106',1,50,5000,0,1,NULL,1,1,'PJ',10),('S244','Joy Anjali Jewellers','M/s Joy Anjali Jewellers','Shyamnagar','Shyamnagar','0','9836775642',1,50,5000,0,1,NULL,1,1,'JAJ',10),('S245','Provashon Jewellers','Provashon Jewellers','Balli','Balli','0','7890730977',1,50,5000,0,1,NULL,1,1,'PJ',10),('S246','G.M. Jewellers','M/s G.M. Jewellers','Bandle','Bandle Station Road','712123','9883349348',1,50,5000,0,1,NULL,1,1,'GMJ',10),('S247','Panchanan Roy & Co','M/s Panchanan Roy & Co','Sheorahphully','Sheorahphully','0','9874718657',1,50,5000,0,1,NULL,1,1,'PR&C',10),('S248','Poddar Jewellers (Barrackpore)','M/s Poddar Jewellers ','Barrackpore','Barrackpore','700122','9230833905',1,50,5000,0,1,NULL,1,1,'PJ',10),('S249','Subham Kundu','M/s Subham Kundu','Barrackpore','Barrackpore','0','7278636343',1,50,5000,0,1,NULL,1,1,'SJ',10),('S25','Namita Jewellery House','M/s Namita Jewellery House','Champahati','Champahati','0','9733501217',1,500,5000,0,1,NULL,1,1,'NJH',10),('S250','Radha Krishna Kewellers','M/s Radha Krishna Kewellers','Titagarh','Titagarh','0','9062646177',1,50,5000,0,1,NULL,1,1,'RKJ',10),('S251','Srikrishna Jewellers (Kankinara)','M/s Srikrishna Jewellers ','Kankinara','Kankinara','0','9331216859',1,500,10000,0,1,NULL,1,1,'SJ',10),('S252','Srikrishna Jewellery House','M/s Srikrishna Jewellery House','Barrackpore','Barrackpore','0','9831212600',1,500,10000,0,1,NULL,1,1,'SJH',10),('S253','Basanti Jewellery Mansion','M/s Basanti Jewellery Mansion','Singur','Singur','0','9433234869',1,50,5000,0,1,NULL,1,1,'BJM',10),('S254','Parul Jewellers (Singur)','M/s Parul Jewellers ','Singur','Singur','0','9062402308',1,50,5000,0,1,NULL,1,1,'PJ',10),('S255','M . N Jewellers','M/s M . N Jewellers','Rishra','Rishra','0','9231889012',1,50,5000,0,1,NULL,1,1,'M.NJ',10),('S256','Rajlaxmi Guinea Gold','M/s Rajlaxmi Guinea Gold','Behala','Behala Poura Panna Bithika , Shop No :7','0','9836135948 , 9804531322',1,50,5000,0,1,NULL,1,1,'RGG',10),('S257','Rajlaxmi Swarnalay (Kishore Da)','M/s Rajlaxmi Swarnalay','Behala','Behala','0','9836311506',1,100,5000,0,1,NULL,1,1,'RS',10),('S258','Srikrishna Jewellers (Sarisha)','M/S Srikrishna Jewellers','Sarisha','Ashram more, Sarisha','0000','9836057996',1,100,5000,0,1,NULL,1,1,'SJ',10),('S259','New Nandi Keswer Jewellers','M/S New Nandi Keswer Jewellers','Champahati','Champahati',NULL,'00000',1,500,5000,0,1,NULL,1,1,'NKJ',10),('S26','New Manikanchan Jewellers','M/s New Manikanchan Jewellers','Shyambazar','Bidhan Sarani , Hatibagan','0','65250298',1,500,5000,0.2,1,NULL,1,1,'NMJ',10),('s260','Ajanta Jewellers','M/S Ajanta Jewellers','Titagarh','S.V.Path','700119','9231962494/2501-2164',1,50,5000,0,1,NULL,1,1,'AJ',10),('S261','B N Paul James and Jewellers','M/S B N Paul James & Jewellers ','Katwa','Katwa, Goenka More, Najrul Market','0','7407023758/9732248858',1,500,5000,0,1,NULL,1,1,'BNP',10),('S262','Maa Manasha Jewellers',' Maa Manasha Jewellers','Madhyamgram','Sodepur Road, Kalibari','700129','9674979284/6290959585',1,50,5000,0,1,NULL,1,1,'MMJ',10),('S263','Manik Ch Pyne','Manik Ch Pyne','Shyambazar','Shyambazar','0','0000000000',1,50,5000,0,1,NULL,1,1,'MCP',10),('S264','Ramkrishna Jewellers','Ramkrishna Jewellers','Sodepur','Thakurkarnar Market','0','033-2563-2164',1,50,5000,0,1,NULL,1,1,'RJ',10),('S265','Chandra Palace Jewellers','Chandra Palace Jewellers','Aasnsol','77,g.t.road (Opp.subhas Cinema)','0','9832127232  , 9832260840',1,50,5000,0,1,NULL,1,1,'CPJ',10),('S266','Avishek Jewellers','AVISHEK JEWELLERS','Durgapur','Dr.b.c Roy Co-operative Service Society Ltd. Chandidas Market Durgapur -5','000000','9832110994, 9832854859',1,50,5000,0,1,NULL,1,1,'AJ',10),('S267','Jai Hind Jewellers','Jai hind jewellers','Burnpur','Shop B/21 Daily Market','713325','9933057277',1,50,5000,0,1,NULL,1,1,'JHJ',10),('S268','Purushottam Alankar','M/s Purushottam Alankar','Barrackpore','Mohanpur , Barrackpore ','700121','9088666888',1,1200,500000,0,1,NULL,1,1,'PA',10),('S269','Jewell Garden(asansol)','Jewell Garden','Asansol','Asansol','0000000000','9547067569',1,50,5000,0,1,NULL,1,1,'JG',10),('S27','Kalyan Jewellers','M/s Kalyan Jewellers','Bagnan','Bagnan','0','9734536835 , 3214266004',1,500,5000,0,1,NULL,1,1,'KJ',10),('S270','Mathura Prasad Jewellers','M/s Mathura Prasad Jewellers','Kanchrapara','45 Lelin Sarani , Pasupati Housing Complex, ','0000000000','9331980828 033 2585 2221',1,50,5000,0.1,1,NULL,1,1,'MPJ',10),('S271','Subham Jewellery House','Subham Jewellery House','Hooghly','23/6,g,t,road,sheoraphuli,hooghly','712223','9830220540       033 2632',1,50,5000,0,1,NULL,1,1,'SJH',10),('S272','M.k.jewellers','M.K.JEWELLERS','Hooghly','1/12 New G.t Road, Uttarpara,hooghly','000000','033 2664-0856',1,50,5000,0,1,NULL,1,1,'M',10),('S273','S.r Jewellers(bangaon)','S.r Jewellers','Bangaon','Bangaon','0','7076836806/03215-259415',1,50,5000,0,1,NULL,1,1,'SJ',10),('S274','G.d.jewellers','G.D.JEWELLERS','Bhawanipur','Bhawanipur','0000000','8910717164   9830120829',1,50,5000,0,1,NULL,1,1,'G',10),('S275','S. N .Gold','S. N .Gold','Goriahut','Golpark','0','9831037544',1,50,5000,0,1,NULL,1,1,'SNG',10),('S276','Debnath Silpa Mandir Jewellers','M/s Debnath Silpa Mandir Jewellers','Sonarpur','Sonarpur Bazar (Rice Market)','700150','9007126422 , 9748212143',1,50,5000,0,1,NULL,1,1,'DSMJ',10),('S277','Laxmi Jewellers(tollygung)','M/s Laxmi Jewellers','Tollygung','Rashbihari ,Tollygunge','0','33-24668150',1,50,5000,0,1,NULL,1,1,'LJ',10),('S278','Roy Jewellery Mansion','Roy Jewellery Mansion','Shyambazar','139b,bidhan Sarani,(hatibagan)','700004','9830246470',1,50,5000,0,1,NULL,1,1,'RJM',10),('S279','Bakshi & Company Jeweller','Bakshi & Company Jeweller','Kolkata','E-7 Gitanjali Park,ariadaha,p.s-belghoria','700057','033 2544-4922           8',1,50,5000,0,1,NULL,1,1,'B&CJ',10),('S28','Laxmi Jewellers','M/s Laxmi Jewellers','Bagnan','Bagnan','0','9933031271',1,500,5000,0,1,NULL,1,1,'LJ',10),('S280','Jatindranath Dutta Jewellers Pvt.ltd','JATINDRANATH DUTTA JEWELLERS PVT.LTD','Bakhrahat','Nibaran Dutta Road Bakhrahat South 24 Parganas','743377','9831071349',1,100,10000,0.05,1,NULL,1,1,'JDJP',10),('S281','Milan Ghosh','M/S Milan Ghosh','Barrackpore','Barrackpore','700121','9681817840',1,50,5000,0,1,NULL,1,1,'AD',10),('S282','Anupam Rakshit','Anupam Rakshit','Barrackpore','Barrackpore','700121','7278834919',1,50,5000,0,1,NULL,1,1,'RD',10),('S283','Arati Jewellers(barisha)','Arati Jewellers(Barisha)','Kolkata','82,diamond Harbour Road (Opp.barisha Barabari),','700008','7980760667   9230401366',1,50,5000,0,1,NULL,1,1,'AJ',10),('S284','V.k.jewellers(Krishnapur)','V.K. JEWELLERS','Kolkata','Bd-46,krishnapur,near-frank Rosspharmacy','700101','8335023425',1,50,5000,0.1,1,NULL,1,1,'V',10),('S285','Raj Ratan Jewellers','Raj Ratan Jewellers','Durgapur','Benachity,nachan Road,durgapur','Durgapur-13','9434804153',1,50,5000,0.2,1,NULL,1,1,'RRJ',10),('S286','New Rupam Jewellers','New Rupam Jewellers','Egra','Dainik Bazar Egra','721429','9733058200',1,50,5000,0,1,NULL,1,1,'NRJ',10),('S287','Bile Da','Mr. Bile Da','Barrackpore','Sewli, Telinipara, Barrackpoe,North 24 PGS kol-121','700121','033-2535-2222',1,5000000,500000000,0.1,1,NULL,1,1,'BD',10),('S288','Poddar Ornaments','M/s Poddar Ornaments','Durgapore','Durga Mandir Road, Benachity','713213','9734761332',1,50,5000,0,1,NULL,1,1,'PO',10),('S289','Usha Jewellers','M/s Usha Jewellers','Assam','A.T.Road, Moranhat , Usha Bhavan , Opp police Station Dibrugarh','785675','7002237269,7002955455',1,500,5000,0,1,NULL,1,1,'UJ',10),('S29','Maa Annapurna Jewellers','M/s Maa Annapurna Jewellers','Bagnan','Bagnan ','0','9232560246',1,500,5000,0,1,NULL,1,1,'MAJ',10),('S291','Raja Jewellers','M/S Raja Jewellers','North 24 Pgs','Kalibari Road , Shyamnagar','0000','7003363376',1,50,5000,0,1,NULL,1,1,'RJ',10),('S292','R.chandra & Sons','M/S R.chandra & Sons','Kancharapara','77,kancharapara, Workshop Road N24(pgs)','0000','9681438283',1,50,5000,0.05,1,NULL,1,1,'R&S',10),('S293','Susanta Jewellers','M/S Susanta Jewellers','Belgharia','Belgharia Busstand , Nimta','0000','8017504202',1,50,5000,0,1,NULL,1,1,'SJ',10),('S294','Sayan Jewellers','M/S Sayan Jewellers','Kancharapara','71b, Kali Biswas Road , Chandmari Road , North 24pgs','000000','9143678985',1,50,5000,0,1,NULL,1,1,'SJ',10),('S295','Protussa Jewellers','M/S Protussa Jewellers','Howrah','7/10, Kasundia 2nd By Lane,near Taltala Club','4','9007148480 , 7687909401',1,50,5000,0,1,NULL,1,1,'PJ',10),('S296','Anup Paul (Barasat)','M/S Anup Paul (Barasat)','Barasat','Barasat','0000000000','7439863638',1,50,5000,0,1,NULL,1,1,'AP',10),('S297','Ankan Jewellers','M/S Ankan Jewellers','Konnogar','334, Criper Road, Indira Ghandhi Road , Hooghly','0000','9748165712',1,50,5000,0,1,NULL,1,1,'AJ',10),('S298','Rco G-o-l-d Jewellers','M/S Rco G-o-l-d Jewellers','Rajarhat','Rajarhat , (211 Bus Stand), Bibhuti Market','700135','9874841883 , 25734030',1,50,5000,0,1,NULL,1,1,'RGJ',10),('S299','Matri Jewellery Palace','Matri Jewellery Palace','Kolkat','45/21, Beleghata Main Road','700010','9831430374',1,50,5000,0,1,NULL,1,1,'MJP',10),('S3','Dacca Jewellers Pvt. Ltd.','M/s Dacca Jewellers Pvt. Ltd.','Sirumpur','Sirumpur','0','9836999588,03326521315',1,500,5000,0.05,1,NULL,1,1,'DJPL',10),('S30','Banik Jewellers','M/s Banik Jewellers','Badyabati','Badyabati','0','9433436880',1,500,5000,0,1,NULL,1,1,'BJ',10),('S300','Kanak Jewellers','M/S Kanak Jewellers','Birati','586, M.b.road, Birati Collage More','700051','7003491939,9836720640',1,50,5000,0,1,NULL,1,1,'KJ',10),('S301','Devi Jewellers','M/s Devi Jewellers','Uttor Para','Uttor Para, Hoogly','000000','7003520537',1,50,5000,0,1,NULL,1,1,'DJ',10),('S302','Sudama Gold','M/s Sudama Gold','Kolkata','1 Mirbahar  Ghat Street, Sona Potty','700007','7686886298',1,50,5000,0,1,NULL,1,1,'SG',10),('S303','New Mira Jewellers','M/s New Mira Jewellers','Sodepur','Barasat Road, Under Lici Building, Sodepur','700110','8697208815',1,50,5000,0,1,NULL,1,1,'NMJ',10),('S304','Sandhya Jewellery','M/s Sandhya Jewellery','Sodepur','B27, B30 Thakur Corner Market, Sodepur','700114','9830472463, 9143281456',1,50,5000,0,1,NULL,1,1,'SJ',10),('S305','Maa Durga Jewellers','M/s Maa Durga Jewellers','Mahesh','3 B, Rose Para Lane','000000','9331202681',1,50,5000,0,1,NULL,1,1,'MDJ',10),('S306','Kanak Jewellery Palace','M/s Kanak Jewellery Palace','Titagarh','S.v. Path. Near Kinnison Jute Mill Gate ','0000000','2501-0095, 8585866419',1,50,5000,0,1,NULL,1,1,'KJP',10),('S307','Mp Gold Aamtala','Mp Gold','Aamtala','Aamtala Mdina Market','000000','8013714398',1,50,5000,0,1,NULL,1,1,'MG',10),('S308','Monikanchan Jewellers Rishra','Monikanchan Jewellers','Morepukur','68a, K. C. Sen Road, Morepukur','00000','8334879613',1,50,5000,0,1,NULL,1,1,'MJ',10),('S309','Ananda Jewellers','Ananda Jewellers','Bagihati','Eb-10, Deshbandhu Nagar, Baguhati','700069','9674159470',1,50,5000,0,1,NULL,1,1,'AJ',10),('S31','Mr Vivekananda Ghosh','M/s Mr Vivekananda Ghosh','Barrackpore','Sewli , Telenipara','700121','9836444999',1,500,5000,0,1,NULL,1,1,'MVG',10),('S310','P.p Jewellers','P.p Jewellers','Baguhati','Ba-13, Deshbandhu Nagar, Baguhati','700059','9830225113',1,50,5000,0,1,NULL,1,1,'PJ',10),('S311','Arabinda Karmakar','Arabinda Karmakar','Barrackpore','Barrackpore','700121','7003624023',1,50,5000,0,1,NULL,1,1,'AK',10),('S312','Samiran Majumder','Samiran Majumder','Barrackpore','Barrackpore','700123','9874741247',1,50,5000,0,1,NULL,1,1,'SM',10),('S313','Surajit Dhara','Surajit Dhara','Barrackpore','Barrackpore','700122','9674875597',1,50,5000,0,1,NULL,1,1,'SD',10),('S314','Arindam Biswas','Arindam Biswas','Barrackpore','Barrackpore','700121','7003031560',1,50,5000,0,1,NULL,1,1,'AB',10),('S315','Sidhartha Dhara','Sidhartha Dhara','Barrackpore','Barrackpore','700121','7003999148',1,50,5000,0,1,NULL,1,1,'SD',10),('S316','Suman Ghosh','Suman Ghosh','Barrackpore','Barrackpore','700121','7044932908',1,50,5000,0,1,NULL,1,1,'SG',10),('S317','Sonali Mansion','M/s Sonali Mansion','Baruipore','Baruipur Kachari Bari','700144','9831518662',1,50,5000,0,1,NULL,1,1,'SM',10),('S318','Maity Jewellers','Maity Jewellers','Kolkata','Boubazar, Robin Chand Lane','0000000','9831712559',1,50,5000,0,1,NULL,1,1,'MJ',10),('S319','Bakshi & Co.','M/s Bakshi & Co.','Belghoriya','Belghariya','700056','8017178229',1,50,5000,0,1,NULL,1,1,'B&C',10),('S32','New Sree Dhar Jewellers','M/s New Sree Dhar Jewellers','Behala','Behala','0','9674439870',1,500,5000,0,1,NULL,1,1,'NSDJ',10),('S320','New Naskar Jewellers','M/s New Naskar Jewellers','Sirakole','Sirakole, Usthi Road','743503','8330632442',1,50,5000,0,1,NULL,1,1,'NNJ',10),('S321','Samanta Guini Palace & Sons','M/s Samanta Guini Palace & Sons','Howra','Amtala, M Pondit Market','705345','9836809030',1,50,5000,0,1,NULL,1,1,'SGP&S',10),('S322','Arindam Ghosh','M/s Arindam Ghosh','Barrackpore','Barrackpore','700122','8697888515',1,50,5000,0,1,NULL,1,1,'AG',10),('S323','R. P. Jewellers','M/s R. P. Jewellers','Barrackpore','Jaffarpore, Barrackpore','700122','0000000',1,50,5000,0,1,NULL,1,1,'RPJ',10),('S33','Rajlaxmi Shilpalaya Jewellers','M/s Rajlaxmi Shilpalaya Jewellers','Behala','Behala','0','23979197',1,500,5000,0,1,NULL,1,1,'RSJ',10),('S34','G. Rakshit Jewellers & Sons','M/s G. Rakshit Jewellers & Sons','Domjur','South Jhapordah Jelapara, Howrah','0','26700180/9830382790',1,50,5000,0,1,NULL,1,1,'GRJ',10),('S35','Parashmani Jewellers','M/s Parashmani Jewellers','Behala','Behala','0','9432181461 , 23986787',1,500,5000,0.05,1,NULL,1,1,'PJ',10),('S36','Tirupati Gold House','M/s Tirupati Gold House','Behala','264 Diamond Hurber Road','0','23491168 , 24071168',1,500,5000,0.2,1,NULL,1,1,'TGH',10),('S37','P . C Dutta Jewellers Pvt. Ltd','M/s P . C Dutta Jewellers Pvt. Ltd','Behala','248/D.H Road Kol - 60','0','9874278020 , 23965050',1,500,5000,0,1,NULL,1,1,'P.CDJPL',10),('S38','Rajlaxmi Swarnamahal Jewellers','M/s Rajlaxmi Swarnamahal Jewellers','Behala','522 Diamond harbour Roaad, Kolkata 34','0','9830177726,8017299322',1,500,5000,0.2,1,NULL,1,1,'RSJ',10),('S39','M.R. Jewellers','M/s M.R. Jewellers','Rajarhut','Kohinur Market, North 24 Parganas','0','9830156731/9830156731',1,500,5000,0,1,NULL,1,1,'MRJ',10),('S4','M. Dutta & Sons','M/s M. Dutta & Sons','Amtala','Kanyanagar','0','9830908166,24709213',1,500,5000,0,1,NULL,1,1,'MDS',10),('S40','A . M Jewellers','M/s A . M Jewellers','Howrah','Howrah','0','26434323',1,500,5000,0,1,NULL,1,1,'A.MJ',10),('S41','Swarna Kuthir Jewellers','M/s Swarna Kuthir Jewellers','Konnogor','Konnogor','0','8981740798',1,500,5000,0,1,NULL,1,1,'SKJ',10),('S42','R . C Jewellers','M/s R . C Jewellers','Konnogor','Konnogor','0','9433488104 , 9681253071',1,500,5000,0,1,NULL,1,1,'R.CJ',10),('S43','Gold Palace','M/s Gold Palace','Konnogor','Konnogor','0','8420099889',1,500,5000,0,1,NULL,1,1,'GP',10),('S44','New R . A Jewellery House','M/s New R . A Jewellery House','Rajarhut','Rajarhut , Chowmatha','700135','9038513522 , 9836004590',1,500,5000,0,1,NULL,1,1,'NR.AJH',10),('S45','Shaikh Co Jewellers','M/s Shaikh Co Jewellers','Rajarhut','Rajarhut','0','9674127989',1,500,5000,0,1,NULL,1,1,'SCJ',10),('S46','Das Jewellers(dipak Da)','M/s Das Jewellers','Ramrajatala','Subhachanditala','0','9830892030',1,500,5000,0,1,NULL,1,1,'DJD',10),('S47','Das Jewellers (Suman Da)','M/s Das Jewellers ','Ramrajatala','Subhachanditala','0','9830417341',1,500,5000,0,1,NULL,1,1,'DJ(D',10),('S48','New Samanta Jewellers','M/s New Samanta Jewellers','Ramrajatala','Mani Hori Road ','0','9836621060',1,500,5000,0,1,NULL,1,1,'NSJ',10),('S49','Kalyaneswari Jewellers','M/s Kalyaneswari Jewellers','Ramrajatala','Ramrajatala','0','9830312516 , 26573796',1,500,5000,0,1,NULL,1,1,'KJ',10),('S5','Jatindra Nath Dutta Jewellers','M/s Jatindra Nath Dutta Jewellers','Amtala','Nibaron Dutta Road','0','24709212',1,500,5000,0.2,1,NULL,1,1,'JNDJ',10),('S50','M . D Nath & Others Jewellers','M/s M . D Nath & Others Jewellers','Ramrajatala','Ramsaranseth Road','0','3326272739 ',1,500,5000,0,1,NULL,1,1,'MDNOJ',10),('S51','Anushka Jewellers','M/s Anushka Jewellers','Ramrajatala','Ramrajatala','0','9804151712',1,500,5000,0,1,NULL,1,1,'AJ',10),('S52','Bera Jewellery Palace','M/s Bera Jewellery Palace','Ramrajatala','Ramrajatala','0','9051998543 , 26270719',1,500,5000,0.2,1,NULL,1,1,'BJP',10),('S53','Tilottama Guinea Palace','M/s Tilottama Guinea Palace','Ramrajatala','Ramcharan Sett Road','0','9836770526',1,500,5000,0,1,NULL,1,1,'TGP',10),('S54','Laxmi Gold','M/s Laxmi Gold','Rishra','29a/1 S N Govt . Colony More Pukur','0','8902272318',1,500,5000,0.05,1,NULL,1,1,'LG',10),('S55','Gahana','M/s Gahana','Domjur','Jilaporisad building, Domjur Annyapurna More','00000','9830327384/9831614867',1,50,5000,0,1,NULL,1,1,'G',10),('S56','Shyamashree Jewellers','M/s Shyamashree Jewellers','Sheoraphully','Sheoraphully','0','8276003092',1,500,5000,0,1,NULL,1,1,'SJ',10),('S57','Srodhanjoli Jewellers','M/s Srodhanjoli Jewellers','Baidyabati','Baidyabati','0','9831678090 , 9734786705',1,500,5000,0,1,NULL,1,1,'SJ',10),('S58','New Gold Queen Jewellers','M/s New Gold Queen Jewellers','Sirumpur','Sirumpur','0','9143048365 , 26624524',1,500,5000,0,1,NULL,1,1,'NGQJ',10),('S59','New B . M Jewellers','M/s New B . M Jewellers','Sirumpur','Mahesh','0','9433290413',1,500,5000,0,1,NULL,1,1,'NB.MJ',10),('S6','Binapani Jewellers','M/s Binapani Jewellers','Amtala','Rajarhut , Shirakole','0','9830799395',1,500,5000,0,1,NULL,1,1,'BJ',10),('S60','Nihar Jewellers','M/s Nihar Jewellers','Kolkata','Kolkata','0','03324608786,9903214752',1,500,5000,0,1,NULL,1,1,'NJ',10),('S61','Rajlakhsmi Jewellery House','M/s Rajlakhsmi Jewellery House','Dum Dum','Nager Bazar','0','0',1,500,5000,0,1,NULL,1,1,'RJ',10),('S62','The M . N  Jewellers','M/s New M . N  Jewellers','Sirumpur','Sirumpur','0','7044171504',1,500,5000,0,1,NULL,1,1,'NM.NJ',10),('S63','Fancy Jewellers','M/s Fancy Jewellers','Sirumpur','582, G. T. Road, Maniktala, Sirampore','0','9830070360',1,50,5000,0,1,NULL,1,1,'FJ',10),('S64','The New Gold Queen ','M/s The New Gold Queen ','Uttarpara','Uttarpara','0','8902250538',1,500,5000,0,1,NULL,1,1,'TNGQ',10),('S65','Ginico Jewellers','M/s Ginico Jewellers','Alambazar','Tantipara , Baranagar','0','8420741463',1,500,5000,0.15,1,NULL,1,1,'GJ',10),('S66','Das Jewellers','M/s Das Jewellers','Alambazar','Tantipara , Baranagar','0','9831526285',1,500,5000,0,1,NULL,1,1,'DJ',10),('S67','Promila Jewellers','M/s Promila Jewellers','Baruipur','Kachari Bazar','0','9830215916',1,500,5000,0,1,NULL,1,1,'PJ',10),('S68','Poddar Jewellers','M/s Poddar Jewellers','Baruipur','Kachari Bazar','0','9433096790 , 24338615',1,500,5000,0,1,NULL,1,1,'PJ',10),('S69','Lila Bachuspati Jewellers','M/s Lila Bachaspati Jewellers','Baruipur','Kachari Bazar','0','24330710',1,500,5000,0.2,1,NULL,1,1,'LBJ',10),('S7','A. K Dutta & Sons','M/s A. K Dutta & Sons','Amtala','Nibaron Dutta Road','0','24809686,9831071349',1,500,5000,0,1,NULL,1,1,'AKDS',10),('S70','Dutta Jewellers','M/s Dutta Jewellers','Baruipur','Padma Pukur , Kulpi Road','0','9830343668 ,  24331638',1,500,5000,0.1,1,NULL,1,1,'DJ',10),('S71','The Promila Guinea Mansion ','M/s The Promila Guinea Mansion ','Baruipur','Kachari Bazar','0','9836468719 , 9051083911',1,500,5000,0.05,1,NULL,1,1,'TPGM',10),('S72','D . K Jewellers','M/s D . K Jewellers','Belgharia','Nilganj Road , Near Bibha Cinema Hall','0','25635878 , 9874242788',1,500,5000,0.2,1,NULL,1,1,'D.KJ',10),('S73','Maa Shitala Jewellers','M/s Maa Shitala Jewellers','Mahesh','451/A GT Road, Hooghly','0','9051918010/7044762099',1,500,5000,0,1,NULL,1,1,'MS',10),('S74','New Rajlakhsmi Jewellers','M/s New Rajlakhsmi Jewellers','Barrackpore','Barasat Road','Kol - 126','9231661547, 8617278400',1,500,5000,0,1,NULL,1,1,'NRJ',10),('S75','The Modern Guinea Palce','M/s The Modern Guinea Palce','Belgharia','Belgharia','0','9830482307',1,500,5000,0.1,1,NULL,1,1,'TMGP',10),('S76','Modern Jewellers','M/s Modern Jewellers','Belgharia','Belgharia','0','9830196456',1,500,5000,0.2,1,NULL,1,1,'MJ',10),('S77','Bijoy Bachaspati Jewellers','M/s Bijoy Bachaspati Jewellers','Champahati','Champahati','0','9883343333',1,500,5000,0.1,1,NULL,1,1,'BBJ',10),('S78','Raj Lakshmi Jewellers','M/s Raj Lakshmi Jewellers','Contai','Purba ,Midnapore','0','0320255356,256471',1,500,5000,0,1,NULL,1,1,'RLJ',10),('S79','Rupam Jewellers','M/s Rupam Jewellers','Contai','Kanthi','0','9002520861,255498',1,500,5000,0.1,1,NULL,1,1,'RJ',10),('S8','Srikrishna Jewellers','M/s Srikrishna Jewellers','Amtala','Rajarhut , Shirakole','0','9874693591',1,500,10000,0.2,1,NULL,1,1,'SJ',10),('S80','Gold House','M/s Gold House','Contai','Contai Post Ofice Bazar.purba Midnapore','0','8820883267',1,500,5000,0,1,NULL,1,1,'GH',10),('S81','Sarada Jewellers','M/s Sarada Jewellers','Dumdum','Nagerbazar,','0','9433171725',1,500,5000,0.2,1,NULL,1,1,'SJ',10),('S82','H . Roy Jewellers','M/s H . Roy Jewellers','Dumdum','Nagerbazar','0','8017370467',1,500,5000,0,1,NULL,1,1,'H.RJ',10),('S83','Dhanalaxmi Jewellers','M/s Dhanalaxmi Jewellers','Dumdum','7, Tank More','0','033-25568616',1,500,5000,0,1,NULL,1,1,'DJ',10),('S84','B.c Jewellers','M/s B.c Jewellers','Dumdum','7,tank Road. Northen Avenue','0','9433359688',1,500,5000,0,1,NULL,1,1,'BJ',10),('S85','Subha Raj Jewellers','M/s Subha Raj Jewellers','Dumdum','Dumdum','0','9830426823,033-25606130',1,500,5000,0,1,NULL,1,1,'SRJ',10),('S86','Rupashree Jewellers','M/s Rupashree Jewellers','Dumdum','Nager Bazar ','0','9830606544 , 25607220',1,500,5000,0,1,NULL,1,1,'RJ',10),('S87','Parul Jewellers','M/s Parul Jewellers','Dumdum','Cantonment','0','9804150808',1,500,5000,0,1,NULL,1,1,'PJ',10),('S88','Laxmi Jeweller & Sons','M/s Laxmi Jeweller & Sons','Sreerampore','94, A.P. Ghosh Road, Chatra, Hooghly','0','26625717/8017627217',1,50,5000,0,1,NULL,1,1,'NRJ',10),('S89','Sri Gopal Jewellers','M/s Sri Gopal Jewellers','Durgachawk','Durgachawk','0','9233820046',1,500,5000,0.2,1,NULL,1,1,'SGJ',10),('S9','Gini Mansion Jewellers','M/s Gini Mansion Jewellers','Baruipur','Kachari Bazar','0','9831792487',1,80000,500000,0,1,NULL,1,1,'GMJ',10),('S90','Taniya Jewellers','M/s Taniya Jewellers','Dumdum','2/7B Ramkrishna Ghosh Road','Kol-50','9830720850/9230530850',1,50,5000,0,1,NULL,1,1,'TJ',10),('S91','Modern Jewellers(durgachawk)','M/s Modern Jewellers','Durgachawk','Holdia Road','0','24274027 ',1,500,5000,0.2,1,NULL,1,1,'MJ',10),('S92','K .C Jewellery Museum','M/s K .C Jewellery Museum','Durganagar','Durganagar','0','9839696302',1,500,5000,0.2,1,NULL,1,1,'K.JM',10),('S93','Mundra Jewellers','M/s Mundra Jewellers','Gangarampur','Gangarampur','0','9800016767',1,500,5000,0,1,NULL,1,1,'MJ',10),('S94','Rekha Jewellers','M/s Rekha Jewellers','Belgharia','Nimta , Golpark','0','9051487670',1,500,5000,0,1,NULL,1,1,'RJ',10),('S95','Vadilal Maganlal','M/s Vadilal Maganlal','Jamshedpur','Main Road Bistupur','0','0657-2320140 , 2321808',1,500,5000,0,1,NULL,1,1,'VM',10),('S96','Arvind Vadilal','M/s Arvind Vadilal','Jamshedpur','Main Road , Bistupur','0','0657-2321721 , 8235661334',1,500,5000,0,1,NULL,1,1,'AV',10),('S97','Natwarlal Sukhlal & Bros','M/s Natwarlal Sukhlal & Bros','Jamshedpur','3natraj Mansion , Main Road , Bistupur','0','0657-2249225 , 2249292 , ',1,500,5000,0,1,NULL,1,1,'NS&B',10),('S98','Keshavji Chhaganlal Jewellers Pvt. Ltd','M/s Keshavji Chhaganlal Jewellers Pvt. Ltd','Jamshedpur','Keshavji Bhavan , Bistupur','0','0657-2320834 , 6441105',1,500,5000,0,1,NULL,1,1,'KCJPL',10),('S99','V . K Jewellers','M/s V . K Jewellers','Dumdum','Kalindi','0','9830803735',1,500,5000,0.1,1,NULL,1,1,'V.KJ',10);

--
-- Table structure for table `daily_gold_rate`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `daily_gold_rate` (
  `gold_input_date` date NOT NULL DEFAULT '0000-00-00',
  `gold_rate` double DEFAULT NULL,
  PRIMARY KEY (`gold_input_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_gold_rate`
--


--
-- Table structure for table `departments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `departments` (
  `department_ID` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`department_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_ID`, `department_name`) VALUES (3,'Administration'),(6,'purchase'),(8,'Sales'),(9,'computer'),(10,'technical'),(12,'Baby Bangle'),(14,'Menjement'),(15,'Gorit'),(16,'Management');

--
-- Table structure for table `designations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `designations` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `designation_name` varchar(50) NOT NULL,
  PRIMARY KEY (`designation_id`),
  UNIQUE KEY `designation_name` (`designation_name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designations`
--

INSERT INTO `designations` (`designation_id`, `designation_name`) VALUES (11,'Accountce Manjement'),(2,'Admin'),(16,'General Employee'),(7,'IT'),(9,'Karighar'),(10,'Karighar1'),(3,'Owner'),(12,'Personal Assestitent'),(5,'Purchase Manager'),(14,'Sales'),(15,'Sales Exucative'),(13,'TA');

--
-- Table structure for table `employee_transaction`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `employee_transaction` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_id` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `tr_qty` double DEFAULT NULL,
  `tr_date` datetime DEFAULT NULL,
  `Updated` int(11) DEFAULT NULL,
  PRIMARY KEY (`tr_id`),
  KEY `emp_id` (`emp_id`),
  KEY `rm_id` (`rm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_transaction`
--


--
-- Table structure for table `employees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `employees` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(100) DEFAULT 'None',
  `emp_address` varchar(255) DEFAULT 'None',
  `emp_contact` varchar(25) DEFAULT '0',
  `emp_manager` int(11) DEFAULT 0,
  `emp_description` varchar(200) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `inforce` bit(1) DEFAULT b'1',
  `user_id` varchar(20) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_type_id` int(11) DEFAULT NULL,
  `nick_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `Uni_key_user_id` (`user_id`),
  KEY `user_type_id` (`user_type_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `user_type` (`user_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `emp_address`, `emp_contact`, `emp_manager`, `emp_description`, `department_id`, `designation_id`, `inforce`, `user_id`, `user_password`, `user_type_id`, `nick_name`) VALUES (28,'Vivekananda Ghosh','Sewli','9836444999',28,'owner',3,1,0x01,'vivek','59402f50a4058ad1ed336e8dd1b11720',2,'bile'),(33,'Manaka User','Barrackpore','9051906728',28,'None',16,11,0x01,'manokauser','81dc9bdb52d04dc20036dbd8313ed055',2,'Saheb'),(34,'Hollow Tinku Paul','Barakanthaliya','9051906728',28,'None',15,9,0x01,NULL,NULL,NULL,'H  Tinku'),(35,'Sanjoy Ghosh','Chalk Kathaliya','9748248814',28,'None',9,11,0x01,'sanjoy','b85505c754360395ca1d6dbf157e175a',5,'Sanjoy'),(41,'Hollow Biswajit Mondal','Barrackpore','9734388897',28,'None',15,9,0x01,NULL,NULL,NULL,'H Biswajit '),(42,'Subhas Singha Roy','Barrackpur','8013606561',28,'None',15,9,0x01,NULL,NULL,NULL,'Subhas '),(46,'Arindam Ghosh','Barrackpore','9239495647',28,'Good Boy',16,11,0x01,'papai','12853c0a29c2fc1ccc76a052ceec426c',7,'Arindam Ghosh'),(50,'Hollow Rana Mondal','Barakanthaliya','9051906728',28,'None',15,9,0x01,NULL,NULL,NULL,'H Rana'),(58,'Sukanta Hui','Barrackpore','9830371685',28,'none',3,2,0x01,'biju','1d683d2f77ebd646f11b4afe50d6f9ca',1,'Sukanta Hui'),(60,'Sourav Rajak','bkp','8334063176',28,'none',15,9,0x01,NULL,NULL,NULL,'Sourav'),(67,'Ananda Paul','Bkp','0000000',28,NULL,15,9,0x01,NULL,NULL,NULL,'Ananda'),(69,'Bubu Ghosh','bkp','9874482888',28,NULL,15,9,0x01,NULL,NULL,NULL,'Bubu'),(70,'Vivekananda User','bkp','9088666888',28,NULL,16,11,0x01,'bile','d93591bdf7860e1e4ee2fca799911215',7,'Vivekananda'),(71,'Hollow Sital Das','bkp','9088555111',28,NULL,15,9,0x01,NULL,NULL,NULL,'Sital'),(72,'manager','bkp','9088777333',28,NULL,15,9,0x01,'manager','1d0258c2440a8d19e716292b231e3190',2,'Manoka'),(73,'Chandan Karmakar','bkp','8013518548',28,NULL,15,9,0x01,'chandan','1d683d2f77ebd646f11b4afe50d6f9ca',NULL,'Chandan'),(74,'Khokon Dey','bkp','7278129422',28,NULL,15,9,0x01,'khokon','1d683d2f77ebd646f11b4afe50d6f9ca',NULL,'khokon'),(75,'Sujit Gan','bkp','0000000',28,NULL,15,9,0x00,'sujit',NULL,NULL,'Sujit'),(76,'Sabir Ali Mondal','bkp','8620090730',28,NULL,15,9,0x01,'sabir',NULL,NULL,'Ali'),(78,'Sona Das','bkp','0000',28,NULL,15,9,0x01,'sona',NULL,NULL,'Sona'),(81,'Babai Mali','bkp','8240844461',28,NULL,15,9,0x00,'babai',NULL,NULL,'Babai'),(82,'Madhab Sarkar','bkp','905177424',28,NULL,15,9,0x00,'madhab',NULL,NULL,'Madhab'),(83,'Parimal Paul','Mohanpur','8777098310',28,NULL,15,9,0x01,'parimal',NULL,NULL,'parimal'),(84,'Joy','Barrackpore','9875350229',28,NULL,9,11,0x00,'joy',NULL,NULL,NULL),(85,'Ajay Basak','Barrackpore','00000000',28,'Worker',15,9,0x00,'ajay','ajay',NULL,'Ajay'),(86,'Saheb Ghosh','Barrackpore','7003031560',28,'NewMan',16,11,0x01,'saheb','39cec6d4d21b5dade7544dab6881423e',7,'Guddu'),(87,'Hollow Sagar Nil Das','Bkp','9831332632',28,'Worker',15,9,0x01,'sagar','sagar',NULL,'sagar'),(88,'Hollow Poltu das','Bkp','9836337988',28,'worker',15,9,0x01,'paltu','paltu',NULL,'poltu'),(89,'Hollow Nayan Mondal','Bkp','9875513525',28,'Worker',15,9,0x01,'nayan','nayan',NULL,'nayan'),(90,'Hollow Debobroto Dey ','Bkp','7980300724',28,'Worker',15,9,0x01,'deb','deb',NULL,'Deb'),(91,'Surajit Dhara','bkp','9674875597',28,NULL,16,11,0x01,'surajit',NULL,5,'surajit'),(92,'Pitam Sadhukhan','bkp','000000000',28,NULL,16,11,0x01,'pitam','81dc9bdb52d04dc20036dbd8313ed055',7,NULL);

--
-- Table structure for table `employees_cash_balance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `employees_cash_balance` (
  `emp_id` int(11) DEFAULT NULL,
  `op_balance` int(11) DEFAULT 0,
  `inward` int(11) DEFAULT 0,
  `outward` int(11) DEFAULT 0,
  `balance` int(11) DEFAULT 0,
  `tr_date` timestamp NOT NULL DEFAULT current_timestamp(),
  UNIQUE KEY `emp_id` (`emp_id`),
  KEY `emp_id_2` (`emp_id`),
  CONSTRAINT `employees_cash_balance_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_cash_balance`
--

INSERT INTO `employees_cash_balance` (`emp_id`, `op_balance`, `inward`, `outward`, `balance`, `tr_date`) VALUES (33,0,0,0,0,'2022-12-13 17:22:51'),(35,0,0,0,0,'2022-12-13 17:22:51'),(28,0,0,0,0,'2022-12-13 17:22:51'),(70,0,0,0,0,'2022-12-13 17:22:51'),(46,0,0,0,0,'2022-12-13 17:22:51'),(72,0,0,0,0,'2022-12-13 17:22:51'),(73,0,0,0,0,'2022-12-13 17:22:51'),(86,0,0,0,0,'2022-12-13 17:22:51'),(92,0,0,0,0,'2022-12-13 17:22:51');

--
-- Table structure for table `emprmbalance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `emprmbalance` (
  `rmbal_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `rm_qty` double DEFAULT NULL,
  `rm_date` datetime DEFAULT NULL,
  PRIMARY KEY (`rmbal_id`),
  KEY `emp_id` (`emp_id`),
  KEY `rm_id` (`rm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emprmbalance`
--


--
-- Table structure for table `failed_jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--


--
-- Table structure for table `gold_price`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gold_price` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT 0,
  `price_date` datetime DEFAULT NULL,
  `user_id` varchar(50) DEFAULT 'None',
  PRIMARY KEY (`ID`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_price`
--


--
-- Table structure for table `gold_receipt_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gold_receipt_master` (
  `gold_receipt_id` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `cust_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `agent_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `gold_value` double DEFAULT NULL,
  `gold_rate` double DEFAULT NULL,
  `cash` double DEFAULT NULL,
  `cheque_value` double DEFAULT NULL,
  `bank_details` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `tr_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_gold_balance` double DEFAULT 0,
  `last_lc_balance` int(11) DEFAULT 0,
  `current_gold_balance` double DEFAULT 0,
  `current_lc_balance` int(11) DEFAULT 0,
  PRIMARY KEY (`gold_receipt_id`),
  KEY `cust_id` (`cust_id`),
  KEY `agent_id` (`agent_id`),
  KEY `rm_id` (`rm_id`),
  KEY `emp_id` (`emp_id`),
  KEY `rm_id_2` (`rm_id`),
  CONSTRAINT `gold_receipt_master_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE,
  CONSTRAINT `gold_receipt_master_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`) ON UPDATE CASCADE,
  CONSTRAINT `gold_receipt_master_ibfk_3` FOREIGN KEY (`rm_id`) REFERENCES `rm_master` (`rm_ID`) ON UPDATE CASCADE,
  CONSTRAINT `gold_receipt_master_ibfk_4` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_receipt_master`
--


--
-- Table structure for table `gold_retun_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gold_retun_master` (
  `gold_retun_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Return_no` varchar(20) DEFAULT '0',
  `Return_mode` varchar(55) DEFAULT 'None',
  `Cust_ID` varchar(55) NOT NULL,
  `return_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Cheque_no` varchar(10) DEFAULT '0',
  `Bank` varchar(55) DEFAULT 'NA',
  `Branch` varchar(75) DEFAULT 'NA',
  `thousand` int(11) DEFAULT 0,
  `five_hundred` int(11) DEFAULT 0,
  `one_hundred` int(11) DEFAULT 0,
  `fifty` int(11) DEFAULT 0,
  `twenty` int(11) DEFAULT 0,
  `ten` int(11) DEFAULT 0,
  `five` int(11) DEFAULT 0,
  `two` int(11) DEFAULT 0,
  `one` int(11) DEFAULT 0,
  `Gold_weight` double DEFAULT 0,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`gold_retun_ID`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_retun_master`
--


--
-- Table structure for table `gold_return_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gold_return_details` (
  `return_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `gold_retun_ID` int(11) DEFAULT 0,
  `return_gold` double DEFAULT 0,
  KEY `gold_retun_ID` (`gold_retun_ID`),
  KEY `return_details_id` (`return_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_return_details`
--


--
-- Table structure for table `gold_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gold_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `gold_type` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_type`
--

INSERT INTO `gold_type` (`ID`, `gold_type`) VALUES (1,'Pure Gold'),(2,'Gini Gold'),(3,'Holmark Gold');

--
-- Table structure for table `inventory_day_book`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `inventory_day_book` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `transaction_type` int(11) DEFAULT 1,
  `rm_value` double DEFAULT 0,
  `reference` varchar(50) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `inforce` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `rm_id` (`rm_id`),
  CONSTRAINT `inventory_day_book_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`emp_id`),
  CONSTRAINT `inventory_day_book_ibfk_2` FOREIGN KEY (`rm_id`) REFERENCES `rm_master` (`rm_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_day_book`
--


--
-- Table structure for table `item_stock_ready_made`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `item_stock_ready_made` (
  `tag` varchar(20) CHARACTER SET utf8 NOT NULL,
  `item_inward_detail_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  `model_no` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `model_size` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `gold` double DEFAULT NULL,
  `labour_charge` int(11) DEFAULT NULL,
  `gross_weight` double DEFAULT NULL,
  `package_weight` double DEFAULT NULL,
  `in_stock` int(11) DEFAULT NULL,
  `agent_id` varchar(20) CHARACTER SET utf8 NOT NULL,
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` varchar(11) CHARACTER SET utf8 NOT NULL,
  `inforce` int(11) DEFAULT 1,
  `reference` varchar(255) DEFAULT NULL,
  `bill_no` varchar(20) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `is_separate` int(11) DEFAULT 0,
  PRIMARY KEY (`tag`),
  KEY `agent_id` (`agent_id`),
  KEY `model_no` (`model_no`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_stock_ready_made`
--

INSERT INTO `item_stock_ready_made` (`tag`, `item_inward_detail_id`, `model_no`, `model_size`, `qty`, `gold`, `labour_charge`, `gross_weight`, `package_weight`, `in_stock`, `agent_id`, `record_time`, `employee_id`, `inforce`, `reference`, `bill_no`, `job_id`, `is_separate`) VALUES ('B7361',NULL,'L0003','2-5-5',2,5.771,1880,30.008,31.636,1,'AG2018','2022-10-26 10:24:41','70',1,'Closing/2022','SBJW/903/2223',NULL,0),('B7364',NULL,'L0047','2-5-5',2,5.66,1880,27.878,28.709,1,'AG2018','2022-10-26 10:33:51','70',1,'Closing/2022','SBJW/872/2223',NULL,0),('B7367',NULL,'C0033','2-6-0',4,4.61,2480,62.683,63.507,1,'AG2018','2022-10-26 10:52:45','70',1,'Closing/2022','SBJW/828/2223',NULL,0),('B7369',NULL,'C0277','2-5-0',4,4.529,2480,43.872,44.698,1,'AG2018','2022-10-26 10:56:00','70',1,'Closing/2022','SBJW/828/2223',NULL,0),('B7371',NULL,'C1427','2-6-0',4,4.329,2400,57.317,58.135,1,'AG2018','2022-10-26 11:22:54','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7372',NULL,'C1427','2-6-0',4,4.329,2400,57.242,58.064,1,'AG2018','2022-10-26 11:24:18','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7373',NULL,'C1427','2-6-0',4,4.329,2400,57.084,57.912,1,'AG2018','2022-10-26 11:25:43','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7374',NULL,'C1628','2-6-5',2,3.988,1520,41.888,42.707,1,'AG2018','2022-10-26 11:27:48','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7375',NULL,'C1628','2-6-5',2,3.988,1520,41.378,42.201,1,'AG2018','2022-10-26 11:28:42','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7376',NULL,'T3123','2-5-5',4,4.23,2400,62.893,63.716,1,'AG2018','2022-10-26 11:30:53','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7377',NULL,'T3123','2-5-5',4,4.23,2400,62.025,62.842,1,'AG2018','2022-10-26 11:32:24','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7378',NULL,'C0277','2-6-5',4,4.381,2480,46.033,46.849,1,'AG2018','2022-10-26 11:36:43','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7379',NULL,'C0277','2-6-5',4,4.381,2480,46.31,47.132,1,'AG2018','2022-10-26 11:41:04','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7381',NULL,'C0033','2-5-0',4,4.562,2480,61.201,62.019,1,'AG2018','2022-10-26 11:43:36','70',1,'Closing/2022','SBJW/893/2223',NULL,0),('B7384',NULL,'N6063','2-6-0',1,2.549,940,24.688,25.512,1,'AG2020','2022-10-26 11:50:52','70',1,'Closing/2022','SBJW/906/2223',NULL,0),('B7388',NULL,'N6064','2-5-5',1,2.388,940,24.34,25.162,1,'AG2018','2022-10-26 11:57:43','70',1,'Closing/2022','SBJW/905/2223',NULL,0),('B7391',NULL,'B7100','0',2,1.531,1200,16.396,16.91,1,'AG2018','2022-10-26 12:36:38','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7392',NULL,'B7100','0',2,1.531,1200,16.318,16.825,1,'AG2018','2022-10-26 12:53:21','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7393',NULL,'B7100','0',2,1.531,1200,16.39,16.899,1,'AG2018','2022-10-26 12:54:49','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7394',NULL,'B7100','0',2,1.531,1200,16.368,16.878,1,'AG2018','2022-10-26 13:12:48','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7395',NULL,'B7100','0',2,1.531,1200,16.295,16.806,1,'AG2018','2022-10-26 13:12:11','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7396',NULL,'B7100','0',2,1.531,1200,16.358,16.861,1,'AG2018','2022-10-26 13:07:04','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7397',NULL,'B7100','0',2,1.531,1200,16.396,16.907,1,'AG2018','2022-10-26 12:47:44','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7398',NULL,'B7100','0',2,1.531,1200,16.421,16.934,1,'AG2018','2022-10-26 13:14:44','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7399',NULL,'B7100','0',2,1.531,1200,16.36,16.871,1,'AG2018','2022-10-26 13:11:25','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7400',NULL,'B7100','0',2,1.531,1200,16.348,16.867,1,'AG2018','2022-10-26 12:48:49','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7401',NULL,'B7100','0',2,1.531,1200,16.35,16.865,1,'AG2018','2022-10-26 12:55:43','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7402',NULL,'B7100','0',2,1.531,1200,16.335,16.847,1,'AG2018','2022-10-26 12:50:51','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7403',NULL,'B7100','0',2,1.531,1200,16.328,16.838,1,'AG2018','2022-10-26 12:56:43','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7404',NULL,'B7100','0',2,1.531,1200,16.349,16.864,1,'AG2018','2022-10-26 13:05:24','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7405',NULL,'B7100','0',2,1.531,1200,16.307,16.818,1,'AG2018','2022-10-26 12:46:45','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7406',NULL,'B7100','0',2,1.531,1200,16.362,16.885,1,'AG2018','2022-10-26 13:10:27','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7407',NULL,'B7100','0',2,1.531,1200,16.356,16.887,1,'AG2018','2022-10-26 13:09:38','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7408',NULL,'B7100','0',2,1.531,1200,16.346,16.861,1,'AG2018','2022-10-26 12:54:00','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7409',NULL,'B7100','0',2,1.531,1200,16.354,16.867,1,'AG2018','2022-10-26 13:07:47','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7410',NULL,'B7100','0',2,1.531,1200,16.351,16.87,1,'AG2018','2022-10-26 12:51:34','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7411',NULL,'B7100','0',2,1.531,1200,16.337,16.847,1,'AG2018','2022-10-26 12:52:16','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7412',NULL,'B7100','0',2,1.531,1200,16.384,16.898,1,'AG2018','2022-10-26 12:49:55','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7413',NULL,'B7100','0',2,1.531,1200,16.345,16.851,1,'AG2018','2022-10-26 13:13:35','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7414',NULL,'B7100','0',2,1.531,1200,16.379,16.898,1,'AG2018','2022-10-26 13:06:04','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7415',NULL,'B7100','0',2,1.531,1200,16.379,16.887,1,'AG2018','2022-10-26 13:08:41','70',1,'Closing/2022','SBJW/885/2223',NULL,0),('B7416',NULL,'B7021','0',2,1.796,1200,8.208,8.718,1,'AG2018','2022-10-26 13:19:55','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7420',NULL,'B7021','0',2,1.796,1200,8.285,8.794,1,'AG2018','2022-10-26 13:34:22','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7421',NULL,'B7021','0',2,1.796,1200,8.294,8.799,1,'AG2018','2022-10-26 13:32:45','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7422',NULL,'B7021','0',2,1.796,1200,8.207,8.723,1,'AG2018','2022-10-26 13:22:11','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7423',NULL,'B7021','0',2,1.796,1200,8.3,8.817,1,'AG2018','2022-10-26 13:23:59','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7424',NULL,'B7021','0',2,1.796,1200,8.281,8.795,1,'AG2018','2022-10-26 13:24:57','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7425',NULL,'B7021','0',2,1.796,1200,8.125,8.643,1,'AG2018','2022-10-26 13:27:31','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7426',NULL,'B7021','0',2,1.796,1200,8.215,8.739,1,'AG2018','2022-10-26 13:26:21','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7427',NULL,'B7021','0',2,1.796,1200,8.029,8.541,1,'AG2018','2022-10-26 13:22:56','70',1,'Closing/2022','SBJW/875/2223',NULL,0),('B7428',NULL,'B7035','0',1,0.792,600,3.788,4.308,1,'AG2018','2022-10-26 13:44:32','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7429',NULL,'B7035','0',2,1.584,1200,7.605,8.121,1,'AG2018','2022-10-26 13:55:18','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7430',NULL,'B7035','0',2,1.584,1200,7.635,8.15,1,'AG2018','2022-10-26 13:54:30','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7431',NULL,'B7035','0',2,1.584,1200,7.573,8.085,1,'AG2018','2022-10-26 13:52:33','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7432',NULL,'B7035','0',2,1.584,1200,7.565,8.079,1,'AG2018','2022-10-26 13:53:09','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7433',NULL,'B7035','0',2,1.584,1200,7.579,8.1,1,'AG2018','2022-10-26 13:53:48','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7435',NULL,'B7035','0',2,1.584,1200,7.671,8.187,1,'AG2018','2022-10-26 13:46:56','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7437',NULL,'B7035','0',2,1.584,1200,7.587,8.104,1,'AG2018','2022-10-26 13:50:19','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7438',NULL,'B7035','0',2,1.584,1200,7.642,8.151,1,'AG2018','2022-10-26 13:45:56','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7439',NULL,'B7035','0',2,1.584,1200,7.676,8.184,1,'AG2018','2022-10-26 13:48:34','70',1,'Closing/2022','SBJW/871/2223',NULL,0),('B7440',NULL,'B7100','0',1,0.748,600,8.36,8.867,1,'AG2018','2022-10-26 13:59:53','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7441',NULL,'B7100','0',2,1.496,1200,16.778,17.285,1,'AG2018','2022-10-26 14:27:42','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7442',NULL,'B7100','0',2,1.496,1200,16.689,17.201,1,'AG2018','2022-10-26 14:05:17','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7443',NULL,'B7100','0',2,1.496,1200,16.784,17.302,1,'AG2018','2022-10-26 14:16:51','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7444',NULL,'B7100','0',2,1.496,1200,16.732,17.24,1,'AG2018','2022-10-26 14:02:41','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7445',NULL,'B7100','0',2,1.496,1200,16.772,17.277,1,'AG2018','2022-10-26 14:08:38','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7446',NULL,'B7100','0',2,1.496,1200,16.727,17.234,1,'AG2018','2022-10-26 14:11:51','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7447',NULL,'B7100','0',2,1.496,1200,16.749,17.258,1,'AG2018','2022-10-26 14:23:10','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7448',NULL,'B7100','0',2,1.496,1200,16.613,17.129,1,'AG2018','2022-10-26 14:17:59','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7449',NULL,'B7100','0',2,1.496,1200,16.76,17.267,1,'AG2018','2022-10-26 14:07:58','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7450',NULL,'B7100','0',2,1.496,1200,16.736,17.243,1,'AG2018','2022-10-26 14:06:11','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7451',NULL,'B7100','0',2,1.496,1200,16.646,17.165,1,'AG2018','2022-10-26 14:22:15','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7452',NULL,'B7100','0',2,1.496,1200,16.606,17.116,1,'AG2018','2022-10-26 14:29:20','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7453',NULL,'B7100','0',2,1.496,1200,16.697,17.207,1,'AG2018','2022-10-26 14:19:20','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7454',NULL,'B7100','0',2,1.496,1200,16.747,17.25,1,'AG2018','2022-10-26 14:24:46','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7455',NULL,'B7100','0',2,1.496,1200,16.629,17.143,1,'AG2018','2022-10-26 14:20:14','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7456',NULL,'B7100','0',2,1.496,1200,16.728,17.24,1,'AG2018','2022-10-26 14:12:52','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7457',NULL,'B7100','0',2,1.496,1200,16.677,17.187,1,'AG2018','2022-10-26 14:03:19','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7458',NULL,'B7100','0',2,1.496,1200,16.716,17.23,1,'AG2018','2022-10-26 14:16:02','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7459',NULL,'B7100','0',2,1.496,1200,16.693,17.211,1,'AG2018','2022-10-26 14:24:09','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7460',NULL,'B7100','0',2,1.496,1200,16.66,17.179,1,'AG2018','2022-10-26 14:26:30','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7461',NULL,'B7100','0',2,1.496,1200,16.764,17.279,1,'AG2018','2022-10-26 14:10:54','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7462',NULL,'B7100','0',2,1.496,1200,16.702,17.216,1,'AG2018','2022-10-26 14:04:02','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7463',NULL,'B7100','0',2,1.496,1200,16.812,17.318,1,'AG2018','2022-10-26 14:25:37','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7464',NULL,'B7100','0',2,1.496,1200,16.735,17.25,1,'AG2018','2022-10-26 14:20:55','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7465',NULL,'B7100','0',2,1.496,1200,16.691,17.21,1,'AG2018','2022-10-26 14:14:19','70',1,'Closing/2022','SBJW/928/2223',NULL,0),('B7466',NULL,'C0937','2-5-5',2,3.893,1440,33.389,34.215,1,'AG2018','2022-10-26 14:23:20','70',1,'Closing/2022','SBJW/858/2223',NULL,0),('B7467',NULL,'B7013','0',1,0.708,600,4.163,4.671,1,'AG2018','2022-10-26 14:25:35','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7468',NULL,'B7013','0',2,1.416,1200,8.434,8.94,1,'AG2018','2022-10-26 14:29:24','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7469',NULL,'B7013','0',2,1.416,1200,8.385,8.892,1,'AG2018','2022-10-26 14:32:14','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7470',NULL,'B7013','0',2,1.416,1200,8.288,8.802,1,'AG2018','2022-10-26 14:26:35','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7471',NULL,'B7013','0',2,1.416,1200,8.314,8.821,1,'AG2018','2022-10-26 14:34:55','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7473',NULL,'B7013','0',2,1.416,1200,8.272,8.783,1,'AG2018','2022-10-26 14:34:31','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7474',NULL,'B7013','0',2,1.416,1200,8.283,8.788,1,'AG2018','2022-10-26 14:33:27','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7475',NULL,'B7013','0',2,1.416,1200,8.394,8.901,1,'AG2018','2022-10-26 14:28:34','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7476',NULL,'B7013','0',2,1.416,1200,8.297,8.806,1,'AG2018','2022-10-26 14:30:45','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7477',NULL,'B7013','0',2,1.416,1200,8.307,8.812,1,'AG2018','2022-10-26 14:30:00','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7478',NULL,'B7013','0',2,1.416,1200,8.32,8.823,1,'AG2018','2022-10-26 14:33:52','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7479',NULL,'B7043','0',2,1.47,1200,8.432,8.939,1,'AG2018','2022-10-26 14:20:47','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7481',NULL,'B7043','0',2,1.47,1200,8.48,8.991,1,'AG2018','2022-10-26 14:16:15','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7482',NULL,'B7043','0',2,1.47,1200,8.376,8.888,1,'AG2018','2022-10-26 14:19:30','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7483',NULL,'B7043','0',2,1.47,1200,8.59,9.107,1,'AG2018','2022-10-26 14:20:16','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7484',NULL,'B7043','0',2,1.47,1200,8.57,9.083,1,'AG2018','2022-10-26 14:19:56','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7485',NULL,'B7043','0',2,1.47,1200,8.472,8.99,1,'AG2018','2022-10-26 14:17:41','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7488',NULL,'B7043','0',2,1.47,1200,8.342,8.855,1,'AG2018','2022-10-26 14:18:14','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7490',NULL,'B7100','0',2,1.534,1200,16.322,16.83,1,'AG2018','2022-10-26 14:38:20','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7491',NULL,'B7100','0',2,1.534,1200,16.337,16.851,1,'AG2018','2022-10-26 14:40:08','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7492',NULL,'B7100','0',2,1.534,1200,16.385,16.907,1,'AG2018','2022-10-26 14:45:20','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7493',NULL,'B7100','0',2,1.534,1200,16.37,16.891,1,'AG2018','2022-10-26 14:37:35','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7494',NULL,'B7100','0',2,1.534,1200,16.378,16.89,1,'AG2018','2022-10-26 14:36:48','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7495',NULL,'B7100','0',2,1.534,1200,16.401,16.913,1,'AG2018','2022-10-26 14:48:51','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7496',NULL,'B7100','0',2,1.534,1200,16.408,16.922,1,'AG2018','2022-10-26 14:47:42','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7497',NULL,'B7100','0',2,1.534,1200,16.333,16.853,1,'AG2018','2022-10-26 14:41:02','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7498',NULL,'B7100','0',2,1.534,1200,16.328,16.849,1,'AG2018','2022-10-26 14:50:49','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7500',NULL,'B7100','0',2,1.534,1200,16.376,16.889,1,'AG2018','2022-10-26 14:55:12','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7501',NULL,'B7100','0',2,1.534,1200,16.359,16.874,1,'AG2018','2022-10-26 14:39:19','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7502',NULL,'B7100','0',2,1.534,1200,16.369,16.889,1,'AG2018','2022-10-26 14:44:18','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7503',NULL,'B7100','0',2,1.534,1200,16.338,16.85,1,'AG2018','2022-10-26 14:46:54','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7504',NULL,'B7100','0',2,1.534,1200,16.336,16.839,1,'AG2018','2022-10-26 14:50:02','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7505',NULL,'B7100','0',2,1.534,1200,16.362,16.874,1,'AG2018','2022-10-26 14:35:54','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7506',NULL,'B7100','0',2,1.534,1200,16.316,16.831,1,'AG2018','2022-10-26 14:43:18','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7507',NULL,'B7100','0',2,1.534,1200,16.417,16.931,1,'AG2018','2022-10-26 14:51:29','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7508',NULL,'B7100','0',2,1.534,1200,16.325,16.832,1,'AG2018','2022-10-26 14:48:19','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7510',NULL,'B7100','0',2,1.534,1200,16.349,16.864,1,'AG2018','2022-10-26 14:54:18','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7511',NULL,'B7100','0',2,1.534,1200,16.436,16.95,1,'AG2018','2022-10-26 14:53:39','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7514',NULL,'B7100','0',2,1.534,1200,16.413,16.933,1,'AG2018','2022-10-26 14:45:55','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7515',NULL,'B7100','0',2,1.534,1200,16.349,16.87,1,'AG2018','2022-10-26 14:42:43','70',1,'Closing/2022','SBJW/857/2223',NULL,0),('B7519',NULL,'C0861','2-5-5',4,5.025,2480,38.459,39.274,1,'AG2018','2022-10-28 11:26:43','70',1,'Closing/2022','SBJW/1004/2223',NULL,0),('B7522',NULL,'C0293','2-6-0',4,4.918,2480,54.281,55.102,1,'AG2018','2022-10-28 11:31:08','70',1,'Closing/2022','SBJW/1004/2223',NULL,0),('B7523',NULL,'C0293','2-6-0',4,4.918,2480,54.198,55.022,1,'AG2018','2022-10-28 11:33:04','70',1,'Closing/2022','SBJW/1004/2223',NULL,0),('B7524',NULL,'C0293','2-6-0',4,4.918,2480,54.947,55.763,1,'AG2018','2022-10-28 11:33:53','70',1,'Closing/2022','SBJW/1004/2223',NULL,0),('B7526',NULL,'C0863','2-5-0',4,5.082,2480,69.082,70.173,1,'AG2018','2022-10-28 11:36:59','70',1,'Closing/2022','SBJW/1004/2223',NULL,0),('B7528',NULL,'B7100','0',2,1.544,1200,16.984,17.492,1,'AG2018','2022-10-28 12:32:24','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7530',NULL,'B7100','0',2,1.544,1200,16.941,17.452,1,'AG2018','2022-10-28 12:34:23','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7533',NULL,'B7100','0',2,1.544,1200,16.902,17.405,1,'AG2018','2022-10-28 12:33:42','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7534',NULL,'B7100','0',2,1.544,1200,16.859,17.367,1,'AG2018','2022-10-28 12:33:01','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7538',NULL,'B7100','0',2,1.544,1200,16.876,17.383,1,'AG2018','2022-10-28 12:37:22','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7539',NULL,'B7100','0',2,1.544,1200,16.937,17.442,1,'AG2018','2022-10-28 12:39:05','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7541',NULL,'B7100','0',2,1.544,1200,16.819,17.333,1,'AG2018','2022-10-28 12:45:53','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7542',NULL,'B7100','0',2,1.544,1200,16.995,17.492,1,'AG2018','2022-10-28 12:41:10','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7545',NULL,'B7100','0',2,1.544,1200,16.923,17.428,1,'AG2018','2022-10-28 12:46:54','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7546',NULL,'B7100','0',2,1.544,1200,16.984,17.488,1,'AG2018','2022-10-28 12:47:34','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7547',NULL,'B7100','0',2,1.544,1200,16.893,17.396,1,'AG2018','2022-10-28 12:49:49','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7548',NULL,'B7100','0',2,1.544,1200,17,17.501,1,'AG2018','2022-10-28 12:42:11','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7550',NULL,'B7100','0',2,1.544,1200,16.971,17.469,1,'AG2018','2022-10-28 12:44:23','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7551',NULL,'B7100','0',2,1.544,1200,16.879,17.388,1,'AG2018','2022-10-28 12:40:29','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7554',NULL,'B7100','0',2,1.544,1200,16.834,17.334,1,'AG2018','2022-10-28 12:27:10','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7555',NULL,'B7100','0',2,1.544,1200,16.945,17.455,1,'AG2018','2022-10-28 12:27:48','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7556',NULL,'B7100','0',2,1.544,1200,17.06,17.565,1,'AG2018','2022-10-28 12:28:48','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7559',NULL,'B7100','0',2,1.544,1200,16.994,17.502,1,'AG2018','2022-10-28 12:23:14','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7560',NULL,'B7100','0',2,1.544,1200,16.933,17.432,1,'AG2018','2022-10-28 12:24:52','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7563',NULL,'B7100','0',2,1.544,1200,16.956,17.459,1,'AG2018','2022-10-28 12:18:33','70',1,'Closing/2022','SBJW/1003/2223',NULL,0),('B7564',NULL,'L0061','2-6-5',2,5.421,1880,28.347,29.267,1,'AG2018','2022-10-28 13:56:35','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7566',NULL,'L0063','2-6-5',2,6.378,1880,25.855,26.851,1,'AG2018','2022-10-28 13:35:03','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7567',NULL,'N2055','2-5-0',2,2.758,1760,19.18,19.988,1,'AG2018','2022-10-28 13:28:27','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7568',NULL,'C1625','2-5-5',2,4.064,1520,47.81,48.629,1,'AG2018','2022-10-28 13:07:24','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7569',NULL,'C1622','2-5-5',2,4.249,1520,43.833,44.649,1,'AG2018','2022-10-28 13:09:15','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7570',NULL,'C1632','2-6-0',2,3.49,1520,41.368,42.187,1,'AG2018','2022-10-28 13:18:03','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7571',NULL,'C1640','2-5-5',2,3.543,1440,27.415,28.232,1,'AG2018','2022-10-28 13:15:20','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7572',NULL,'C1027','2-5-0',2,3.73,1520,47.508,48.322,1,'AG2018','2022-10-28 13:23:17','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7575',NULL,'C1611','2-5-5',2,3.634,1520,43.645,44.463,1,'AG2018','2022-10-28 13:21:20','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7577',NULL,'N2041','2-5-0',2,2.187,1760,16.671,17.49,1,'AG2018','2022-10-28 13:16:38','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7578',NULL,'N2047','2-4-5',2,2.565,1760,18.596,19.405,1,'AG2018','2022-10-28 13:48:19','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7579',NULL,'N2050','2-4-0',2,2.637,1760,17.023,17.831,1,'AG2018','2022-10-28 13:51:47','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7580',NULL,'N2050','2-4-0',2,2.637,1760,17.217,18.025,1,'AG2018','2022-10-28 13:36:51','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7581',NULL,'N2050','2-4-0',2,2.637,1760,20.121,21.016,1,'AG2018','2022-10-28 13:54:53','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7582',NULL,'H1819','2-4-0',2,4.961,1760,20.537,21.216,1,'AG2018','2022-10-28 13:26:12','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7583',NULL,'N2050','2-4-0',2,2.781,1760,17.215,18.026,1,'AG2018','2022-10-28 13:30:05','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7584',NULL,'N2055','2-5-5',2,2.73,1760,18.348,19.159,1,'AG2018','2022-10-28 13:49:48','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7585',NULL,'N2048','2-5-0',2,2.646,1760,18.772,19.593,1,'AG2018','2022-10-28 13:43:43','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7587',NULL,'N6049','2-6-0',1,3.297,920,21.32,22.132,1,'AG2018','2022-10-28 14:07:58','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7591',NULL,'C0293','2-5-0',4,3.656,2480,52.052,52.857,1,'AG2018','2022-10-28 13:52:22','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7593',NULL,'M0717','2-6-0',2,3.961,1480,56.615,57.424,1,'AG2018','2022-10-28 13:39:20','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7594',NULL,'C2320','2-5-0',2,3.748,1440,45.733,46.549,1,'AG2018','2022-10-28 14:00:04','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7595',NULL,'C0737','2-4-0',2,3.154,1400,37.156,37.977,1,'AG2018','2022-10-28 13:58:10','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7596',NULL,'T3102','2-5-5',4,3.498,2400,51.395,52.21,1,'AG2018','2022-10-28 14:21:08','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7598',NULL,'T3110','2-5-0',4,3.445,2400,40.938,41.761,1,'AG2018','2022-10-28 14:09:53','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7599',NULL,'T3109','2-5-5',4,3.658,2400,42.325,43.139,1,'AG2018','2022-10-28 14:23:38','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7601',NULL,'T3117','2-6-0',4,3.554,2400,42.462,43.28,1,'AG2018','2022-10-28 14:24:47','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7602',NULL,'T3117','2-5-5',4,3.325,2400,42.45,43.272,1,'AG2018','2022-10-28 14:12:45','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7603',NULL,'C1406','2-5-5',4,3.691,2400,47.645,48.461,1,'AG2018','2022-10-28 14:22:20','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7604',NULL,'C1406','2-5-5',4,3.691,2400,49.064,49.88,1,'AG2018','2022-10-28 14:14:25','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7606',NULL,'B7021','0',2,1.58,1200,8.401,8.906,1,'AG2018','2022-10-29 06:19:31','70',1,'Closing/2022','RMD/291022/02',NULL,0),('B7607',NULL,'B7096','0',1,0.738,600,8.52,9.029,1,'AG2018','2022-10-28 16:19:13','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7609',NULL,'B7013','0',2,1.256,1200,7.666,8.181,1,'AG2018','2022-10-29 06:25:41','70',1,'Closing/2022','RMD/291022/02',NULL,0),('B7611',NULL,'B7042','0',2,0.995,1160,5.736,6.24,1,'AG2018','2022-10-28 16:19:51','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7621',NULL,'B7035','0',2,1.336,1200,6.477,6.982,1,'AG2018','2022-10-29 06:21:15','70',1,'Closing/2022','RMD/291022/02',NULL,0),('B7622',NULL,'B7042','0',2,0.995,1160,5.801,6.304,1,'AG2018','2022-10-28 16:17:15','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7623',NULL,'B7068','0',1,0.643,600,8.283,8.793,1,'AG2018','2022-10-28 16:21:30','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7624',NULL,'B7042','0',2,0.995,1160,5.754,6.263,1,'AG2018','2022-10-28 16:16:33','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7626',NULL,'B7052','0',2,1.23,1200,7.708,8.221,1,'AG2018','2022-10-28 14:38:31','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7627',NULL,'B7052','0',2,1.23,1200,7.597,8.101,1,'AG2018','2022-10-28 14:40:55','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7628',NULL,'B7052','0',2,1.23,1200,7.725,8.288,1,'AG2018','2022-10-28 14:43:32','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7629',NULL,'B7052','0',2,1.23,1200,7.673,8.179,1,'AG2018','2022-10-28 14:35:28','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7630',NULL,'B7052','0',2,1.23,1200,7.725,8.243,1,'AG2018','2022-10-28 14:42:35','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7632',NULL,'B7052','0',2,1.23,1200,7.767,8.27,1,'AG2018','2022-10-28 14:41:54','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7633',NULL,'B7052','0',2,1.23,1200,7.699,8.207,1,'AG2018','2022-10-28 14:44:16','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7634',NULL,'B7052','0',2,1.23,1200,7.697,8.192,1,'AG2018','2022-10-28 14:37:48','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7637',NULL,'B7043','0',2,1.261,1200,8.514,9.021,1,'AG2018','2022-10-28 14:53:08','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7638',NULL,'B7043','0',2,1.261,1200,8.51,9.014,1,'AG2018','2022-10-28 14:53:51','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7639',NULL,'B7043','0',2,1.261,1200,8.447,8.961,1,'AG2018','2022-10-28 14:55:39','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7640',NULL,'B7043','0',2,1.261,1200,8.44,8.95,1,'AG2018','2022-10-28 14:58:39','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7641',NULL,'B7043','0',2,1.261,1200,8.474,9.026,1,'AG2018','2022-10-28 14:59:34','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7642',NULL,'B7043','0',2,1.261,1200,8.577,9.084,1,'AG2018','2022-10-28 14:47:56','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7643',NULL,'B7043','0',2,1.261,1200,8.437,8.943,1,'AG2018','2022-10-28 14:54:52','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7644',NULL,'B7043','0',2,1.261,1200,8.476,9.024,1,'AG2018','2022-10-28 14:57:55','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7645',NULL,'B7043','0',2,1.261,1200,8.537,9.087,1,'AG2018','2022-10-28 14:48:35','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7646',NULL,'B7099','0',2,1.585,1200,16.611,17.129,1,'AG2018','2022-10-28 15:14:24','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7647',NULL,'B7099','0',2,1.585,1200,16.564,17.088,1,'AG2018','2022-10-28 15:07:26','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7649',NULL,'B7099','0',2,1.485,1200,15.194,15.827,1,'AG2018','2022-10-28 15:22:22','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7650',NULL,'B7099','0',2,1.565,1200,16.379,16.934,1,'AG2018','2022-10-28 15:24:32','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7651',NULL,'B7099','0',2,1.565,1200,16.517,17.058,1,'AG2018','2022-10-28 15:28:49','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7652',NULL,'B7099','0',2,1.585,1200,16.575,17.086,1,'AG2018','2022-10-28 15:18:16','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7653',NULL,'B7099','0',2,1.565,1200,16.337,16.892,1,'AG2018','2022-10-28 15:27:46','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7655',NULL,'B7099','0',2,1.565,1200,16.396,16.949,1,'AG2018','2022-10-28 15:26:04','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7657',NULL,'B7099','0',2,1.565,1200,16.356,16.91,1,'AG2018','2022-10-28 15:25:13','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7658',NULL,'B7099','0',2,1.585,1200,16.581,17.114,1,'AG2018','2022-10-28 15:16:21','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7659',NULL,'B7099','0',2,1.585,1200,16.481,17.016,1,'AG2018','2022-10-28 15:09:22','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7662',NULL,'B7099','0',2,1.565,1200,16.46,17.009,1,'AG2018','2022-10-28 15:29:25','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7663',NULL,'B7099','0',2,1.585,1200,16.552,17.078,1,'AG2018','2022-10-28 15:19:24','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7665',NULL,'B7044','0',2,1.018,1160,5.781,6.329,1,'AG2018','2022-10-28 15:52:20','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7666',NULL,'B7044','0',2,1.018,1160,5.852,6.395,1,'AG2018','2022-10-28 15:48:57','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7668',NULL,'B7044','0',2,1.018,1160,5.839,6.385,1,'AG2018','2022-10-28 15:53:43','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7669',NULL,'B7044','0',2,1.018,1160,5.811,6.354,1,'AG2018','2022-10-28 15:50:32','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7670',NULL,'B7044','0',2,1.018,1160,5.842,6.389,1,'AG2018','2022-10-28 15:48:04','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7672',NULL,'B7044','0',2,1.018,1160,5.828,6.374,1,'AG2018','2022-10-28 15:48:44','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7673',NULL,'B7044','0',2,1.018,1160,5.887,6.431,1,'AG2018','2022-10-28 15:45:58','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7674',NULL,'B7044','0',2,1.018,1160,5.816,6.36,1,'AG2018','2022-10-28 15:53:46','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7675',NULL,'B7044','0',2,1.018,1160,5.691,6.235,1,'AG2018','2022-10-28 15:53:04','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7676',NULL,'B7044','0',2,1.018,1160,5.913,6.463,1,'AG2018','2022-10-28 15:51:08','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7677',NULL,'B7044','0',2,1.018,1160,5.768,6.317,1,'AG2018','2022-10-28 15:46:44','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7678',NULL,'B7044','0',2,1.018,1160,5.737,6.277,1,'AG2018','2022-10-28 15:51:40','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7679',NULL,'B7044','0',2,1.018,1160,5.841,6.386,1,'AG2018','2022-10-28 15:51:14','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7680',NULL,'B7044','0',2,1.018,1160,5.823,6.367,1,'AG2018','2022-10-28 15:53:17','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7681',NULL,'B7044','0',2,1.018,1160,5.89,6.425,1,'AG2018','2022-10-28 15:49:39','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7682',NULL,'B7044','0',2,1.018,1160,5.786,6.239,1,'AG2018','2022-10-28 15:46:21','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7683',NULL,'B7044','0',2,1.018,1160,5.866,6.405,1,'AG2018','2022-10-28 15:52:00','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7684',NULL,'B7044','0',2,1.004,1160,5.581,6.125,1,'AG2018','2022-10-28 15:50:19','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7685',NULL,'B7044','0',2,1.004,1160,5.688,6.234,1,'AG2018','2022-10-28 15:45:06','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7686',NULL,'B7032','0',2,1.33,1200,8.621,7.656,1,'AG2018','2022-10-28 15:40:15','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7690',NULL,'B7032','0',2,1.33,1200,7.003,7.542,1,'AG2018','2022-10-28 15:41:23','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7691',NULL,'B7032','0',2,1.33,1200,7.03,7.582,1,'AG2018','2022-10-28 15:43:07','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7692',NULL,'B7032','0',2,1.33,1200,7.087,7.64,1,'AG2018','2022-10-28 15:42:08','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7693',NULL,'B7032','0',2,1.33,1200,7.048,7.598,1,'AG2018','2022-10-28 15:40:47','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7695',NULL,'B7032','0',2,1.33,1200,7.079,7.618,1,'AG2018','2022-10-28 15:40:13','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7698',NULL,'B7333','0',2,1.715,1200,8.661,9.211,1,'AG2018','2022-10-28 15:37:45','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7699',NULL,'B7333','0',2,1.625,1200,8.406,8.946,1,'AG2018','2022-10-28 15:36:12','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7700',NULL,'B7333','0',2,1.715,1200,8.674,9.229,1,'AG2018','2022-10-28 15:34:07','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7701',NULL,'B7333','0',2,1.625,1200,8.391,8.934,1,'AG2018','2022-10-28 15:36:47','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7702',NULL,'B7333','0',2,1.625,1200,8.441,8.989,1,'AG2018','2022-10-28 15:35:35','70',1,'Closing/2022','RMD/281022/02',NULL,0),('B7703',NULL,'M0282','2-5-0',4,4.45,2480,59.841,60.654,1,'AG2018','2022-10-29 07:30:39','70',1,'Closing/2022','SBJW/1007/2223',NULL,0),('B7704',NULL,'M0282','2-5-0',4,4.45,2480,60.177,60.989,1,'AG2018','2022-10-29 07:31:44','70',1,'Closing/2022','SBJW/1007/2223',NULL,0),('B7705',NULL,'M0282','2-5-0',4,4.45,2480,59.798,60.606,1,'AG2018','2022-10-29 07:32:43','70',1,'Closing/2022','SBJW/1007/2223',NULL,0),('B7707',NULL,'C0257','2-5-5',4,4.311,2480,49.687,50.682,1,'AG2018','2022-10-29 07:35:48','70',1,'Closing/2022','SBJW/1007/2223',NULL,0),('B7708',NULL,'C0257','2-5-5',4,4.311,2480,49.658,50.471,1,'AG2018','2022-10-29 07:36:48','70',1,'Closing/2022','SBJW/1007/2223',NULL,0),('B7710',NULL,'N6047','2-5-5',1,3.515,920,19.257,20.08,1,'AG2020','2022-10-29 07:41:21','70',1,'Closing/2022','SBJW/1005/2223',NULL,0),('B7711',NULL,'N6047','2-5-5',1,3.515,920,18.581,19.395,1,'AG2018','2022-10-29 07:43:00','70',1,'Closing/2022','SBJW/1005/2223',NULL,0),('B7718',NULL,'C0950','2-7-0',2,4.014,1440,35.196,36.013,1,'AG2018','2022-10-29 08:27:03','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7719',NULL,'C0950','2-7-0',2,4.014,1440,35.333,36.145,1,'AG2018','2022-10-29 08:27:53','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7721',NULL,'C2728','2-6-0',2,3.985,1440,33.451,34.26,1,'AG2018','2022-10-29 08:31:41','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7722',NULL,'C0936','2-5-0',2,3.845,1400,41.56,42.375,1,'AG2018','2022-10-29 08:36:43','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7723',NULL,'C0936','2-5-0',2,3.845,1400,41.029,41.844,1,'AG2018','2022-10-29 08:38:56','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7724',NULL,'C0970','2-5-0',2,3.798,1440,46.276,47.094,1,'AG2018','2022-10-29 08:41:55','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7725',NULL,'C0970','2-5-0',2,3.798,1440,46.008,46.829,1,'AG2018','2022-10-29 08:43:11','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7726',NULL,'C0942','2-7-0',2,3.983,1440,46.866,47.688,1,'AG2018','2022-10-29 08:44:44','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7727',NULL,'C0942','2-7-0',2,3.983,1440,47.106,47.921,1,'AG2018','2022-10-29 08:45:39','70',1,'Closing/2022','SBJW/1006/2223',NULL,0),('B7728',NULL,'L0063','2-6-0',2,6.071,1880,23.52,24.333,1,'AG2018','2022-10-29 10:35:41','70',1,'Closing/2022','SBJW/1008/2223',NULL,0),('B7731',NULL,'N6061','2-5-0',1,2.53,940,17.638,18.447,1,'AG2018','2022-10-29 10:39:39','70',1,'Closing/2022','SBJW/1008/2223',NULL,0),('B7732',NULL,'N6061','2-5-0',1,2.53,940,17.684,18.499,1,'AG2018','2022-10-29 10:40:37','70',1,'Closing/2022','SBJW/1008/2223',NULL,0),('B7737',NULL,'N6062','2-5-0',1,3.47,940,25.352,26.17,1,'AG2018','2022-10-29 10:47:41','70',1,'Closing/2022','SBJW/1008/2223',NULL,0),('B7742',NULL,'C0001','2-5-0',4,4.609,2400,50.345,51.165,1,'AG2018','2022-11-05 14:17:21','70',1,'Closing/2022','SBJW/1040/2223',NULL,0),('B7743',NULL,'C0001','2-5-0',4,4.609,2400,50.262,51.075,1,'AG2018','2022-11-05 14:19:15','70',1,'Closing/2022','SBJW/1040/2223',NULL,0),('B7744',NULL,'C0001','2-5-0',4,4.609,2400,50.25,51.065,1,'AG2018','2022-11-05 14:22:49','70',1,'Closing/2022','SBJW/1040/2223',NULL,0),('B7746',NULL,'N6045','2-5-0',1,3.631,920,23.028,23.835,1,'AG2018','2022-11-08 06:13:39','70',1,'Closing/2022','RMD/081122/02',NULL,0),('B7748',NULL,'C0010','2-5-5',4,4.521,2400,31.307,32.127,1,'AG2018','2022-11-17 05:44:06','70',1,'Closing/2022','1080',NULL,0),('B7749',NULL,'C0010','2-5-5',4,4.521,2400,31.28,32.103,1,'AG2018','2022-11-17 05:45:27','70',1,'Closing/2022','1080',NULL,0),('B7750',NULL,'C0010','2-5-5',4,4.521,2400,31.58,32.403,1,'AG2018','2022-11-17 05:46:35','70',1,'Closing/2022','1080',NULL,0),('B7751',NULL,'C2436','2-5-5',4,4.869,2400,52.922,53.74,1,'AG2018','2022-11-17 05:48:44','70',1,'Closing/2022','1078',NULL,0),('B7752',NULL,'C2436','2-5-5',4,4.869,2400,51.557,52.378,1,'AG2018','2022-11-17 05:49:27','70',1,'Closing/2022','1078',NULL,0),('B7753',NULL,'C2436','2-5-5',4,4.869,2400,53.822,53.645,1,'AG2018','2022-11-17 05:51:06','70',1,'Closing/2022','1078',NULL,0),('B7754',NULL,'C0036','2-5-0',4,4.647,2400,48.171,48.993,1,'AG2018','2022-11-17 06:14:47','70',1,'Closing/2022','1078',NULL,0),('B7755',NULL,'C0036','2-5-0',4,4.647,2400,48.061,48.878,1,'AG2018','2022-11-17 06:15:53','70',1,'Closing/2022','1078',NULL,0),('B7756',NULL,'C0036','2-5-0',4,4.647,2400,49.269,50.091,1,'AG2018','2022-11-17 06:17:03','70',1,'Closing/2022','1078',NULL,0),('B7757',NULL,'C0046','2-6-0',4,4.468,2400,48.234,49.055,1,'AG2018','2022-11-17 06:19:13','70',1,'Closing/2022','1079',NULL,0),('B7758',NULL,'C0046','2-6-0',4,4.468,2400,49.18,49.999,1,'AG2018','2022-11-17 06:20:17','70',1,'Closing/2022','1079',NULL,0),('B7759',NULL,'C0046','2-6-0',4,4.468,2400,48.363,49.181,1,'AG2018','2022-11-17 06:21:23','70',1,'Closing/2022','1079',NULL,0),('B7760',NULL,'C0083','2-5-5',4,4.634,2480,53.514,54.328,1,'AG2018','2022-11-17 06:24:11','70',1,'Closing/2022','1079',NULL,0),('B7761',NULL,'C0083','2-5-5',4,4.634,2480,53.624,54.441,1,'AG2018','2022-11-17 06:26:57','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7763',NULL,'T3103','2-4-0',4,4.292,2400,50.325,51.146,1,'AG2018','2022-11-17 06:42:45','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7764',NULL,'T3103','2-4-0',4,4.292,2400,50.98,51.804,1,'AG2018','2022-11-17 06:43:48','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7765',NULL,'T3103','2-4-0',4,4.292,2400,50.633,51.456,1,'AG2018','2022-11-17 06:44:33','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7766',NULL,'T4938','2-6-5',4,4.359,2400,48.315,49.134,1,'AG2018','2022-11-17 06:46:15','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7767',NULL,'T4938','2-6-5',4,4.359,2400,48.337,49.155,1,'AG2018','2022-11-17 06:48:33','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7768',NULL,'T4938','2-6-5',4,4.359,2400,49.479,50.292,1,'AG2018','2022-11-17 06:49:13','70',1,'Closing/2022','SBJW/1079/2223',NULL,0),('B7769',NULL,'N6058','2-5-0',1,2.601,920,25.547,26.364,1,'AG2020','2022-11-19 06:00:06','70',1,'Closing/2022','SBJW/1093/2223',NULL,0),('B7770',NULL,'N6058','2-6-0',1,2.601,920,25.821,26.635,1,'AG2018','2022-11-19 06:01:57','70',1,'Closing/2022','SBJW/1093/2223',NULL,0),('B7772',NULL,'N6058','2-5-5',1,2.601,920,25.572,26.385,1,'AG2018','2022-11-19 06:05:18','70',1,'Closing/2022','SBJW/1093/2223',NULL,0),('B7773',NULL,'N6058','2-6-5',1,2.601,920,25.756,26.564,1,'AG2018','2022-11-19 06:08:04','70',1,'Closing/2022','SBJW/1093/2223',NULL,0),('B7774',NULL,'N6058','2-5-5',1,2.601,920,25.503,26.322,1,'AG2018','2022-11-19 06:09:06','70',1,'Closing/2022','SBJW/1093/2223',NULL,0),('B7775',NULL,'C0002','2-6-0',4,3.862,2400,46.346,47.16,1,'AG2018','2022-11-19 06:12:13','70',1,'Closing/2022','SBJW/1095/2223',NULL,0),('B7776',NULL,'C0002','2-6-0',4,4.192,2400,46.241,47.053,1,'AG2018','2022-11-19 06:13:32','70',1,'Closing/2022','SBJW/1095/2223',NULL,0),('B7777',NULL,'C0002','2-6-0',4,4.192,2400,46.296,47.109,1,'AG2018','2022-11-19 06:14:27','70',1,'Closing/2022','SBJW/1095/2223',NULL,0),('B7778',NULL,'M0717','2-5-0',2,4.295,1480,52.626,53.437,1,'AG2018','2022-11-19 06:17:13','70',1,'Closing/2022','SBJW/1094/2223',NULL,0),('B7779',NULL,'M0717','2-5-0',2,4.295,1480,53.302,54.124,1,'AG2018','2022-11-19 06:18:41','70',1,'Closing/2022','SBJW/1094/2223',NULL,0),('B7780',NULL,'M0717','2-6-0',2,4.452,1480,54.04,54.856,1,'AG2018','2022-11-19 06:20:25','70',1,'Closing/2022','SBJW/1094/2223',NULL,0),('B7781',NULL,'M0717','2-6-0',2,4.452,1480,54.909,55.726,1,'AG2018','2022-11-19 06:22:00','70',1,'Closing/2022','SBJW/1094/2223',NULL,0),('B7782',NULL,'C2722','2-7-0',2,3.884,1440,44.223,45.041,1,'AG2018','2022-11-19 06:36:11','70',1,'Closing/2022','RMD/191122/03',NULL,0),('B7783',NULL,'C2703','2-6-0',2,3.911,1480,45.563,46.372,1,'AG2018','2022-11-19 06:37:38','70',1,'Closing/2022','RMD/191122/03',NULL,0),('B7784',NULL,'C1427','2-6-0',4,4.063,2400,56.868,57.68,1,'AG2018','2022-11-19 06:40:14','70',1,'Closing/2022','RMD/191122/03',NULL,0),('B7785',NULL,'C0036','2-5-0',4,3.865,2400,45.9,46.723,1,'AG2018','2022-11-19 06:42:24','70',1,'Closing/2022','RMD/191122/03',NULL,0),('B7786',NULL,'C0084','2-5-0',4,4.012,2480,41.229,42.044,1,'AG2018','2022-11-19 06:43:32','70',1,'Closing/2022','RMD/191122/03',NULL,0),('B7787',NULL,'C1750','2-6-0',4,4.649,2480,52.354,53.163,1,'AG2018','2022-11-23 05:48:56','70',1,'Closing/2022','SBJW/1114/2223',NULL,0),('B7788',NULL,'C1750','2-6-0',4,4.649,2480,52.556,53.37,1,'AG2018','2022-11-23 06:24:46','70',1,'Closing/2022','SBJW/1114/2223',NULL,0),('B7789',NULL,'C1750','2-6-0',4,4.649,2480,52.726,53.539,1,'AG2018','2022-11-23 06:25:56','70',1,'Closing/2022','SBJW/1114/2223',NULL,0),('B7790',NULL,'C1648','2-5-0',2,3.412,1480,23.526,24.332,1,'AG2018','2022-11-23 06:27:56','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7791',NULL,'C1648','2-5-0',2,3.412,1480,23.509,24.319,1,'AG2018','2022-11-23 06:28:58','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7792',NULL,'C1648','2-5-0',2,3.412,1480,23.452,24.261,1,'AG2018','2022-11-23 06:29:47','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7793',NULL,'C2722','2-6-0',2,4.035,1440,46.994,47.809,1,'AG2018','2022-11-23 06:32:00','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7794',NULL,'C2722','2-6-0',2,4.035,1440,46.692,47.5,1,'AG2018','2022-11-23 06:34:02','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7795',NULL,'C2722','2-6-0',2,4.035,1440,46.129,46.937,1,'AG2018','2022-11-23 06:34:53','70',1,'Closing/2022','SBJW/1112/2223',NULL,0),('B7796',NULL,'C0219','2-5-0',4,4.674,2480,73.023,73.834,1,'AG2018','2022-11-23 06:37:13','70',1,'Closing/2022','SBJW/1113/2223',NULL,0),('B7797',NULL,'C0219','2-5-0',4,4.674,2480,72.275,73.085,1,'AG2018','2022-11-23 06:38:55','70',1,'Closing/2022','SBJW/1113/2223',NULL,0),('B7798',NULL,'C0380','2-5-5',2,2.98,1280,41.15,41.952,1,'AG2018','2022-11-23 06:40:24','70',1,'Closing/2022','SBJW/1113/2223',NULL,0),('B7799',NULL,'C0380','2-5-5',2,2.98,1280,41.41,42.223,1,'AG2018','2022-11-23 06:41:19','70',1,'Closing/2022','SBJW/1113/2223',NULL,0),('B7800',NULL,'C0380','2-5-5',2,2.98,1280,41.326,42.14,1,'AG2018','2022-11-23 06:42:04','70',1,'Closing/2022','SBJW/1113/2223',NULL,0),('B7801',NULL,'B7032','0',1,0.804,600,4.194,4.741,1,'AG2018','2022-11-23 07:20:38','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7802',NULL,'B7032','0',2,1.609,1200,8.664,9.209,1,'AG2018','2022-11-23 07:22:15','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7803',NULL,'B7032','0',2,1.609,1200,8.863,9.23,1,'AG2018','2022-11-23 07:23:02','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7804',NULL,'B7032','0',2,1.609,1200,8.559,9.109,1,'AG2018','2022-11-23 07:23:46','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7806',NULL,'B7032','0',2,1.609,1200,8.68,9.229,1,'AG2018','2022-11-23 07:25:30','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7807',NULL,'B7032','0',2,1.609,1200,8.434,8.985,1,'AG2018','2022-11-23 07:27:38','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7808',NULL,'B7032','0',2,1.609,1200,8.623,9.174,1,'AG2018','2022-11-23 07:28:30','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7809',NULL,'B7032','0',2,1.609,1200,8.579,9.13,1,'AG2018','2022-11-23 07:29:23','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7810',NULL,'B7032','0',2,1.609,1200,8.548,9.099,1,'AG2018','2022-11-23 07:30:14','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7811',NULL,'B7032','0',2,1.609,1200,8.568,9.114,1,'AG2018','2022-11-23 07:31:04','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7812',NULL,'B7032','0',2,1.609,1200,8.49,9.04,1,'AG2018','2022-11-23 07:31:57','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7813',NULL,'B7032','0',2,1.609,1200,8.628,9.175,1,'AG2018','2022-11-23 07:32:40','70',1,'Closing/2022','SBJW/1115/2223',NULL,0),('B7814',NULL,'C1421','2-5-5',4,4.096,2480,39.768,40.588,1,'AG2018','2022-11-25 11:32:56','70',1,'Closing/2022','SBJW/1120/2223',NULL,0),('B7815',NULL,'C1421','2-5-5',4,4.096,2480,40.096,40.927,1,'AG2018','2022-11-25 11:34:11','70',1,'Closing/2022','SBJW/1120/2223',NULL,0),('B7816',NULL,'C0725','2-6-0',2,4.319,1480,51.026,51.848,1,'AG2018','2022-11-25 11:37:16','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7817',NULL,'C0725','2-6-0',2,4.319,1480,50.607,51.433,1,'AG2018','2022-11-25 11:38:08','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7818',NULL,'C0725','2-6-0',2,4.319,1480,51.088,51.901,1,'AG2018','2022-11-25 11:39:31','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7819',NULL,'C0338','2-6-0',4,4.912,2480,61.923,62.748,1,'AG2018','2022-11-25 11:41:33','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7820',NULL,'C0338','2-6-0',4,4.912,2480,62.104,62.922,1,'AG2018','2022-11-25 11:42:22','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7821',NULL,'C0338','2-6-0',4,4.912,2480,62.732,63.561,1,'AG2018','2022-11-25 11:43:55','70',1,'Closing/2022','SBJW/1119/2223',NULL,0),('B7822',NULL,'B7013','0',1,0.755,600,4.518,5.063,1,'AG2018','2022-11-25 11:49:00','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7823',NULL,'B7013','0',2,1.511,1200,9.166,9.715,1,'AG2018','2022-11-25 11:50:46','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7824',NULL,'B7013','0',2,1.511,1200,9.2,9.747,1,'AG2018','2022-11-25 11:51:35','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7825',NULL,'B7013','0',2,1.511,1200,9.052,9.597,1,'AG2018','2022-11-25 11:52:23','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7826',NULL,'B7013','0',2,1.511,1200,9.18,9.716,1,'AG2018','2022-11-25 11:54:13','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7827',NULL,'B7013','0',2,1.511,1200,8.931,9.476,1,'AG2018','2022-11-25 11:56:06','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7828',NULL,'B7013','0',2,1.511,1200,9.143,9.696,1,'AG2018','2022-11-25 11:56:43','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7829',NULL,'B7013','0',2,1.511,1200,9.035,9.589,1,'AG2018','2022-11-25 11:57:26','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7830',NULL,'B7013','0',2,1.511,1200,9.08,9.62,1,'AG2018','2022-11-25 11:59:32','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7832',NULL,'B7013','0',2,1.511,1200,9.186,9.73,1,'AG2018','2022-11-25 12:02:28','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7833',NULL,'B7013','0',2,1.511,1200,9.075,9.626,1,'AG2018','2022-11-25 12:03:04','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7834',NULL,'B7013','0',2,1.511,1200,9.188,9.74,1,'AG2018','2022-11-25 12:04:15','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7835',NULL,'B7013','0',2,1.511,1200,9.04,9.59,1,'AG2018','2022-11-25 12:05:03','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7836',NULL,'B7013','0',2,1.511,1200,9.085,9.637,1,'AG2018','2022-11-25 12:05:55','70',1,'Closing/2022','SBJW/1121/2223',NULL,0),('B7837',NULL,'T4986','2-6-5',4,4.35,2400,51.35,51.894,1,'AG2018','2022-11-26 05:22:03','70',1,'Closing/2022','SBJW/1133/2223',NULL,0),('B7838',NULL,'T4986','2-6-5',4,4.35,2400,52.061,52.874,1,'AG2018','2022-11-26 05:23:00','70',1,'Closing/2022','SBJW/1133/2223',NULL,0),('B7839',NULL,'T4986','2-6-5',4,4.35,2400,51.67,52.481,1,'AG2018','2022-11-26 05:23:42','70',1,'Closing/2022','SBJW/1133/2223',NULL,0),('B7840',NULL,'T3123','2-6-0',4,4.577,2400,56.38,57.196,1,'AG2018','2022-11-26 05:26:33','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7841',NULL,'T3123','2-6-0',4,4.577,2400,56.77,57.578,1,'AG2018','2022-11-26 05:27:34','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7842',NULL,'T3123','2-6-0',4,4.577,2400,46.924,57.736,1,'AG2018','2022-11-26 05:29:20','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7843',NULL,'C0084','2-5-5',4,4.461,2480,43.514,44.327,1,'AG2018','2022-11-26 05:34:48','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7844',NULL,'C0084','2-5-5',4,4.461,2480,43.085,43.901,1,'AG2018','2022-11-26 05:36:59','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7845',NULL,'C1752','2-5-5',4,4.548,2480,51.746,52.552,1,'AG2018','2022-11-26 05:40:33','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7846',NULL,'C1752','2-5-5',4,4.548,2480,51.611,52.425,1,'AG2018','2022-11-26 05:42:02','70',1,'Closing/2022','SBJW/1132/2223',NULL,0),('B7847',NULL,'B7021','0',2,1.769,1200,9.461,9.996,1,'AG2018','2022-11-26 11:31:09','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7848',NULL,'B7021','0',2,1.769,1200,9.487,10.032,1,'AG2018','2022-11-26 11:32:00','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7850',NULL,'B7021','0',2,1.769,1200,9.381,9.931,1,'AG2018','2022-11-26 11:33:21','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7851',NULL,'B7021','0',2,1.769,1200,9.372,9.922,1,'AG2018','2022-11-26 11:33:52','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7852',NULL,'B7021','0',2,1.769,1200,9.452,10.003,1,'AG2018','2022-11-26 11:34:39','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7853',NULL,'B7021','0',2,1.769,1200,9.392,9.952,1,'AG2018','2022-11-26 11:35:25','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7854',NULL,'B7021','0',2,1.769,1200,9.342,9.902,1,'AG2018','2022-11-26 11:36:17','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7855',NULL,'B7021','0',2,1.769,1200,9.309,9.866,1,'AG2018','2022-11-26 11:37:22','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7856',NULL,'B7021','0',2,1.769,1200,9.426,9.976,1,'AG2018','2022-11-26 11:38:37','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7857',NULL,'B7021','0',2,1.769,1200,9.394,9.948,1,'AG2018','2022-11-26 11:39:12','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7858',NULL,'B7021','0',2,1.769,1200,9.362,9.914,1,'AG2018','2022-11-26 11:40:00','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7859',NULL,'B7021','0',2,1.769,1200,9.459,10.006,1,'AG2018','2022-11-26 11:40:56','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7860',NULL,'B7021','0',2,1.769,1200,9.45,9.994,1,'AG2018','2022-11-26 11:41:46','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7861',NULL,'B7021','0',2,1.769,1200,9.395,9.943,1,'AG2018','2022-11-26 11:42:33','70',1,'Closing/2022','SBJW/1134/2223',NULL,0),('B7862',NULL,'B7042','0',2,1.166,1160,6.411,6.966,1,'AG2018','2022-12-02 07:09:49','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7863',NULL,'B7042','0',2,1.166,1160,6.505,7.066,1,'AG2018','2022-12-02 07:10:39','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7864',NULL,'B7042','0',2,1.166,1160,6.505,7.065,1,'AG2018','2022-12-02 07:11:43','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7865',NULL,'B7042','0',2,1.166,1160,6.48,7.032,1,'AG2018','2022-12-02 07:13:14','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7866',NULL,'B7042','0',2,1.166,1160,6.417,6.963,1,'AG2018','2022-12-02 07:14:49','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7867',NULL,'B7042','0',2,1.166,1160,6.438,6.988,1,'AG2018','2022-12-02 07:15:33','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7868',NULL,'B7042','0',2,1.166,1160,6.381,6.928,1,'AG2018','2022-12-02 07:16:15','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7869',NULL,'B7042','0',2,1.166,1160,6.488,7.038,1,'AG2018','2022-12-02 07:16:54','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7870',NULL,'B7042','0',2,1.166,1160,6.466,7.016,1,'AG2018','2022-12-02 07:17:49','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7871',NULL,'B7042','0',2,1.166,1160,6.418,6.967,1,'AG2018','2022-12-02 07:19:02','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7872',NULL,'B7042','0',2,1.166,1160,6.421,6.966,1,'AG2018','2022-12-02 07:20:21','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7873',NULL,'B7042','0',2,1.166,1160,6.482,7.036,1,'AG2018','2022-12-02 07:21:21','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7874',NULL,'B7042','0',2,1.166,1160,6.459,7.004,1,'AG2018','2022-12-02 07:21:51','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7875',NULL,'B7042','0',2,1.166,1160,6.44,6.987,1,'AG2018','2022-12-02 07:22:29','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7876',NULL,'B7042','0',2,1.166,1160,6.41,6.958,1,'AG2018','2022-12-02 07:23:12','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7877',NULL,'B7042','0',2,1.166,1160,6.431,6.984,1,'AG2018','2022-12-02 07:26:31','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7878',NULL,'B7042','0',2,1.166,1160,6.536,7.08,1,'AG2018','2022-12-02 07:27:19','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7879',NULL,'B7042','0',2,1.166,1160,6.429,6.984,1,'AG2018','2022-12-02 07:27:50','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7880',NULL,'B7042','0',2,1.166,1160,6.519,7.07,1,'AG2018','2022-12-02 07:29:01','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7881',NULL,'B7042','0',2,1.166,1160,6.372,6.933,1,'AG2018','2022-12-02 07:29:34','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7882',NULL,'B7042','0',2,1.166,1160,6.453,7.002,1,'AG2018','2022-12-02 07:30:14','70',1,'Closing/2022','SBJW/1154/2223',NULL,0),('B7883',NULL,'B7048','0',2,1.391,1200,15.409,15.959,1,'AG2018','2022-12-02 12:50:25','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7884',NULL,'B7048','0',2,1.391,1200,15.446,15.984,1,'AG2018','2022-12-02 13:36:00','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7885',NULL,'B7048','0',2,1.391,1200,15.447,15.986,1,'AG2018','2022-12-02 13:36:48','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7886',NULL,'B7048','0',2,1.391,1200,15.477,16.018,1,'AG2018','2022-12-02 13:38:41','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7887',NULL,'B7048','0',2,1.391,1200,15.426,15.973,1,'AG2018','2022-12-02 13:39:36','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7888',NULL,'B7048','0',2,1.391,1200,15.42,15.957,1,'AG2018','2022-12-02 13:40:10','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7889',NULL,'B7048','0',2,1.391,1200,15.383,15.921,1,'AG2018','2022-12-02 13:41:06','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7890',NULL,'B7048','0',2,1.391,1200,15.451,15.993,1,'AG2018','2022-12-02 13:42:33','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7891',NULL,'B7048','0',2,1.391,1200,15.429,15.972,1,'AG2018','2022-12-02 13:43:13','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7892',NULL,'B7048','0',2,1.391,1200,15.461,16.002,1,'AG2018','2022-12-02 13:43:56','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7893',NULL,'B7048','0',2,1.391,1200,15.424,15.97,1,'AG2018','2022-12-02 13:44:57','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7894',NULL,'B7048','0',2,1.391,1200,15.463,16.008,1,'AG2018','2022-12-02 13:46:13','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7895',NULL,'B7048','0',2,1.391,1200,15.411,15.956,1,'AG2018','2022-12-02 13:46:46','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7896',NULL,'B7048','0',2,1.391,1200,15.457,16.001,1,'AG2018','2022-12-02 13:47:38','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7897',NULL,'B7048','0',2,1.391,1200,15.444,15.982,1,'AG2018','2022-12-02 13:48:17','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7898',NULL,'B7048','0',2,1.391,1200,15.424,15.966,1,'AG2018','2022-12-02 13:48:56','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7899',NULL,'B7048','0',2,1.391,1200,15.413,15.971,1,'AG2018','2022-12-02 13:50:10','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7900',NULL,'B7048','0',2,1.391,1200,15.449,16.001,1,'AG2018','2022-12-02 13:51:31','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7901',NULL,'B7048','0',2,1.391,1200,15.496,16.042,1,'AG2018','2022-12-02 13:52:21','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7902',NULL,'B7048','0',2,1.391,1200,15.468,16.014,1,'AG2018','2022-12-02 13:53:06','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7903',NULL,'B7048','0',2,1.391,1200,15.412,15.959,1,'AG2018','2022-12-02 13:54:59','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7904',NULL,'B7048','0',2,1.391,1200,15.403,15.954,1,'AG2018','2022-12-02 13:55:44','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7905',NULL,'B7048','0',2,1.391,1200,15.454,15.998,1,'AG2018','2022-12-02 13:56:19','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7906',NULL,'B7048','0',2,1.391,1200,15.402,15.947,1,'AG2018','2022-12-02 13:57:19','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7907',NULL,'B7048','0',2,1.391,1200,15.405,15.953,1,'AG2018','2022-12-02 13:58:07','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7908',NULL,'B7048','0',2,1.391,1200,15.524,16.077,1,'AG2018','2022-12-02 13:58:55','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7909',NULL,'B7048','0',2,1.391,1200,15.451,15.998,1,'AG2018','2022-12-02 14:01:05','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7910',NULL,'B7048','0',2,1.391,1200,15.414,15.964,1,'AG2018','2022-12-02 14:01:50','70',1,'Closing/2022','SBJW/1155/2223',NULL,0),('B7911',NULL,'X0004','2-4-5',1,2.476,920,21.415,22.229,1,'AG2018','2022-12-02 14:05:41','70',1,'Closing/2022','RMD/021222/03',NULL,0);

--
-- Table structure for table `job_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `job_master` (
  `job_id` int(11) NOT NULL,
  `order_id` varchar(25) DEFAULT NULL,
  `order_serial` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `product_code` varchar(25) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `pieces` int(11) NOT NULL,
  `product_size` varchar(12) DEFAULT NULL,
  `job_date` int(11) DEFAULT NULL,
  `delivery_date` int(11) DEFAULT NULL,
  `expected_gold` double DEFAULT 0,
  `p_loss` double DEFAULT 0,
  `tr_date` int(11) DEFAULT 0,
  `tr_time` timestamp NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT 0,
  `emp_id` int(11) DEFAULT NULL,
  `price_method` varchar(10) DEFAULT NULL,
  `price_code` varchar(255) DEFAULT NULL,
  `price` double DEFAULT 0,
  `gold_send` double DEFAULT 0,
  `dal_send` double DEFAULT 0,
  `pan_send` double DEFAULT 0,
  `bronze_send` double DEFAULT 0,
  `copper_send` double DEFAULT 0,
  `gold_returned` double DEFAULT 0,
  `dal_returned` double DEFAULT 0,
  `pan_returned` double DEFAULT 0,
  `bronze_returned` double DEFAULT 0,
  `nitrick_returned` double DEFAULT 0,
  `copper_return` double DEFAULT 0,
  `product_wt` double DEFAULT 0,
  `comments` varchar(255) DEFAULT 'none',
  `dal_id` int(11) DEFAULT NULL,
  `pan_id` int(11) DEFAULT 0,
  `bronze_id` int(11) DEFAULT NULL,
  `copper_id` int(11) DEFAULT NULL,
  `markup_value` double DEFAULT 0,
  `in_stock` int(10) unsigned DEFAULT 0,
  `ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_master`
--


--
-- Table structure for table `lc_receipt_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `lc_receipt_master` (
  `lc_receipt_no` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `lc_receipt_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `cust_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `mode` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `cheque_details` varchar(50) CHARACTER SET utf8 DEFAULT 'No',
  `agent_id` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `discount` double DEFAULT 0,
  PRIMARY KEY (`lc_receipt_no`),
  KEY `cust_id` (`cust_id`),
  KEY `agent_id` (`agent_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `lc_receipt_master_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`),
  CONSTRAINT `lc_receipt_master_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`),
  CONSTRAINT `lc_receipt_master_ibfk_3` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lc_receipt_master`
--


--
-- Table structure for table `ledger_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ledger_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ledger_type_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger_types`
--

INSERT INTO `ledger_types` (`id`, `ledger_type_name`, `value`, `created_at`, `updated_at`) VALUES (1,'Income',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(2,'Expenditure',-1,'2021-11-03 07:30:58','2021-11-03 07:30:58');

--
-- Table structure for table `ledgers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ledgers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ledger_type_id` bigint(20) unsigned NOT NULL,
  `ledger_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ledgers_ledger_type_id_foreign` (`ledger_type_id`),
  CONSTRAINT `ledgers_ledger_type_id_foreign` FOREIGN KEY (`ledger_type_id`) REFERENCES `ledger_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledgers`
--

INSERT INTO `ledgers` (`id`, `ledger_type_id`, `ledger_name`, `inforce`, `created_at`, `updated_at`) VALUES (1,1,'Received from Owner',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(2,1,'Received LC',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(3,1,'Refinish income',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(4,1,'Misc. Received',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(5,2,'Withdraw by Owner',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(6,2,'Electricity Bill Paid',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(7,2,'Municipal Tax',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(8,2,'Saraswati Puja Expenditure',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(9,2,'Biswakarma Puja Expenditure',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(10,2,'Daily Puja Expenditure',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(11,2,'Daily Tiffin Expenditure',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(12,2,'Muchi',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(13,2,'Sweeper',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(14,2,'Van Rent',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(15,2,'Car Rent',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(16,2,'TA for Salesman',1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(17,2,'Gas Equipment purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(18,2,'Donation Paid',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(19,2,'Market Expenditure for owner',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(20,2,'Gas Expenditure',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(21,2,'Salary paid',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(22,2,'Misc. Expenditure',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(23,2,'Cleaning Material Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(24,2,'Bala Making Charge Paid',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(25,2,'Dice Charge paid',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(26,2,'Color Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(27,2,'Electric worker paid ',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(28,2,'Electric Equipment Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(29,2,'Costic Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(30,2,'Acid Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(31,2,'Sohaga Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(32,2,'Bronze Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(33,2,'Copper Purchase',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(34,2,'Phone Bill Paid',1,'2021-11-03 07:30:59','2021-11-03 07:30:59');

--
-- Table structure for table `log_table`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `log_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(255) DEFAULT NULL,
  `old_value` double DEFAULT NULL,
  `new_value` double DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `reference` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `old_closing_balance` double DEFAULT NULL,
  `new_closing_balance` double DEFAULT NULL,
  `transaction_time` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_table`
--


--
-- Table structure for table `login_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `login_details` (
  `login_id` int(11) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `login_date` int(11) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_date` int(11) DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  `login_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`login_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_details`
--


--
-- Table structure for table `material_inward_outward`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_inward_outward` (
  `material_inward_outward_id` varchar(20) NOT NULL DEFAULT '',
  `employee_id` int(11) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `transaction_id` varchar(20) DEFAULT NULL,
  `inward_value` double DEFAULT NULL,
  `outward_value` double DEFAULT NULL,
  `material_inward_outward_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`material_inward_outward_id`),
  KEY `material_inward_outward_status_id` (`material_inward_outward_status_id`),
  KEY `employee_id` (`employee_id`),
  KEY `material_id` (`material_id`),
  CONSTRAINT `material_inward_outward_ibfk_1` FOREIGN KEY (`material_inward_outward_status_id`) REFERENCES `material_inward_outward_status` (`material_inward_outward_status_id`) ON UPDATE CASCADE,
  CONSTRAINT `material_inward_outward_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`emp_id`) ON UPDATE CASCADE,
  CONSTRAINT `material_inward_outward_ibfk_3` FOREIGN KEY (`material_id`) REFERENCES `rm_master` (`rm_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_inward_outward`
--


--
-- Table structure for table `material_inward_outward_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_inward_outward_status` (
  `material_inward_outward_status_id` int(11) NOT NULL DEFAULT 0,
  `material_inward_outward_status_details` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`material_inward_outward_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_inward_outward_status`
--


--
-- Table structure for table `material_to_cash`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_to_cash` (
  `material_to_cash_id` varchar(20) NOT NULL DEFAULT '',
  `material_id` int(11) DEFAULT NULL,
  `material_rate` int(11) DEFAULT NULL,
  `material_qty` double DEFAULT NULL,
  `cash` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `comment` varchar(20) DEFAULT NULL,
  `record_time` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`material_to_cash_id`),
  KEY `material_id` (`material_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `material_to_cash_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `rm_master` (`rm_ID`),
  CONSTRAINT `material_to_cash_ibfk_2` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_to_cash`
--


--
-- Table structure for table `material_to_employee_balance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_to_employee_balance` (
  `material_balance_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `rm_id` int(11) NOT NULL,
  `inward` double NOT NULL DEFAULT 0,
  `outward` double NOT NULL DEFAULT 0,
  `opening_balance` double NOT NULL DEFAULT 0,
  `closing_balance` double NOT NULL DEFAULT 0,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`material_balance_id`),
  UNIQUE KEY `Uni_key_emp_rm` (`emp_id`,`rm_id`),
  KEY `material_balance_id` (`material_balance_id`),
  KEY `rm_id` (`rm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42383 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_to_employee_balance`
--

INSERT INTO `material_to_employee_balance` (`material_balance_id`, `emp_id`, `rm_id`, `inward`, `outward`, `opening_balance`, `closing_balance`, `update_time`) VALUES (553,33,31,0,0,0,0,'2022-12-13 18:08:11'),(554,28,31,0,0,0,0,'2022-12-13 18:08:11'),(555,33,36,0,0,0,0,'2022-12-13 18:08:11'),(556,28,36,0,0,0,0,'2022-12-13 18:08:11'),(557,33,48,0,0,0,0,'2022-12-13 18:08:11'),(558,28,48,0,0,0,0,'2022-12-13 18:08:11'),(559,33,37,0,0,0,0,'2022-12-13 18:08:11'),(560,28,37,0,0,0,0,'2022-12-13 18:08:11'),(561,33,33,0,0,0,0,'2022-12-13 18:08:11'),(562,28,33,0,0,0,0,'2022-12-13 18:08:11'),(563,33,44,0,0,0,0,'2022-12-13 18:08:11'),(564,28,44,0,0,0,0,'2022-12-13 18:08:11'),(565,41,33,0,0,0,0,'2022-12-13 18:08:11'),(567,41,31,0,0,0,0,'2022-12-13 18:08:11'),(569,42,33,0,0,0,0,'2022-12-13 18:08:11'),(571,42,31,0,0,0,0,'2022-12-13 18:08:11'),(573,54,33,0,0,0,0,'2022-12-13 18:08:11'),(575,54,31,0,0,0,0,'2022-12-13 18:08:11'),(577,60,33,0,0,0,0,'2022-12-13 18:08:11'),(579,60,31,0,0,0,0,'2022-12-13 18:08:11'),(595,54,44,0,0,0,0,'2022-12-13 18:08:11'),(598,60,44,0,0,0,0,'2022-12-13 18:08:11'),(604,41,44,0,0,0,0,'2022-12-13 18:08:11'),(622,42,44,0,0,0,0,'2022-12-13 18:08:11'),(623,33,45,0,0,0,0,'2022-12-13 18:08:11'),(642,35,48,0,0,0,0,'2022-12-13 18:08:11'),(667,49,33,0,0,0,0,'2022-12-13 18:08:11'),(669,49,31,0,0,0,0,'2022-12-13 18:08:11'),(674,50,33,0,0,0,0,'2022-12-13 18:08:11'),(676,50,31,0,0,0,0,'2022-12-13 18:08:11'),(813,49,44,0,0,0,0,'2022-12-13 18:08:11'),(866,35,36,0,0,0,0,'2022-12-13 18:08:11'),(988,35,45,0,0,0,0,'2022-12-13 18:08:11'),(1134,35,31,0,0,0,0,'2022-12-13 18:08:11'),(1180,28,45,0,0,0,0,'2022-12-13 18:08:11'),(1233,35,37,0,0,0,0,'2022-12-13 18:08:11'),(1384,50,44,0,0,0,0,'2022-12-13 18:08:11'),(1791,41,48,0,0,0,0,'2022-12-13 18:08:11'),(1987,41,45,0,0,0,0,'2022-12-13 18:08:11'),(2119,48,33,0,0,0,0,'2022-12-13 18:08:11'),(2121,48,31,0,0,0,0,'2022-12-13 18:08:11'),(2148,61,48,0,0,0,0,'2022-12-13 18:08:11'),(2258,61,45,0,0,0,0,'2022-12-13 18:08:11'),(2373,48,44,0,0,0,0,'2022-12-13 18:08:11'),(2385,62,48,0,0,0,0,'2022-12-13 18:08:11'),(2578,62,45,0,0,0,0,'2022-12-13 18:08:11'),(2623,34,33,0,0,0,0,'2022-12-13 18:08:11'),(2624,34,44,0,0,0,0,'2022-12-13 18:08:11'),(2626,34,31,0,0,0,0,'2022-12-13 18:08:11'),(2637,62,36,0,0,0,0,'2022-12-13 18:08:11'),(2641,61,36,0,0,0,0,'2022-12-13 18:08:11'),(2690,23,44,0,0,0,0,'2022-12-13 18:08:11'),(2779,41,32,0,0,0,0,'2022-12-13 18:08:11'),(2780,33,32,0,0,0,0,'2022-12-13 18:08:11'),(2840,35,33,0,0,0,0,'2022-12-13 18:08:11'),(2850,62,31,0,0,0,0,'2022-12-13 18:08:11'),(2903,61,31,0,0,0,0,'2022-12-13 18:08:11'),(2935,62,37,0,0,0,0,'2022-12-13 18:08:11'),(2999,63,36,0,0,0,0,'2022-12-13 18:08:11'),(3006,63,48,0,0,0,0,'2022-12-13 18:08:11'),(3008,63,45,0,0,0,0,'2022-12-13 18:08:11'),(3016,63,31,0,0,0,0,'2022-12-13 18:08:11'),(3115,63,37,0,0,0,0,'2022-12-13 18:08:11'),(3134,64,48,0,0,0,0,'2022-12-13 18:08:11'),(3188,64,45,0,0,0,0,'2022-12-13 18:08:11'),(3226,64,31,0,0,0,0,'2022-12-13 18:08:11'),(3245,64,36,0,0,0,0,'2022-12-13 18:08:11'),(3284,34,48,0,0,0,0,'2022-12-13 18:08:11'),(3306,50,48,0,0,0,0,'2022-12-13 18:08:11'),(3343,35,44,0,0,0,0,'2022-12-13 18:08:11'),(3485,62,33,0,0,0,0,'2022-12-13 18:08:11'),(3527,61,0,0,0,0,0,'2022-12-13 18:08:11'),(3543,56,33,0,0,0,0,'2022-12-13 18:08:11'),(3544,56,44,0,0,0,0,'2022-12-13 18:08:11'),(3633,56,31,0,0,0,0,'2022-12-13 18:08:11'),(3683,35,32,0,0,0,0,'2022-12-13 18:08:11'),(3684,28,32,0,0,0,0,'2022-12-13 18:08:11'),(3752,63,33,0,0,0,0,'2022-12-13 18:08:11'),(3758,65,48,0,0,0,0,'2022-12-13 18:08:11'),(3777,65,45,0,0,0,0,'2022-12-13 18:08:11'),(3788,65,31,0,0,0,0,'2022-12-13 18:08:11'),(3791,49,48,0,0,0,0,'2022-12-13 18:08:11'),(3794,49,45,0,0,0,0,'2022-12-13 18:08:11'),(3881,66,33,0,0,0,0,'2022-12-13 18:08:11'),(3882,66,44,0,0,0,0,'2022-12-13 18:08:11'),(3884,66,31,0,0,0,0,'2022-12-13 18:08:11'),(3927,63,42,0,0,0,0,'2022-12-13 18:08:11'),(3929,68,45,0,0,0,0,'2022-12-13 18:08:11'),(3930,68,48,0,0,0,0,'2022-12-13 18:08:11'),(3931,69,31,0,0,0,0,'2022-12-13 18:08:11'),(3933,69,33,0,0,0,0,'2022-12-13 18:08:11'),(3934,69,44,0,0,0,0,'2022-12-13 18:08:11'),(3955,23,36,0,0,0,0,'2022-12-13 18:08:11'),(3956,48,36,0,0,0,0,'2022-12-13 18:08:11'),(3990,70,36,0,0,0,0,'2022-12-13 18:08:11'),(3992,70,31,0,0,0,0,'2022-12-13 18:08:11'),(3994,70,33,0,0,0,0,'2022-12-13 18:08:11'),(3996,70,48,0,0,0,0,'2022-12-13 18:08:11'),(3998,70,44,0,0,0,0,'2022-12-13 18:08:11'),(4005,70,45,0,0,0,0,'2022-12-13 18:08:11'),(4034,67,33,0,0,0,0,'2022-12-13 18:08:11'),(4036,67,31,0,0,0,0,'2022-12-13 18:08:11'),(4224,67,44,0,0,0,0,'2022-12-13 18:08:11'),(4428,70,32,0,0,0,0,'2022-12-13 18:08:11'),(4612,69,32,0,0,0,0,'2022-12-13 18:08:11'),(4662,23,31,0,0,0,0,'2022-12-13 18:08:11'),(4677,23,33,0,0,0,0,'2022-12-13 18:08:11'),(4713,70,42,0,0,0,0,'2022-12-13 18:08:11'),(4953,60,48,0,0,0,0,'2022-12-13 18:08:11'),(5237,60,36,0,0,0,0,'2022-12-13 18:08:11'),(5245,33,42,0,0,0,0,'2022-12-13 18:08:11'),(5265,46,36,0,0,0,0,'2022-12-13 18:08:11'),(5543,28,42,0,0,0,0,'2022-12-13 18:08:11'),(5664,60,32,0,0,0,0,'2022-12-13 18:08:11'),(5683,42,32,0,0,0,0,'2022-12-13 18:08:11'),(5769,33,41,0,0,0,0,'2022-12-13 18:08:11'),(5770,28,41,0,0,0,0,'2022-12-13 18:08:11'),(5881,35,42,0,0,0,0,'2022-12-13 18:08:11'),(5921,71,31,0,0,0,0,'2022-12-13 18:08:11'),(5923,71,33,0,0,0,0,'2022-12-13 18:08:11'),(5973,71,44,0,0,0,0,'2022-12-13 18:08:11'),(5992,70,37,0,0,0,0,'2022-12-13 18:08:11'),(6125,69,48,0,0,0,0,'2022-12-13 18:08:11'),(6429,46,48,0,0,0,0,'2022-12-13 18:08:11'),(6599,58,45,0,0,0,0,'2022-12-13 18:08:11'),(6631,71,32,0,0,0,0,'2022-12-13 18:08:11'),(6906,60,42,0,0,0,0,'2022-12-13 18:08:11'),(6907,58,42,0,0,0,0,'2022-12-13 18:08:11'),(6916,72,36,0,0,0,0,'2022-12-13 18:08:11'),(6937,72,31,0,0,0,0,'2022-12-13 18:08:11'),(6939,72,33,0,0,0,0,'2022-12-13 18:08:11'),(6941,72,38,0,0,0,0,'2022-12-13 18:08:11'),(6942,28,38,0,0,0,0,'2022-12-13 18:08:11'),(6943,72,37,0,0,0,0,'2022-12-13 18:08:11'),(6945,72,39,0,0,0,0,'2022-12-13 18:08:11'),(6946,28,39,0,0,0,0,'2022-12-13 18:08:11'),(7033,72,42,0,0,0,0,'2022-12-13 18:08:11'),(7034,72,48,0,0,0,0,'2022-12-13 18:08:11'),(7035,72,41,0,0,0,0,'2022-12-13 18:08:11'),(7075,0,33,0,0,0,0,'2022-12-13 18:08:11'),(7076,0,44,0,0,0,0,'2022-12-13 18:08:11'),(7077,0,0,0,0,0,0,'2022-12-13 18:08:11'),(7218,50,42,0,0,0,0,'2022-12-13 18:08:11'),(7264,60,45,0,0,0,0,'2022-12-13 18:08:11'),(7292,74,45,0,0,0,0,'2022-12-13 18:08:11'),(7300,46,45,0,0,0,0,'2022-12-13 18:08:11'),(7348,73,36,0,0,0,0,'2022-12-13 18:08:11'),(7422,72,45,0,0,0,0,'2022-12-13 18:08:11'),(7566,75,31,0,0,0,0,'2022-12-13 18:08:11'),(7568,75,33,0,0,0,0,'2022-12-13 18:08:11'),(7644,75,44,0,0,0,0,'2022-12-13 18:08:11'),(7764,76,31,0,0,0,0,'2022-12-13 18:08:11'),(7766,76,33,0,0,0,0,'2022-12-13 18:08:11'),(7780,76,44,0,0,0,0,'2022-12-13 18:08:11'),(7781,76,32,0,0,0,0,'2022-12-13 18:08:11'),(7883,76,42,0,0,0,0,'2022-12-13 18:08:11'),(7959,78,33,0,0,0,0,'2022-12-13 18:08:11'),(7960,78,44,0,0,0,0,'2022-12-13 18:08:11'),(8122,78,31,0,0,0,0,'2022-12-13 18:08:11'),(8145,81,33,0,0,0,0,'2022-12-13 18:08:11'),(8146,81,44,0,0,0,0,'2022-12-13 18:08:11'),(8148,81,31,0,0,0,0,'2022-12-13 18:08:11'),(8363,42,45,0,0,0,0,'2022-12-13 18:08:11'),(8419,82,33,0,0,0,0,'2022-12-13 18:08:11'),(8421,82,31,0,0,0,0,'2022-12-13 18:08:11'),(8523,82,44,0,0,0,0,'2022-12-13 18:08:11'),(9118,83,31,0,0,0,0,'2022-12-13 18:08:11'),(9120,83,33,0,0,0,0,'2022-12-13 18:08:11'),(9148,74,33,0,0,0,0,'2022-12-13 18:08:11'),(9152,74,44,0,0,0,0,'2022-12-13 18:08:11'),(9154,74,31,0,0,0,0,'2022-12-13 18:08:11'),(9192,73,33,0,0,0,0,'2022-12-13 18:08:11'),(9194,73,31,0,0,0,0,'2022-12-13 18:08:11'),(9248,73,44,0,0,0,0,'2022-12-13 18:08:11'),(9480,83,44,0,0,0,0,'2022-12-13 18:08:11'),(9494,84,48,0,0,0,0,'2022-12-13 18:08:11'),(9587,84,45,0,0,0,0,'2022-12-13 18:08:11'),(9666,84,31,0,0,0,0,'2022-12-13 18:08:11'),(10559,46,31,0,0,0,0,'2022-12-13 18:08:11'),(10873,86,31,0,0,0,0,'2022-12-13 18:08:11'),(10874,86,36,0,0,0,0,'2022-12-13 18:08:11'),(10875,86,45,0,0,0,0,'2022-12-13 18:08:11'),(10876,86,48,0,0,0,0,'2022-12-13 18:08:11'),(10922,87,31,0,0,0,0,'2022-12-13 18:08:11'),(10924,87,33,0,0,0,0,'2022-12-13 18:08:11'),(11094,87,44,0,0,0,0,'2022-12-13 18:08:11'),(12017,88,31,0,0,0,0,'2022-12-13 18:08:11'),(12019,88,33,0,0,0,0,'2022-12-13 18:08:11'),(12114,88,44,0,0,0,0,'2022-12-13 18:08:11'),(12215,69,45,0,0,0,0,'2022-12-13 18:08:11'),(12790,86,33,0,0,0,0,'2022-12-13 18:08:11'),(12940,90,31,0,0,0,0,'2022-12-13 18:08:11'),(12941,90,33,0,0,0,0,'2022-12-13 18:08:11'),(12942,90,36,0,0,0,0,'2022-12-13 18:08:11'),(12943,90,45,0,0,0,0,'2022-12-13 18:08:11'),(12944,90,48,0,0,0,0,'2022-12-13 18:08:11'),(13675,90,44,0,0,0,0,'2022-12-13 18:08:11'),(33474,50,32,0,0,0,0,'2022-12-13 18:08:11'),(37691,92,36,0,0,0,0,'2022-12-13 18:08:11'),(37692,92,48,0,0,0,0,'2022-12-13 18:08:11'),(37788,92,31,0,0,0,0,'2022-12-13 18:08:11'),(37808,92,45,0,0,0,0,'2022-12-13 18:08:11');

--
-- Table structure for table `material_transaction`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_transaction` (
  `transaction_id` varchar(30) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `rm_id` int(11) NOT NULL,
  `inward` double NOT NULL DEFAULT 0,
  `outward` double NOT NULL DEFAULT 0,
  `job_id` int(11) NOT NULL,
  `reference` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `record_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `comment` varchar(100) DEFAULT NULL,
  `transaction_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `employee_id` (`employee_id`),
  KEY `rm_id` (`rm_id`),
  KEY `transaction_type_id` (`transaction_type_id`),
  CONSTRAINT `material_transaction_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`emp_id`) ON UPDATE CASCADE,
  CONSTRAINT `material_transaction_ibfk_2` FOREIGN KEY (`rm_id`) REFERENCES `rm_master` (`rm_ID`) ON UPDATE CASCADE,
  CONSTRAINT `material_transaction_ibfk_3` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`transaction_type_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_transaction`
--


--
-- Table structure for table `material_transaction_map`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_transaction_map` (
  `map_id` varchar(30) NOT NULL,
  `transaction_id` varchar(30) NOT NULL,
  `tr_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `emp_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`map_id`,`transaction_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `emp_id` (`emp_id`),
  CONSTRAINT `material_transaction_map_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`) ON UPDATE CASCADE,
  CONSTRAINT `material_transaction_map_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `material_transaction` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_transaction_map`
--


--
-- Table structure for table `material_transformation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_transformation` (
  `trnasformation_id` varchar(25) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `particulars` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `tr_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`trnasformation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_transformation`
--


--
-- Table structure for table `material_transformation_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_transformation_details` (
  `material_transformation_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_transformation_master_id` varchar(20) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `rm_value` double DEFAULT NULL,
  `tr_type` int(11) DEFAULT -1,
  PRIMARY KEY (`material_transformation_details_id`),
  KEY `material_transformation_master_id` (`material_transformation_master_id`),
  KEY `material_transformation_master_2` (`material_transformation_master_id`),
  CONSTRAINT `material_transformation_details_ibfk_1` FOREIGN KEY (`material_transformation_master_id`) REFERENCES `material_transformation_master` (`material_transformation_master_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_transformation_details`
--


--
-- Table structure for table `material_transformation_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `material_transformation_master` (
  `material_transformation_master_id` varchar(20) NOT NULL DEFAULT '',
  `employee_id` int(11) DEFAULT NULL,
  `record_time` timestamp NULL DEFAULT current_timestamp(),
  `karigar_id` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`material_transformation_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_transformation_master`
--


--
-- Table structure for table `maxtable`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `maxtable` (
  `table_id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) DEFAULT 'None',
  `mainfield` int(10) unsigned DEFAULT NULL,
  `prefix` varchar(255) DEFAULT 'None',
  `suffix` varchar(255) DEFAULT 'None',
  `lock_field` int(11) DEFAULT 0,
  `financial_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`table_id`),
  UNIQUE KEY `Uni_key` (`table_name`,`financial_year`)
) ENGINE=InnoDB AUTO_INCREMENT=12582 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maxtable`
--

INSERT INTO `maxtable` (`table_id`, `table_name`, `mainfield`, `prefix`, `suffix`, `lock_field`, `financial_year`) VALUES (0,'cash_transaction_between_employees',107,'CTBE','CTBE',0,1718),(3,'job_master',0,NULL,'1213',0,NULL),(94,'order_master',2240,'None','None',0,1617),(96,'material_transaction_map',1319,'None','None',0,1617),(97,'material_transaction',2638,'MT','None',0,1617),(107,'gold_receipt_master',2276,'GLR','None',0,1617),(108,'lc_receipt_master',1939,'LCR','None',0,1617),(113,'bill_master',2851,'CIV','None',0,1617),(181,'customer',323,'S','None',0,1),(182,'bill_master',3160,'SBJW','SBJW',0,1718),(191,'order_master',2642,'ORD','ORD',0,1718),(201,'material_transaction_map',1333,'MTP','MTP',0,1718),(202,'material_transaction',3511,'MT','MT',0,1718),(265,'gold_receipt_master',2377,'GR','GR',0,1718),(267,'lc_receipt_master',2136,'LR','LR',0,1718),(338,'material_transformation',89,'MTR','None',0,1718),(344,'cash_transaction_between_employees_2',105,'CWM','None',0,1718),(458,'fine_to_cash',7,'FNC','None',0,1718),(459,'cash_book',7,'CB','None',0,1718),(490,'gold_receipt_master',2217,'GRM','GRM',0,1819),(491,'lc_receipt_master',1947,'LRM','LRM',0,1819),(492,'order_master',2436,'OM','OM',0,1819),(493,'material_transaction',2902,'MT','MT',0,1819),(500,'material_transaction_map',712,'MTM','MTM',0,1819),(511,'bill_master',2869,'SBJW','SBJW',0,1819),(529,'cash_transaction_between_employees',16,'CTE','CTE',0,1819),(533,'cash_transaction_between_employees_2',177,'CWM','CWM',0,1819),(585,'customer_discount',142,'DISC','DISC',0,1819),(623,'material_transformation',1,'MTR','MT',0,1819),(768,'lc_receipt_master',1451,'LRM','LRM',0,1920),(769,'order_master',1834,'OM','OM',0,1920),(774,'gold_receipt_master',1714,'GRM','GRM',0,1920),(775,'material_transaction',2393,'MT','MT',0,1920),(776,'cash_transaction_between_employees_2',13,'CTE','CTE',0,1920),(782,'bill_master',2277,'SBJW','SBJW',0,1920),(796,'material_transaction_map',1162,'MTM','MTM',0,1920),(897,'cash_transaction_between_employees',68,'None','None',0,1920),(904,'material_transformation',19,'MTR','None',0,1920),(962,'fine_to_cash',9,'FNC','None',0,1920),(963,'cash_book',9,'CB','None',0,1920),(964,'order_master',705,'SBJW','None',0,2021),(965,'material_transaction_map',440,'SBJW','None',0,2021),(966,'material_transaction',879,'SBJW','None',0,2021),(967,'gold_receipt_master',714,'SBJW','None',0,2021),(977,'bill_master',905,'SBJW','None',0,2021),(980,'lc_receipt_master',564,'SBJW','None',0,2021),(1069,'cash_transaction_between_employees',18,'CTE','None',0,2021),(1260,'gold_receipt_master',1872,'GRM','None',0,2122),(1269,'lc_receipt_master',1399,'LRM','None',0,2122),(1276,'order_master',1636,'OM','None',0,2122),(1283,'bill_master',2375,'SBJW','None',0,2122),(1289,'material_transaction_map',1061,'MTM','None',0,2122),(1290,'material_transaction',2122,'MT','None',0,2122),(1364,'cash_transaction_between_employees',41,'CTE','None',0,2122),(7413,'bill_master',0,'SBJW','None',0,2223),(7421,'order_master',0,'ORD','None',0,2223),(7422,'material_transaction_map',0,'SBJW','None',0,2223),(7423,'material_transaction',0,'SBJW','None',0,2223),(7426,'gold_receipt_master',0,'SBJW','None',0,2223),(7427,'lc_receipt_master',0,'SBJW','None',0,2223),(7648,'cash_transaction_between_employees',0,'None','None',0,2223);

--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2013_11_23_193732_create_user_types_table',1),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'3020_05_11_152837_create_all_procedures_and_functions',2),(7,'2021_09_08_122801_create_price_masters_table',3),(8,'2021_09_29_001401_create_raw_materials_table',3),(9,'2021_11_01_224532_create_ledger_types_table',3),(10,'2021_11_01_225648_create_ledgers_table',3),(11,'2021_11_01_230836_create_assets_table',3),(12,'2021_11_01_231214_create_vouchers_table',3),(13,'2021_11_02_121407_create_transactions_table',3),(14,'2021_11_02_201908_create_custom_vouchers_table',3),(15,'2022_07_06_132843_create_salary_holders_table',4),(18,'2022_07_22_130829_create_salary_holder_salary_months_table',6),(20,'2022_07_21_130603_create_salary_holder_salaries_table',7),(21,'2022_07_27_131331_create_salary_holder_salary_payments_table',8),(22,'2022_10_21_134655_create_sale_returns_table',9);

--
-- Table structure for table `model_size`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `model_size` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_size`
--

INSERT INTO `model_size` (`ID`, `size`) VALUES (1,'1-2-3'),(2,'4-5-6'),(3,'4-0-9');

--
-- Table structure for table `oldprice_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `oldprice_master` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `price_code` varchar(55) DEFAULT 'None',
  `price` double DEFAULT 0,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` varchar(55) DEFAULT NULL,
  KEY `price_id` (`price_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oldprice_master`
--

INSERT INTO `oldprice_master` (`price_id`, `price_code`, `price`, `time_stamp`, `user_id`) VALUES (1,'A',115,'2012-10-28 12:51:50','vivek'),(2,'B',120,'2012-10-28 12:51:50','vivek'),(3,'C',125,'2012-10-28 12:51:50','vivek'),(4,'D',130,'2012-10-28 12:51:50','vivek'),(5,'E',135,'2012-10-28 12:51:50','vivek'),(6,'F',140,'2012-10-28 12:51:50','vivek'),(7,'G',145,'2012-10-28 12:51:50','vivek'),(8,'H',150,'2012-10-28 12:51:50','vivek'),(9,'I',155,'2012-10-28 12:51:50','vivek'),(10,'J',160,'2012-10-28 12:51:50','vivek'),(11,'K',165,'2012-10-28 12:51:50','vivek'),(12,'L',170,'2012-10-28 12:51:50','vivek'),(13,'M',175,'2012-10-28 12:51:50','vivek'),(14,'N',180,'2012-10-28 12:51:50','vivek'),(15,'O',185,'2012-10-28 12:51:50','vivek'),(16,'P',290,'2012-10-28 12:51:50','vivek'),(17,'Q',295,'2012-10-28 12:51:50','vivek'),(18,'R',200,'2012-10-28 12:51:50','vivek'),(19,'S',205,'2012-10-28 12:51:50','vivek'),(20,'T',210,'2012-10-28 12:51:50','vivek'),(21,'U',215,'2012-10-28 12:51:50','vivek'),(22,'V',220,'2012-10-28 12:51:50','vivek'),(23,'W',225,'2012-10-28 12:51:50','vivek'),(24,'X',230,'2012-10-28 12:51:50','vivek'),(25,'Y',235,'2012-10-28 12:51:50','vivek'),(26,'Z',240,'2012-10-28 12:51:50','vivek'),(27,NULL,NULL,'2012-10-28 12:51:50','vivek'),(28,'A',115,'2012-10-28 12:51:50','vivek'),(29,'B',120,'2012-10-28 12:51:50','vivek'),(30,'C',125,'2012-10-28 12:51:50','vivek'),(31,'D',130,'2012-10-28 12:51:50','vivek'),(32,'E',135,'2012-10-28 12:51:50','vivek'),(33,'F',140,'2012-10-28 12:51:50','vivek'),(34,'G',145,'2012-10-28 12:51:50','vivek'),(35,'H',150,'2012-10-28 12:51:50','vivek'),(36,'I',155,'2012-10-28 12:51:50','vivek'),(37,'J',160,'2012-10-28 12:51:50','vivek'),(38,'K',165,'2012-10-28 12:51:50','vivek'),(39,'L',170,'2012-10-28 12:51:50','vivek'),(40,'M',175,'2012-10-28 12:51:50','vivek'),(41,'N',180,'2012-10-28 12:51:50','vivek'),(42,'O',185,'2012-10-28 12:51:50','vivek'),(43,'P',290,'2012-10-28 12:51:50','vivek'),(44,'Q',295,'2012-10-28 12:51:50','vivek'),(45,'R',200,'2012-10-28 12:51:50','vivek'),(46,'S',205,'2012-10-28 12:51:50','vivek'),(47,'T',210,'2012-10-28 12:51:50','vivek'),(48,'U',215,'2012-10-28 12:51:50','vivek'),(49,'V',220,'2012-10-28 12:51:50','vivek'),(50,'W',225,'2012-10-28 12:51:50','vivek'),(51,'X',230,'2012-10-28 12:51:50','vivek'),(52,'Y',235,'2012-10-28 12:51:50','vivek'),(53,'Z',240,'2012-10-28 12:51:50','vivek'),(1,'A',115,'2012-10-28 12:51:50','vivek'),(2,'B',120,'2012-10-28 12:51:50','vivek'),(3,'C',125,'2012-10-28 12:51:50','vivek'),(4,'D',130,'2012-10-28 12:51:50','vivek'),(5,'E',135,'2012-10-28 12:51:50','vivek'),(6,'F',140,'2012-10-28 12:51:50','vivek'),(7,'G',145,'2012-10-28 12:51:50','vivek'),(8,'H',150,'2012-10-28 12:51:50','vivek'),(9,'I',155,'2012-10-28 12:51:50','vivek'),(10,'J',160,'2012-10-28 12:51:50','vivek'),(11,'K',165,'2012-10-28 12:51:50','vivek'),(12,'L',170,'2012-10-28 12:51:50','vivek'),(13,'M',175,'2012-10-28 12:51:50','vivek'),(14,'N',180,'2012-10-28 12:51:50','vivek'),(15,'O',185,'2012-10-28 12:51:50','vivek'),(16,'P',290,'2012-10-28 12:51:50','vivek'),(17,'Q',295,'2012-10-28 12:51:50','vivek'),(18,'R',200,'2012-10-28 12:51:50','vivek'),(19,'S',205,'2012-10-28 12:51:50','vivek'),(20,'T',210,'2012-10-28 12:51:50','vivek'),(21,'U',215,'2012-10-28 12:51:50','vivek'),(22,'V',220,'2012-10-28 12:51:50','vivek'),(23,'W',225,'2012-10-28 12:51:50','vivek'),(24,'X',230,'2012-10-28 12:51:50','vivek'),(25,'Y',235,'2012-10-28 12:51:50','vivek'),(26,'Z',240,'2012-10-28 12:51:50','vivek'),(27,NULL,NULL,'2012-10-28 12:51:50','vivek'),(28,'A',115,'2012-10-28 12:51:50','vivek'),(29,'B',120,'2012-10-28 12:51:50','vivek'),(30,'C',125,'2012-10-28 12:51:50','vivek'),(31,'D',130,'2012-10-28 12:51:50','vivek'),(32,'E',135,'2012-10-28 12:51:50','vivek'),(33,'F',140,'2012-10-28 12:51:50','vivek'),(34,'G',145,'2012-10-28 12:51:50','vivek'),(35,'H',150,'2012-10-28 12:51:50','vivek'),(36,'I',155,'2012-10-28 12:51:50','vivek'),(37,'J',160,'2012-10-28 12:51:50','vivek'),(38,'K',165,'2012-10-28 12:51:50','vivek'),(39,'L',170,'2012-10-28 12:51:50','vivek'),(40,'M',175,'2012-10-28 12:51:50','vivek'),(41,'N',180,'2012-10-28 12:51:50','vivek'),(42,'O',185,'2012-10-28 12:51:50','vivek'),(43,'P',290,'2012-10-28 12:51:50','vivek'),(44,'Q',295,'2012-10-28 12:51:50','vivek'),(45,'R',200,'2012-10-28 12:51:50','vivek'),(46,'S',205,'2012-10-28 12:51:50','vivek'),(47,'T',210,'2012-10-28 12:51:50','vivek'),(48,'U',215,'2012-10-28 12:51:50','vivek'),(49,'V',220,'2012-10-28 12:51:50','vivek'),(50,'W',225,'2012-10-28 12:51:50','vivek'),(51,'X',230,'2012-10-28 12:51:50','vivek'),(52,'Y',235,'2012-10-28 12:51:50','vivek'),(53,'Z',240,'2012-10-28 12:51:50','vivek');

--
-- Table structure for table `order_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `order_details` (
  `order_no` int(11) NOT NULL AUTO_INCREMENT,
  `sl_no` int(11) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT 'None',
  `product_code` varchar(55) DEFAULT 'None',
  `price_code` varchar(55) DEFAULT 'None',
  `price_method` varchar(55) DEFAULT 'None',
  `price` double DEFAULT 0,
  `p_loss` double DEFAULT 0,
  `prd_size` varchar(55) DEFAULT 'None',
  `gold_wt` varchar(255) DEFAULT '0',
  `rm_id` int(11) DEFAULT 0,
  `particulars` varchar(100) DEFAULT 'None',
  `qty` varchar(25) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `product_mv` double DEFAULT 0,
  PRIMARY KEY (`order_no`),
  KEY `order_id` (`order_id`),
  KEY `price_code` (`price_code`),
  KEY `product_code` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7096 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_details`
--


--
-- Table structure for table `order_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `order_master` (
  `order_autoid` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) NOT NULL,
  `order_serial` int(11) DEFAULT NULL,
  `cust_id` varchar(50) DEFAULT NULL,
  `agent_id` varchar(50) DEFAULT NULL,
  `DoO` int(11) DEFAULT NULL,
  `DoD` int(11) DEFAULT NULL,
  `Status_id` int(11) DEFAULT 0,
  `User_ID` varchar(50) DEFAULT NULL,
  `tr_date` int(11) DEFAULT 0,
  `tr_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `lc_discount_percentage` int(11) DEFAULT 0,
  PRIMARY KEY (`order_autoid`)
) ENGINE=InnoDB AUTO_INCREMENT=3259 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_master`
--


--
-- Table structure for table `password_resets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--


--
-- Table structure for table `personal_access_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=972 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES (112,'App\\Models\\User',5,'my-app-token','429094357a385221bc3640f6f3ed3cf1df54ba5a1d59d6199780a653b769f54e','[\"*\"]','2021-11-12 08:35:55','2021-11-11 08:13:04','2021-11-12 08:35:55'),(838,'App\\Models\\User',2,'my-app-token','cb3949cd160aa65505ce0bbcaf52301a512a069e346010defc71313d59ba365d','[\"*\"]','2022-09-09 07:34:45','2022-09-09 07:33:33','2022-09-09 07:34:45'),(912,'App\\Models\\User',6,'my-app-token','ed0d59507ba6fd85b4df663ba1089dbc92bfc8bd8516c42a5f60ae06c50373bc','[\"*\"]','2022-12-09 08:00:57','2022-10-24 07:38:20','2022-12-09 08:00:57'),(937,'App\\Models\\User',1,'my-app-token','60eb7639bbf910558f19feafb53634fe0ef02e429f63b873a4716b7c75c87ff2','[\"*\"]','2022-11-18 11:42:35','2022-11-15 12:25:34','2022-11-18 11:42:35'),(950,'App\\Models\\User',1,'my-app-token','ee2d8d3953c4e49daf52b6c9c365a3c82a54ffa704d67662395ac7743896679d','[\"*\"]','2022-11-23 13:01:07','2022-11-23 12:26:52','2022-11-23 13:01:07'),(967,'App\\Models\\User',3,'my-app-token','3508404b535802203e81e944d7b82d03708e26228b9da33bfd2a1ce170f00e21','[\"*\"]','2022-12-10 04:21:26','2022-12-06 04:18:19','2022-12-10 04:21:26'),(968,'App\\Models\\User',1,'my-app-token','188b9b1b22d5552635cd3f54935cfa6ad34e7f06937a67b551a539b0f8f31a4c','[\"*\"]','2022-12-08 08:14:52','2022-12-06 07:40:11','2022-12-08 08:14:52'),(969,'App\\Models\\User',1,'my-app-token','fce6bc6fc6d09b7bf7f6e80d2dc64af2751fda0e646fc869b97bee813776282e','[\"*\"]','2022-12-08 11:42:53','2022-12-08 11:17:00','2022-12-08 11:42:53'),(970,'App\\Models\\User',3,'my-app-token','cd8ab6da8b047134f72662e26f061e2f6dce92f89efda43145b93ce49f618611','[\"*\"]','2022-12-11 11:58:03','2022-12-10 09:11:29','2022-12-11 11:58:03'),(971,'App\\Models\\User',6,'my-app-token','b6e8a66134cec0381bfb441e55d48b9968c54d15a7786dcd642939c15505f28f','[\"*\"]','2022-12-12 05:28:06','2022-12-10 12:27:08','2022-12-12 05:28:06');

--
-- Table structure for table `pettystock`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pettystock` (
  `ptr_id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_id` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `rmtr_id` int(11) DEFAULT NULL,
  `rm_value` double DEFAULT NULL,
  `transaction_type` int(11) DEFAULT NULL,
  `inforce` int(11) DEFAULT NULL,
  `ptr_time` datetime DEFAULT NULL,
  `ptr_date` int(11) DEFAULT 0,
  `particulars` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ptr_id`),
  UNIQUE KEY `Unique_test` (`job_id`,`rm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pettystock`
--


--
-- Table structure for table `price_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `price_master` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `price_code` varchar(55) DEFAULT NULL,
  `price_cat` int(11) DEFAULT 0,
  `price` int(11) DEFAULT 0,
  `p_loss` double DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` varchar(55) DEFAULT NULL,
  `price_master_mv` double DEFAULT 0,
  PRIMARY KEY (`price_id`),
  KEY `price_id` (`price_id`),
  KEY `user_id` (`user_id`),
  KEY `price_cat` (`price_cat`),
  CONSTRAINT `price_master_ibfk_1` FOREIGN KEY (`price_cat`) REFERENCES `cust_category` (`ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_master`
--

INSERT INTO `price_master` (`price_id`, `price_code`, `price_cat`, `price`, `p_loss`, `time_stamp`, `user_id`, `price_master_mv`) VALUES (89,'A',1,480,0.114,NULL,NULL,0),(90,'B',1,500,0.124,NULL,NULL,0),(91,'C',1,520,0.134,NULL,NULL,0),(92,'D',1,540,0.14400000000000002,'2010-09-16 00:00:00',NULL,0),(93,'E',1,560,0.154,NULL,NULL,0),(94,'F',1,580,0.164,'2010-09-24 00:00:00',NULL,0),(95,'G',1,600,0.174,NULL,NULL,0),(96,'H',1,620,0.184,NULL,NULL,0),(97,'I',1,640,0.194,NULL,NULL,0),(98,'J',1,660,0.20400000000000001,NULL,NULL,0),(99,'K',1,680,0.21400000000000002,'2011-10-07 00:00:00',NULL,0),(100,'L',1,700,0.22399999999999998,NULL,NULL,0),(101,'M',1,720,0.23399999999999999,NULL,NULL,0),(102,'N',1,740,0.244,NULL,NULL,0),(103,'O',1,760,0.254,NULL,NULL,0),(104,'P',1,780,0.264,NULL,NULL,0),(105,'Q',1,800,0.274,NULL,NULL,0),(106,'R',1,820,0.284,NULL,NULL,0),(107,'S',1,840,0.294,NULL,NULL,0),(108,'T',1,860,0.304,NULL,NULL,0),(109,'U',1,880,0.314,NULL,NULL,0),(110,'V',1,900,0.324,NULL,NULL,0),(111,'W',1,920,0.334,NULL,NULL,0),(112,'X',1,940,0.6639999999999999,NULL,NULL,0),(113,'Y',1,960,0.714,NULL,NULL,0),(114,'Z',1,980,0.764,NULL,NULL,0),(115,'A',13,430,0.114,NULL,NULL,0),(116,'B',13,450,0.124,NULL,NULL,0),(117,'C',13,470,0.134,NULL,NULL,0),(118,'D',13,490,0.14400000000000002,NULL,NULL,0),(119,'E',13,510,0.154,NULL,NULL,0),(120,'F',13,530,0.164,NULL,NULL,0),(121,'G',13,550,0.174,NULL,NULL,0),(122,'H',13,570,0.184,NULL,NULL,0),(123,'I',13,590,0.194,NULL,NULL,0),(124,'J',13,610,0.20400000000000001,NULL,NULL,0),(125,'K',13,630,0.21400000000000002,NULL,NULL,0),(126,'L',13,650,0.22399999999999998,NULL,NULL,0),(127,'M',13,670,0.23399999999999999,NULL,NULL,0),(128,'N',13,690,0.244,NULL,NULL,0),(129,'O',13,710,0.254,NULL,NULL,0),(130,'P',13,730,0.264,NULL,NULL,0),(131,'Q',13,750,0.274,NULL,NULL,0),(132,'R',13,770,0.284,NULL,NULL,0),(133,'S',13,790,0.294,NULL,NULL,0),(134,'T',13,810,0.304,NULL,NULL,0),(135,'U',13,830,0.314,NULL,NULL,0),(136,'V',13,850,0.324,NULL,NULL,0),(137,'W',13,870,0.334,NULL,NULL,0),(138,'X',13,940,0.6639999999999999,NULL,NULL,0),(139,'Y',13,960,0.714,NULL,NULL,0),(140,'Z',13,980,0.764,NULL,NULL,0),(142,'A',14,460,0.114,NULL,NULL,0),(143,'B',14,480,0.124,NULL,NULL,0),(144,'C',14,500,0.134,NULL,NULL,0),(145,'D',14,520,0.14400000000000002,NULL,NULL,0),(146,'E',14,540,0.154,NULL,NULL,0),(147,'F',14,560,0.164,NULL,NULL,0),(148,'G',14,580,0.174,NULL,NULL,0),(149,'H',14,600,0.184,NULL,NULL,0),(150,'I',14,620,0.194,NULL,NULL,0),(151,'J',14,640,0.20400000000000001,NULL,NULL,0),(152,'K',14,660,0.21400000000000002,NULL,NULL,0),(153,'L',14,680,0.22399999999999998,NULL,NULL,0),(154,'M',14,700,0.23399999999999999,NULL,NULL,0),(155,'N',14,720,0.244,NULL,NULL,0),(156,'O',14,740,0.254,NULL,NULL,0),(157,'P',14,760,0.264,NULL,NULL,0),(158,'Q',14,780,0.274,NULL,NULL,0),(159,'R',14,800,0.284,NULL,NULL,0),(160,'S',14,820,0.294,NULL,NULL,0),(161,'T',14,840,0.304,NULL,NULL,0),(162,'U',14,860,0.314,NULL,NULL,0),(163,'V',14,880,0.324,NULL,NULL,0),(164,'W',14,900,0.334,NULL,NULL,0),(165,'X',14,920,0.6639999999999999,NULL,NULL,0),(166,'Y',14,940,0.714,NULL,NULL,0),(167,'Z',14,960,0.764,NULL,NULL,0),(168,'A',15,450,0.114,NULL,NULL,0),(169,'B',15,470,0.124,NULL,NULL,0),(170,'C',15,490,0.134,NULL,NULL,0),(171,'D',15,510,0.14400000000000002,NULL,NULL,0),(172,'E',15,530,0.154,NULL,NULL,0),(173,'F',15,550,0.164,NULL,NULL,0),(174,'G',15,570,0.174,NULL,NULL,0),(175,'H',15,590,0.184,NULL,NULL,0),(176,'I',15,610,0.194,NULL,NULL,0),(177,'J',15,630,0.20400000000000001,NULL,NULL,0),(178,'K',15,650,0.21400000000000002,NULL,NULL,0),(179,'L',15,670,0.22399999999999998,NULL,NULL,0),(180,'M',15,690,0.23399999999999999,NULL,NULL,0),(181,'N',15,710,0.244,NULL,NULL,0),(182,'O',15,730,0.254,NULL,NULL,0),(183,'P',15,750,0.264,NULL,NULL,0),(184,'Q',15,770,0.274,NULL,NULL,0),(185,'R',15,790,0.284,NULL,NULL,0),(186,'S',15,810,0.294,NULL,NULL,0),(187,'T',15,830,0.304,NULL,NULL,0),(188,'U',15,850,0.314,NULL,NULL,0),(189,'V',15,870,0.324,NULL,NULL,0),(190,'W',15,890,0.334,NULL,NULL,0),(191,'X',15,940,0.6639999999999999,NULL,NULL,0),(192,'Y',15,960,0.714,NULL,NULL,0),(193,'Z',15,980,0.764,NULL,NULL,0),(194,'A',12,340,0.114,NULL,NULL,0),(195,'B',12,350,0.124,NULL,NULL,0),(196,'C',12,370,0.134,NULL,NULL,0),(197,'D',12,390,0.14400000000000002,NULL,NULL,0),(198,'E',12,410,0.154,NULL,NULL,0),(199,'F',12,430,0.164,NULL,NULL,0),(200,'G',12,450,0.174,NULL,NULL,0),(201,'H',12,470,0.184,NULL,NULL,0),(202,'I',12,490,0.194,NULL,NULL,0),(203,'J',12,510,0.20400000000000001,NULL,NULL,0),(204,'K',12,530,0.21400000000000002,NULL,NULL,0),(205,'L',12,550,0.22399999999999998,NULL,NULL,0),(206,'M',12,570,0.23399999999999999,NULL,NULL,0),(207,'N',12,590,0.244,NULL,NULL,0),(208,'O',12,610,0.254,NULL,NULL,0),(209,'P',12,630,0.264,NULL,NULL,0),(210,'Q',12,650,0.274,NULL,NULL,0),(211,'R',12,670,0.284,NULL,NULL,0),(212,'S',12,690,0.294,NULL,NULL,0),(213,'T',12,710,0.304,NULL,NULL,0),(214,'U',12,730,0.314,NULL,NULL,0),(215,'V',12,750,0.324,NULL,NULL,0),(216,'W',12,770,0.334,NULL,NULL,0),(217,'X',12,690,0.6639999999999999,NULL,NULL,0),(218,'Y',12,740,0.714,NULL,NULL,0),(219,'Z',12,790,0.764,NULL,NULL,0),(298,'AA',1,960,0.228,NULL,NULL,0),(299,'FI',1,1220,0.358,NULL,'manoka',0),(301,'FI',13,640,0.324,NULL,'manoka',0),(302,'FI',14,640,0.324,NULL,'manoka',0),(303,'FI',15,640,0.324,NULL,'manoka',0),(304,'FJ',1,1240,0.368,NULL,'manoka',0),(306,'FJ',13,660,0.34400000000000003,NULL,'manoka',0),(307,'FJ',14,660,0.34400000000000003,NULL,'manoka',0),(308,'FJ',15,660,0.34400000000000003,NULL,'manoka',0),(309,'FK',1,1260,0.378,NULL,'manoka',0),(311,'FK',13,680,0.36400000000000005,NULL,'manoka',0),(312,'FK',14,680,0.36400000000000005,NULL,'manoka',0),(313,'FK',15,680,0.36400000000000005,NULL,'manoka',0),(314,'FL',1,1280,0.388,NULL,'manoka',0),(316,'FL',13,700,0.384,NULL,'manoka',0),(317,'FL',14,700,0.384,NULL,'manoka',0),(318,'FL',15,700,0.384,NULL,'manoka',0),(319,'FM',1,1300,0.398,NULL,'manoka',0),(321,'FM',13,720,0.404,NULL,'manoka',0),(322,'FM',14,720,0.404,NULL,'manoka',0),(323,'FM',15,720,0.404,NULL,'manoka',0),(324,'FN',1,1320,0.408,NULL,'manoka',0),(326,'FN',13,740,0.42400000000000004,NULL,'manoka',0),(327,'FN',14,740,0.42400000000000004,NULL,'manoka',0),(328,'FN',15,740,0.42400000000000004,NULL,'manoka',0),(329,'FO',1,1340,0.418,NULL,'manoka',0),(331,'FO',13,760,0.444,NULL,'manoka',0),(332,'FO',14,760,0.444,NULL,'manoka',0),(333,'FO',15,760,0.444,NULL,'manoka',0),(334,'A',16,410,0.114,NULL,NULL,0),(335,'B',16,420,0.124,NULL,NULL,0),(336,'C',16,430,0.134,NULL,NULL,0),(337,'D',16,440,0.14400000000000002,NULL,NULL,0),(338,'E',16,450,0.154,NULL,NULL,0),(339,'F',16,460,0.164,NULL,NULL,0),(340,'G',16,470,0.174,NULL,NULL,0),(341,'H',16,480,0.184,NULL,NULL,0),(342,'I',16,490,0.194,NULL,NULL,0),(343,'J',16,500,0.20400000000000001,NULL,NULL,0),(344,'K',16,510,0.21400000000000002,NULL,NULL,0),(345,'L',16,520,0.22399999999999998,NULL,NULL,0),(346,'M',16,530,0.23399999999999999,NULL,NULL,0),(347,'N',16,540,0.244,NULL,NULL,0),(348,'O',16,550,0.254,NULL,NULL,0),(349,'P',16,560,0.264,NULL,NULL,0),(350,'Q',16,570,0.274,NULL,NULL,0),(351,'R',16,580,0.284,NULL,NULL,0),(352,'S',16,590,0.294,NULL,NULL,0),(353,'T',16,600,0.304,NULL,NULL,0),(354,'U',16,610,0.314,NULL,NULL,0),(355,'V',16,620,0.324,NULL,NULL,0),(356,'W',16,630,0.334,NULL,NULL,0),(357,'X',16,640,0.6639999999999999,NULL,NULL,0),(358,'Y',16,650,0.714,NULL,NULL,0),(359,'Z',16,660,0.764,NULL,NULL,0),(393,'A',17,380,0.114,NULL,NULL,0),(394,'B',17,400,0.124,NULL,NULL,0),(395,'C',17,420,0.134,NULL,NULL,0),(396,'D',17,440,0.14400000000000002,NULL,NULL,0),(397,'E',17,460,0.154,NULL,NULL,0),(398,'F',17,480,0.164,NULL,NULL,0),(399,'G',17,500,0.174,NULL,NULL,0),(400,'H',17,520,0.184,NULL,NULL,0),(401,'I',17,540,0.194,NULL,NULL,0),(402,'J',17,560,0.20400000000000001,NULL,NULL,0),(403,'K',17,580,0.214,NULL,NULL,0),(404,'L',17,600,0.224,NULL,NULL,0),(405,'M',17,620,0.234,NULL,NULL,0),(406,'N',17,640,0.244,NULL,NULL,0),(407,'O',17,660,0.254,NULL,NULL,0),(408,'P',17,680,0.264,NULL,NULL,0),(409,'Q',17,700,0.274,NULL,NULL,0),(410,'R',17,720,0.28400000000000003,NULL,NULL,0),(411,'S',17,740,0.29400000000000004,NULL,NULL,0),(412,'T',17,760,0.304,NULL,NULL,0),(413,'U',17,780,0.314,NULL,NULL,0),(414,'V',17,800,0.324,NULL,NULL,0),(415,'W',17,820,0.334,NULL,NULL,0),(416,'X',17,890,0.6639999999999999,NULL,NULL,0),(417,'Y',17,910,0.714,NULL,NULL,0),(418,'Z',17,930,0.764,NULL,NULL,0),(419,'FI',17,590,0.324,NULL,NULL,0),(420,'FJ',17,610,0.34400000000000003,NULL,NULL,0),(421,'FK',17,630,0.364,NULL,NULL,0),(422,'FL',17,650,0.384,NULL,NULL,0),(423,'FM',17,670,0.404,NULL,NULL,0),(424,'FN',17,690,0.424,NULL,NULL,0),(425,'FO',17,710,0.444,NULL,NULL,0),(459,'FI',12,540,0.324,NULL,NULL,0),(460,'FJ',12,560,0.34400000000000003,NULL,NULL,0),(461,'FK',12,580,0.364,NULL,NULL,0),(462,'FL',12,600,0.384,NULL,NULL,0),(463,'FM',12,620,0.404,NULL,NULL,0),(464,'FN',12,640,0.424,NULL,NULL,0),(465,'FO',12,660,0.444,NULL,NULL,0),(466,'A',18,320,0.114,NULL,NULL,0),(467,'B',18,320,0.124,NULL,NULL,0),(468,'C',18,320,0.134,NULL,NULL,0),(469,'D',18,320,0.14400000000000002,NULL,NULL,0),(470,'E',18,320,0.154,NULL,NULL,0),(471,'F',18,320,0.164,NULL,NULL,0),(472,'G',18,320,0.174,NULL,NULL,0),(473,'H',18,320,0.184,NULL,NULL,0),(474,'I',18,320,0.194,NULL,NULL,0),(475,'J',18,320,0.20400000000000001,NULL,NULL,0),(476,'K',18,320,0.214,NULL,NULL,0),(477,'L',18,320,0.224,NULL,NULL,0),(478,'M',18,320,0.234,NULL,NULL,0),(479,'N',18,320,0.244,NULL,NULL,0),(480,'O',18,320,0.254,NULL,NULL,0),(481,'P',18,320,0.264,NULL,NULL,0),(482,'Q',18,320,0.274,NULL,NULL,0),(483,'R',18,320,0.28400000000000003,NULL,NULL,0),(484,'S',18,320,0.29400000000000004,NULL,NULL,0),(485,'T',18,320,0.304,NULL,NULL,0),(486,'U',18,320,0.314,NULL,NULL,0),(487,'V',18,320,0.324,NULL,NULL,0),(488,'W',18,320,0.334,NULL,NULL,0),(489,'X',18,320,0.6639999999999999,NULL,NULL,0),(490,'Y',18,320,0.714,NULL,NULL,0),(491,'Z',18,320,0.764,NULL,NULL,0),(492,'FI',18,320,0.324,NULL,NULL,0),(493,'FJ',18,320,0.34400000000000003,NULL,NULL,0),(494,'FK',18,320,0.364,NULL,NULL,0),(495,'FL',18,320,0.384,NULL,NULL,0),(496,'FM',18,320,0.404,NULL,NULL,0),(497,'FN',18,320,0.424,NULL,NULL,0),(498,'FO',18,320,0.444,NULL,NULL,0);

--
-- Table structure for table `price_masters`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `price_masters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_masters`
--


--
-- Table structure for table `print_bill_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_bill_details` (
  `bill_details_id` int(11) DEFAULT NULL,
  `bill_serial_no` int(11) DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `model_no` varchar(12) DEFAULT NULL,
  `price_code` varchar(4) DEFAULT NULL,
  `gold_wt` double DEFAULT NULL,
  `gross_wt` double DEFAULT 0,
  `price_method` varchar(20) DEFAULT NULL,
  `wastage_percentage` double DEFAULT NULL,
  `wastage` double DEFAULT 0,
  `total_gold` double DEFAULT NULL,
  `gold_quality` double DEFAULT 0,
  `fine_gold` double DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `size` varchar(10) DEFAULT NULL,
  `job_date` int(11) DEFAULT NULL,
  `ploss` double DEFAULT NULL,
  `labour_charge` double DEFAULT NULL,
  KEY `bill_id` (`bill_id`),
  KEY `job_id` (`job_id`),
  KEY `price_code` (`price_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_bill_details`
--


--
-- Table structure for table `print_bill_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_bill_master` (
  `bill_id` int(11) NOT NULL,
  `bill_serial` varchar(255) DEFAULT NULL,
  `bill_no` varchar(255) DEFAULT NULL,
  `bill_date` int(11) DEFAULT 0,
  `cust_id` varchar(55) DEFAULT NULL,
  `order_id` varchar(55) DEFAULT NULL,
  `bill_gold` double DEFAULT NULL,
  `bill_wages` double DEFAULT NULL,
  `Cash_cleared` int(11) DEFAULT NULL,
  `gold_cleared` int(11) DEFAULT NULL,
  `agent_id` varchar(20) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` varchar(55) DEFAULT NULL,
  `total_lc_inward` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`bill_id`),
  KEY `agent_id` (`agent_id`),
  KEY `cust_id` (`cust_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_bill_master`
--


--
-- Table structure for table `print_job_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_job_master` (
  `job_id` int(11) DEFAULT NULL,
  `order_id` varchar(55) DEFAULT NULL,
  `order_serial` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `product_code` varchar(55) DEFAULT NULL,
  `gold_type` int(11) DEFAULT NULL,
  `pieces` int(11) DEFAULT 0,
  `product_size` varchar(55) DEFAULT NULL,
  `job_date` int(11) DEFAULT NULL,
  `delivery_date` int(11) DEFAULT NULL,
  `expected_gold` double DEFAULT 0,
  `p_loss` double DEFAULT 0,
  `time_stamp` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `gold_send` double DEFAULT 0,
  `rm_gold` double DEFAULT 0,
  `dal_send` double DEFAULT 0,
  `pan_send` double DEFAULT 0,
  `bronze_send` double DEFAULT 0,
  `gold_returned` double DEFAULT 0,
  `dal_returned` double DEFAULT 0,
  `pan_returned` double DEFAULT 0,
  `bronze_returned` double DEFAULT 0,
  `emp_name` varchar(100) DEFAULT NULL,
  `awt` double DEFAULT 0,
  `price_code` varchar(10) DEFAULT NULL,
  KEY `emp_id` (`emp_id`),
  KEY `price_code` (`price_code`),
  KEY `product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_job_master`
--


--
-- Table structure for table `print_order_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_order_details` (
  `order_no` int(11) NOT NULL AUTO_INCREMENT,
  `sl_no` int(11) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `price_code` varchar(255) DEFAULT NULL,
  `price_method` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `p_loss` double DEFAULT NULL,
  `prd_size` varchar(255) DEFAULT NULL,
  `gold_wt` double DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `particulars` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_no`),
  KEY `order_id` (`order_id`),
  KEY `price_code` (`price_code`),
  KEY `product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_order_details`
--


--
-- Table structure for table `print_order_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_order_master` (
  `order_id` varchar(55) NOT NULL,
  `agent_id` varchar(55) DEFAULT NULL,
  `cust_id` varchar(55) DEFAULT NULL,
  `user_id` varchar(55) DEFAULT NULL,
  `DoO` int(11) DEFAULT NULL,
  `dod` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `agent_id` (`agent_id`),
  KEY `cust_id` (`cust_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_order_master`
--


--
-- Table structure for table `print_receipt_details`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_receipt_details` (
  `receipt_id` int(11) DEFAULT NULL,
  `recipt_serial` int(11) DEFAULT NULL,
  `received_amount` double DEFAULT NULL,
  `bill_id` int(11) DEFAULT NULL,
  `receipt_type` varchar(55) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `adv_amount` double DEFAULT NULL,
  KEY `bill_id` (`bill_id`),
  KEY `receipt_id` (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_receipt_details`
--


--
-- Table structure for table `print_receipt_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_receipt_master` (
  `Receipt_ID` int(11) NOT NULL,
  `Receipt_mode` varchar(255) DEFAULT NULL,
  `Cust_ID` varchar(255) DEFAULT NULL,
  `Receipt_date` datetime DEFAULT NULL,
  `Cheque_no` varchar(255) DEFAULT NULL,
  `Bank` varchar(255) DEFAULT NULL,
  `Branch` varchar(255) DEFAULT NULL,
  `thousand` int(11) DEFAULT NULL,
  `five_hundred` int(11) DEFAULT NULL,
  `one_hundred` int(11) DEFAULT NULL,
  `fifty` int(11) DEFAULT NULL,
  `twenty` int(11) DEFAULT NULL,
  `ten` int(11) DEFAULT NULL,
  `five` int(11) DEFAULT NULL,
  `two` int(11) DEFAULT NULL,
  `one` int(11) DEFAULT NULL,
  PRIMARY KEY (`Receipt_ID`),
  KEY `Cust_ID` (`Cust_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_receipt_master`
--


--
-- Table structure for table `print_receiptnotes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `print_receiptnotes` (
  `ReceiptID` int(11) NOT NULL AUTO_INCREMENT,
  `ReceiptDate` datetime DEFAULT NULL,
  `Thousand` int(11) DEFAULT NULL,
  `FiveHundred` int(11) DEFAULT NULL,
  `Hundred` int(11) DEFAULT NULL,
  `Fifty` int(11) DEFAULT NULL,
  `Twenty` int(11) DEFAULT NULL,
  `Ten` int(11) DEFAULT NULL,
  `Five` int(11) DEFAULT NULL,
  `Two` int(11) DEFAULT NULL,
  `One` int(11) DEFAULT NULL,
  PRIMARY KEY (`ReceiptID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_receiptnotes`
--


--
-- Table structure for table `product_cat`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_cat` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(55) DEFAULT NULL,
  `category_header` varchar(30) DEFAULT NULL,
  `calculation_method` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_cat`
--

INSERT INTO `product_cat` (`ID`, `category`, `category_header`, `calculation_method`) VALUES (3,'Baby','B','Regular'),(4,'churi','C','Regular'),(5,'solid churi','S','Wastage'),(10,'Mina Thokai patla','M','Regular'),(12,'Thokai Churi','T','Regular'),(13,'Bouty','BO','Regular'),(14,'Thokai Patla','CT','Regular'),(15,'Kankan','CK','Regular'),(16,'Xsample','X','Regular'),(17,'Mima Churi','Mm','Regular'),(18,'Holo Churi','MH','Regular'),(19,'Holo','H','Regular');

--
-- Table structure for table `product_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_master` (
  `product_code` varchar(255) NOT NULL,
  `product_description` varchar(255) DEFAULT NULL,
  `product_category` int(11) DEFAULT NULL,
  `price_code` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `product_markuped` int(11) DEFAULT 0,
  `product_markup_value` double DEFAULT 0,
  PRIMARY KEY (`product_code`),
  KEY `price_code` (`price_code`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`product_code`, `product_description`, `product_category`, `price_code`, `time_stamp`, `user_id`, `details`, `product_markuped`, `product_markup_value`) VALUES ('B7001','BABY',3,'G',NULL,NULL,NULL,0,0),('B7002','Baby Bangle',3,'G',NULL,NULL,NULL,0,0),('B7003','BABY BANGLE',3,'H',NULL,NULL,NULL,0,0),('B7004','baby bangle',3,'H',NULL,NULL,NULL,0,0),('B7008','baby',3,'G',NULL,NULL,NULL,0,0),('B7009','Baby Bangle',3,'v','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('B7013','BABY BANGLE',3,'G',NULL,'sanjoy',NULL,1,0.05),('B7014','Baby Bangle',3,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('B7018','Baby Bangle',3,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7021','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7022','BABY BANGLE',3,'H',NULL,'sanjoy',NULL,1,0.05),('B7023','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7024','BABY',3,'F',NULL,NULL,NULL,0,0),('B7025','BABY',3,'G',NULL,NULL,NULL,0,0),('B7026','New Model',3,'G',NULL,NULL,NULL,0,0),('B7027','Baby Bangle',3,'E','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7032','BANGALE',3,'G',NULL,NULL,NULL,0,0),('B7035','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7042','baby',3,'F',NULL,NULL,NULL,0,0),('B7043','baby',3,'G',NULL,NULL,NULL,0,0),('B7044','BABY BANGLE',3,'F',NULL,NULL,NULL,0,0),('B7048','BANGLE',3,'G',NULL,NULL,NULL,0,0),('B7050','bangale',3,'G',NULL,NULL,NULL,0,0),('B7052','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7054','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7059','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7060','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7061','Baby Bangle',3,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7062','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7066','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7068','baby',3,'G',NULL,NULL,NULL,0,0),('B7069','Baby Bangle',3,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7079','Baby Bangle',3,'D','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7088','BABY BANGLE',3,'D',NULL,NULL,NULL,0,0),('B7096','bangle',3,'G',NULL,NULL,NULL,0,0),('B7097','baby',3,'G',NULL,NULL,NULL,0,0),('B7098','BANGALE',3,'G',NULL,NULL,NULL,0,0),('B7099','baby bangle',3,'G',NULL,NULL,NULL,0,0),('B7100','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7112','Baby Bangle',3,'C','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7115','Baby Bangle',3,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('B7116','CHURI',3,'B',NULL,'sanjoy',NULL,1,0.05),('B7117','Baby Bangle',3,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('B7222','LOW',3,'F','2014-04-02 00:00:00','sanjoy',NULL,1,0.05),('B7333','Baby Bangle',3,'G','2014-04-02 00:00:00','sanjoy',NULL,1,0.05),('C0001','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0002','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0003','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0004','Thokai Bangal Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0005','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0006','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0007','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0008','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0009','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0010','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0011','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0012','Thokai Bangla Churi Soru  ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0013','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0014','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0015','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0016','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0017','Thokai Bangla Churi Soru ',4,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0018','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0019','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0020','Thokai Bangla Churi Soru ',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0022','Thokai Bangla Churi Soru ',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0023','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0024','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0025','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0026','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0027','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0028','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0029','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0030','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0031','Thokai Bangla Churi Soru ',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0032','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0033','Thokai Bangla Churi Soru ',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0034','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0035','Thokai Bangla Churi Soru ',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0036','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0037','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0038','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0039','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0040','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0041','Thokai bangla churi majhari',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0042','Thokai bangal churi majhari',4,'G','2010-06-03 18:52:44','sanjoy',NULL,1,0.05),('C0043','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:00','sanjoy',NULL,1,0.05),('C0044','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:12','sanjoy',NULL,1,0.05),('C0045','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:23','sanjoy',NULL,1,0.05),('C0046','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:35','sanjoy',NULL,1,0.05),('C0047','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:49','sanjoy',NULL,1,0.05),('C0048','Thokai bangal churi majhari',4,'G','2010-06-03 18:53:59','sanjoy',NULL,1,0.05),('C0049','Thokai bangal churi majhari',4,'G','2010-06-03 18:54:12','sanjoy',NULL,1,0.05),('C0050','Thokai bangal churi majhari',4,'G','2010-06-03 18:55:08','sanjoy',NULL,1,0.05),('C0051','Thokai bangal churi majhari',4,'G','2010-06-03 18:55:24','sanjoy',NULL,1,0.05),('C0052','Thokai bangal churi majhari',4,'G','2010-06-03 18:55:39','sanjoy',NULL,1,0.05),('C0053','Thokai bangal churi majhari',4,'G','2010-06-03 18:55:52','sanjoy',NULL,1,0.05),('C0054','Thokai bangal churi majhari',4,'G','2010-06-03 18:56:04','sanjoy',NULL,1,0.05),('C0055','Thokai bangal churi majhari',4,'G','2010-06-03 18:56:22','sanjoy',NULL,1,0.05),('C0056','Thokai bangal churi majhari',4,'G','2010-06-03 18:56:43','sanjoy',NULL,1,0.05),('C0057','Thokai bangal churi majhari',4,'G','2010-06-03 18:56:56','sanjoy',NULL,1,0.05),('C0058','Thokai bangal churi majhari',4,'G','2010-06-03 19:02:27','sanjoy',NULL,1,0.05),('C0059','Thokai bangal churi majhari',4,'G','2010-06-03 18:57:17','sanjoy',NULL,1,0.05),('C0060','Thokai bangal churi majhari',4,'H','2010-06-03 18:57:29','sanjoy',NULL,1,0.05),('C0061','Thokai bangal churi majhari',4,'G','2010-06-04 16:27:09','sanjoy',NULL,1,0.05),('C0062','Thokai bangal churi majhari',4,'G','2010-06-03 18:57:56','sanjoy',NULL,1,0.05),('C0063','Thokai bangal churi majhari',4,'G','2010-06-03 18:58:07','sanjoy',NULL,1,0.05),('C0064','Thokai bangal churi majhari',4,'G','2011-01-29 11:46:46','saheb',NULL,1,0.05),('C0065','Thokai bangal churi majhari',4,'G','2010-06-03 18:58:31','sanjoy',NULL,1,0.05),('C0066','Thokai bangal churi majhari',4,'G','2010-06-03 18:58:43','sanjoy',NULL,1,0.05),('C0067','Thokai bangal churi majhari',4,'G','2010-06-03 18:58:56','sanjoy',NULL,1,0.05),('C0068','Thokai bangal churi majhari',4,'G','2010-06-03 18:59:07','sanjoy',NULL,1,0.05),('C0069','Thokai bangal churi majhari',4,'G','2010-06-03 18:59:21','sanjoy',NULL,1,0.05),('C0070','Thokai bangal churi majhari',4,'H','2010-06-03 18:59:32','sanjoy',NULL,1,0.05),('C0072','Thokai bangal mena churi majari',4,'G','2010-06-03 19:04:48','sanjoy',NULL,1,0.05),('C0073','Thokai bangal mena churi majari',4,'G','2010-06-03 19:05:01','sanjoy',NULL,1,0.05),('C0074','Thokai bangal mena churi majari',4,'H','2010-06-03 19:05:24','sanjoy',NULL,1,0.05),('C0075','Thokai bangal mena churi majari',4,'I','2010-06-03 19:05:34','sanjoy',NULL,1,0.05),('C0076','Thokai bangal mena churi majari',4,'H','2010-06-03 19:05:53','sanjoy',NULL,1,0.05),('C0077','Thokai bangal mena churi majari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0078','Thokai bangla churi majari',4,'H','2010-06-03 19:06:15','sanjoy',NULL,1,0.05),('C0079','THOKAI DD CHURI SORU',4,'F','2010-06-03 19:06:28','sanjoy',NULL,1,0.05),('C0080','Thokai bangal mena churi majari',4,'F','2010-06-03 19:06:41','sanjoy',NULL,1,0.05),('C0081','Thokai bangal churi majari',4,'G','2010-06-03 19:06:56','sanjoy',NULL,1,0.05),('C0082','Thokai bangal mena churi majari',4,'H','2010-06-03 19:07:07','sanjoy',NULL,1,0.05),('C0083','Thokai bangal mena churi majari',4,'H','2010-06-04 16:26:28','sanjoy',NULL,1,0.05),('C0084','Thokai bangal mena churi majari',4,'H','2010-06-03 19:08:49','sanjoy',NULL,1,0.05),('C0085','Thokai bangal mena churi majari',4,'H','2010-06-03 19:09:05','sanjoy',NULL,1,0.05),('C0086','Thokai bangal mena churi majari',4,'G','2011-01-29 11:47:56','saheb',NULL,1,0.05),('C0087','Thokai bangal mena churi majari',4,'G','2011-01-29 11:48:04','saheb',NULL,1,0.05),('C0088','Thokai Churi',12,'F','2011-01-07 10:45:43','sandip',NULL,1,0.05),('C0089','Thokai bangal mena churi majari',4,'F','2011-01-29 11:48:20','saheb',NULL,1,0.05),('C0090','Thokai bangal mena churi majari',4,'G','2011-01-29 11:50:21','saheb',NULL,1,0.05),('C0091','Thokai bangal mena churi majari',4,'G','2011-01-29 11:50:26','saheb',NULL,1,0.05),('C0092','Thokai bangal mena churi majari',4,'G','2011-01-29 11:50:31','saheb',NULL,1,0.05),('C0093','Thokai churi',4,'G','2011-01-16 12:25:11','sandip',NULL,1,0.05),('C0094','Thokai bangal mena churi majari',4,'G','2011-01-29 11:50:36','saheb',NULL,1,0.05),('C0095','Thokai Churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0096','Thokai churi',4,'G','2011-01-26 11:58:46','sandip',NULL,1,0.05),('C0097','Thokai churi',4,'K','2011-01-29 11:51:36','saheb',NULL,1,0.05),('C0098','Thokai churi',4,'G','2011-01-29 11:51:46','saheb',NULL,1,0.05),('C0099','Thokai churi',4,'G','2011-01-26 11:59:11','sandip',NULL,1,0.05),('C0100','Thokai churi',4,'H','2011-01-29 11:52:14','saheb',NULL,1,0.05),('C0101','Machin chala flat churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0102','Machin chala flat churi ',4,'F','2010-06-04 17:39:54','b',NULL,1,0.05),('C0103','Machin chala flat churi ',4,'F','2011-01-12 19:37:59','sandip',NULL,1,0.05),('C0104','Machin chala flat churi ',4,'F','2011-01-30 12:46:18','sanjoy',NULL,1,0.05),('C0105','Machin chala flat churi ',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0106','Machin chala flat churi ',4,'G','2011-01-29 11:53:31','saheb',NULL,1,0.05),('C0107','Machin chala flat churi ',4,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0108','Machin chala flat churi ',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0109','Machine chela flat churi ',4,'F','2010-06-04 17:41:41','b',NULL,1,0.05),('C0110','Machin chala flat churi ',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0111','Machin chala flat mena churi saru',4,'F','2010-06-04 17:44:10','b',NULL,1,0.05),('C0112','Machin chala flat mena churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0113','Machin chala flat mena churi saru',4,'F','2010-06-04 17:47:02','b',NULL,1,0.05),('C0114','Machin chala flat mena churi saru',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0115','Machin chala flat mena churi saru',4,'F','2010-06-04 17:47:27','b',NULL,1,0.05),('C0116','Machin chala flat  churi majhari',4,'F','2010-06-04 17:48:34','b',NULL,1,0.05),('C0117','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0118','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0119','Machin chala flat  churi majhari',4,'F','2010-06-04 17:49:49','b',NULL,1,0.05),('C0120','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0121','Machin chala flat  churi majhari',4,'F','2010-06-04 18:45:01','b',NULL,1,0.05),('C0122','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0123','Machin chala flat  churi majhari',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0124','Machin chala flat  churi majhari',4,'F','2010-06-04 18:46:07','b',NULL,1,0.05),('C0125','Machin chala flat  churi majhari',4,'F','2010-06-04 18:46:20','b',NULL,1,0.05),('C0126','Machin chala flat  churi majhari',4,'F','2010-06-04 18:46:30','b',NULL,1,0.05),('C0127','Machin chala flat  churi majhari',4,'F','2010-06-04 18:46:41','b',NULL,1,0.05),('C0128','Machin chala flat  churi majhari',4,'F','2010-06-04 18:46:53','b',NULL,1,0.05),('C0129','Machin chala flat  churi majhari',4,'F','2010-06-04 18:47:06','b',NULL,1,0.05),('C0130','Machin chala flat  churi majhari',4,'I','2011-01-12 19:26:42','sandip',NULL,1,0.05),('C0131','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0132','Machin chala flat  churi majhari',4,'F','2011-01-29 11:54:38','saheb',NULL,1,0.05),('C0133','Machin chala flat  churi majhari',4,'F','2010-06-04 18:48:09','b',NULL,1,0.05),('C0134','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0135','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0136','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0137','Machin chala flat  churi majhari',4,'F','2010-06-04 18:48:46','b',NULL,1,0.05),('C0138','Machin chala flat  churi majhari',4,'F','2010-06-04 18:48:56','b',NULL,1,0.05),('C0139','Machin chala flat  churi majhari',4,'F','2010-06-04 18:49:06','b',NULL,1,0.05),('C0140','Machin chala flat  churi majhari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0142','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:05:23','b',NULL,1,0.05),('C0143','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:05:48','b',NULL,1,0.05),('C0144','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:05:59','b',NULL,1,0.05),('C0145','Machin chala flat mena churi majhari',4,'J','2010-06-04 18:06:11','b',NULL,1,0.05),('C0146','Machin chala flat mena churi majhari',4,'J','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0147','Machin chala flat mena churi majhari',4,'G','2011-01-29 11:55:42','saheb',NULL,1,0.05),('C0148','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:06:47','b',NULL,1,0.05),('C0149','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:07:02','b',NULL,1,0.05),('C0150','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:07:12','b',NULL,1,0.05),('C0151','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:07:22','b',NULL,1,0.05),('C0152','Machin chala flat mena churi majhari',4,'I','2010-06-04 18:07:35','b',NULL,1,0.05),('C0153','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:07:45','b',NULL,1,0.05),('C0154','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:07:56','b',NULL,1,0.05),('C0155','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:08:07','b',NULL,1,0.05),('C0156','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:08:19','b',NULL,1,0.05),('C0157','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:08:30','b',NULL,1,0.05),('C0158','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:08:40','b',NULL,1,0.05),('C0159','Machin chala flat mena churi majhari',4,'I','2010-06-04 18:08:57','b',NULL,1,0.05),('C0160','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:09:20','b',NULL,1,0.05),('C0161','Machin chala flat mena churi majhari',4,'I','2010-06-04 18:10:14','b',NULL,1,0.05),('C0162','Machin chala flat mena churi majhari',4,'H','2010-06-04 18:14:16','b',NULL,1,0.05),('C0163','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:10:34','b',NULL,1,0.05),('C0164','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:10:51','b',NULL,1,0.05),('C0165','Machin chala flat mena churi majhari',4,'G','2010-06-04 18:09:39','b',NULL,1,0.05),('C0166','Machin chala flat churi chowrah',4,'K','2010-06-05 11:47:25','sanjoy',NULL,1,0.05),('C0167','Machin chala flat churi chowrah',4,'K','2010-06-04 18:13:03','b',NULL,1,0.05),('C0168','Machin chala flat churi chowrah',4,'G','2010-06-04 18:21:41','b',NULL,1,0.05),('C0169','Machin chala flat churi chowrah',4,'K','2010-06-04 18:21:54','b',NULL,1,0.05),('C0170','Machin chala flat churi chowrah',4,'I','2010-06-04 18:22:07','b',NULL,1,0.05),('C0171','Machin chala flat churi chowrah',4,'G','2010-06-04 18:22:17','b',NULL,1,0.05),('C0172','Machin chala flat churi chowrah',4,'G','2010-06-04 18:22:28','b',NULL,1,0.05),('C0173','Machin chala flat churi chowrah',4,'G','2010-06-04 18:22:38','b',NULL,1,0.05),('C0174','Machin chala flat churi chowrah',4,'G','2010-06-04 18:22:50','b',NULL,1,0.05),('C0175','Machin chala flat churi chowrah',4,'G','2010-06-04 18:23:06','b',NULL,1,0.05),('C0176','Machin chala flat churi chowrah',4,'G','2010-06-04 18:23:16','b',NULL,1,0.05),('C0177','Machin chala flat churi chowrah',4,'G','2010-06-04 18:23:28','b',NULL,1,0.05),('C0178','Machin chala flat churi chowrah',4,'G','2010-06-04 18:23:38','b',NULL,1,0.05),('C0179','Machin chala flat churi chowrah',4,'G','2010-06-04 18:23:48','b',NULL,1,0.05),('C0180','Machin chala flat churi chowrah',4,'G','2010-06-04 18:24:02','b',NULL,1,0.05),('C0181','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:25:24','b',NULL,1,0.05),('C0182','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:27:44','b',NULL,1,0.05),('C0183','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:28:31','b',NULL,1,0.05),('C0184','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:28:43','b',NULL,1,0.05),('C0185','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:28:54','b',NULL,1,0.05),('C0186','Machin chala flat mena churi chowrah',4,'H','2011-01-29 11:58:47','saheb',NULL,1,0.05),('C0187','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:29:16','b',NULL,1,0.05),('C0188','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:29:32','b',NULL,1,0.05),('C0189','Machin chala flat mena churi chowrah',4,'H','2010-06-04 18:29:44','b',NULL,1,0.05),('C0190','Machin chala flat mena churi chowrah',4,'L','2010-06-04 18:29:54','b',NULL,1,0.05),('C0191','Machin chala flat mena churi chowrah',4,'I','2011-01-29 11:59:23','saheb',NULL,1,0.05),('C0192','Machin chala flat mena churi chowrah',4,'G','2011-01-29 11:59:33','saheb',NULL,1,0.05),('C0193','Machin chala flat mena churi chowrah',4,'H','2011-01-29 11:59:41','saheb',NULL,1,0.05),('C0194','Machin chala flat mena churi chowrah',4,'H','2011-01-29 11:59:58','saheb',NULL,1,0.05),('C0195','Machin chala flat mena churi chowrah',4,'M','2011-01-29 12:00:07','saheb',NULL,1,0.05),('C0196','Machin chala flat mena churi chowrah',4,'I','2011-01-22 20:13:59','sanjoy',NULL,1,0.05),('C0197','Machin chala flat mena churi chowrah',4,'H','2011-01-29 12:00:32','saheb',NULL,1,0.05),('C0200','Machin chala flat mena churi chowrah',4,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0201','Thikai dd churi saru',4,'G','2011-01-29 12:02:09','saheb',NULL,1,0.05),('C0202','Thikai dd churi saru',4,'G','2011-01-29 12:02:25','saheb',NULL,1,0.05),('C0203','Thikai dd churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0204','Thikai dd churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0205','Thikai dd churi saru',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0206','Thikai dd churi saru',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0207','Thikai dd churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0208','Thikai dd churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0209','Thikai dd churi saru',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0210','Thikai dd churi saru',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0211','Thikai dd churi saru',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0212','Thikai dd churi saru',4,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C0213','Thikai dd churi saru',4,'H','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C0214','Thikai dd churi saru',4,'G','2010-06-04 18:34:14','b',NULL,1,0.05),('C0215','Thikai dd churi',4,'H','2010-06-04 18:34:27','b',NULL,1,0.05),('C0216','Thokai dd churi',4,'G','2010-06-04 18:34:37','b',NULL,1,0.05),('C0217','Thikai dd churi saru',4,'G','2010-06-04 18:34:46','b',NULL,1,0.05),('C0218','Thikai dd churi',4,'H','2010-06-04 18:34:59','b',NULL,1,0.05),('C0219','Thokai dd churi',4,'H','2010-06-04 18:35:14','b',NULL,1,0.05),('C0220','thokai dd churi  soru',4,'H','2010-06-05 11:56:19','sanjoy',NULL,1,0.05),('C0221','thokai dd mena churi soru ',4,'G','2010-06-06 13:03:41','sanjoy',NULL,1,0.05),('C0222','PLAZA',4,'H','2010-06-05 12:09:26','sanjoy',NULL,1,0.05),('C0223','thokai dd mena churi  soru',4,'F','2010-06-05 12:09:12','sanjoy',NULL,1,0.05),('C0224','thokai dd mena churi  soru',4,'F','2010-06-05 12:09:00','sanjoy',NULL,1,0.05),('C0225','thokai dd mena churi  soru',4,'F','2010-06-05 12:08:35','sanjoy',NULL,1,0.05),('C0226','thokai dd mena churi  soru',4,'F','2010-06-05 12:08:23','sanjoy',NULL,1,0.05),('C0227','thokai dd mena churi  soru',4,'F','2010-06-05 12:08:09','sanjoy',NULL,1,0.05),('C0228','thokai dd mena churi soru',4,'F','2010-06-05 12:02:59','sanjoy',NULL,1,0.05),('C0229','thokai dd mena churi  soru',4,'F','2010-06-05 12:06:07','sanjoy',NULL,1,0.05),('C0230','thokai dd mena churi  soru',4,'F','2010-06-05 12:13:56','sanjoy',NULL,1,0.05),('C0231','thokai dd mena churi  soru',4,'F','2010-06-05 12:14:32','sanjoy',NULL,1,0.05),('C0232','thokai dd mena churi  soru',4,'F','2010-06-05 12:14:43','sanjoy',NULL,1,0.05),('C0233','thokai dd mena churi  soru',4,'F','2010-06-05 12:14:55','sanjoy',NULL,1,0.05),('C0234','thokai dd mena churi  soru',4,'F','2010-06-05 12:15:06','sanjoy',NULL,1,0.05),('C0235','thokai dd mena churi  soru',4,'H','2010-06-05 12:15:14','sanjoy',NULL,1,0.05),('C0236','thokai dd churi  maghari',4,'H','2010-06-05 12:16:31','sanjoy',NULL,1,0.05),('C0237','thokai dd churi  maghari',4,'H','2010-06-05 12:16:55','sanjoy',NULL,1,0.05),('C0238','thokai dd churi  maghari',4,'F','2010-06-05 12:17:04','sanjoy',NULL,1,0.05),('C0239','thokai dd churi  maghari',4,'F','2010-06-05 12:17:16','sanjoy',NULL,1,0.05),('C0240','thokai dd churi  maghari',4,'F','2010-06-05 12:17:26','sanjoy',NULL,1,0.05),('C0241','Thokai dd churi  maghari',4,'G','2010-06-05 12:17:39','sanjoy',NULL,1,0.05),('C0242','thokai dd churi  maghari',4,'H','2010-06-05 12:17:48','sanjoy',NULL,1,0.05),('C0243','thokai dd churi  maghari',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0244','thokai dd churi  maghari',4,'F','2010-06-05 12:18:07','sanjoy',NULL,1,0.05),('C0245','thokai dd churi  maghari',4,'H','2010-06-05 12:18:19','sanjoy',NULL,1,0.05),('C0246','thokai dd churi  maghari',4,'F','2010-06-05 12:18:30','sanjoy',NULL,1,0.05),('C0247','thokai dd churi  maghari',4,'F','2010-06-05 12:18:40','sanjoy',NULL,1,0.05),('C0248','thokai dd churi  maghari',4,'G','2010-06-05 12:21:14','sanjoy',NULL,1,0.05),('C0249','thokai dd churi  maghari',4,'H','2011-02-08 09:40:28','sandip',NULL,1,0.05),('C0250','thokai dd churi  maghari',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0251','thokai dd churi  maghari',4,'H','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0252','thokai dd churi  maghari',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0253','thokai dd churi  maghari',4,'F','2010-06-05 12:22:41','sanjoy',NULL,1,0.05),('C0254','thokai dd churi  maghari',4,'F','2010-06-05 12:22:50','sanjoy',NULL,1,0.05),('C0255','thokai dd churi  maghari',4,'H','2010-06-05 12:22:59','sanjoy',NULL,1,0.05),('C0256','Thokai DD mina Churi Majhari',4,'H','2010-06-05 12:23:08','sanjoy',NULL,1,0.05),('C0257','Thokai DD Churi  Majhari',4,'H','2010-06-05 12:23:18','sanjoy',NULL,1,0.05),('C0258','Thokai DD Churi  Majhari',4,'H','2010-06-05 12:23:26','sanjoy',NULL,1,0.05),('C0259','Thokai DD Mina Churi  Majhari',4,'G','2010-06-05 12:23:37','sanjoy',NULL,1,0.05),('C0260','Thokai DD Churi  Majhari',4,'I','2010-06-05 12:23:47','sanjoy',NULL,1,0.05),('C0262','Thokai dd mena churi majhari',4,'G','2010-06-04 18:56:00','b',NULL,1,0.05),('C0267','Thokai dd mena churi majhari',4,'G','2010-06-04 19:00:20','b',NULL,1,0.05),('C0268','Thokai dd mena churi majhari',4,'G','2010-06-04 19:00:41','b',NULL,1,0.05),('C0269','Thokai dd mena churi majhari',4,'H','2010-06-04 19:01:03','b',NULL,1,0.05),('C0270','Thokai dd mena churi majhari',4,'I','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0271','thokai dd churi chowrah',4,'I','2011-01-31 17:45:51','saheb',NULL,1,0.05),('C0272','thokai dd churi chowrah',4,'G','2010-06-04 19:03:13','b',NULL,1,0.05),('C0273','thokai dd churi chowrah',4,'G','2010-06-04 19:03:34','b',NULL,1,0.05),('C0274','thokai dd churi chowrah',4,'G','2010-06-04 19:04:25','b',NULL,1,0.05),('C0275','thokai dd churi chowrah',4,'G','2010-06-04 19:04:57','b',NULL,1,0.05),('C0276','thokai dd churi chowrah',4,'G','2010-06-04 19:05:38','b',NULL,1,0.05),('C0277','thokai dd churi chowrah',4,'H','2010-06-04 19:05:56','b',NULL,1,0.05),('C0278','thokai dd churi chowrah',4,'H','2010-06-04 19:06:18','b',NULL,1,0.05),('C0279','thokai dd churi chowrah',4,'G','2010-06-04 19:06:35','b',NULL,1,0.05),('C0280','thokai dd churi chowrah',4,'G','2010-06-04 19:06:48','b',NULL,1,0.05),('C0287','THOKAI DD CHURI',4,'H',NULL,NULL,NULL,0,0),('C0288','THOKAI DD CHURI',4,'I',NULL,NULL,NULL,0,0),('C0289','THOKAI DD CHURI',4,'H',NULL,NULL,NULL,0,0),('C0290','THOKAI DD CHURI MAJHARI',4,'H',NULL,NULL,NULL,0,0),('C0291','thokai dd churi chowrah',4,'F','2011-01-29 12:19:44','saheb',NULL,1,0.05),('C0292','THOKAI DD CHURI',4,'H',NULL,NULL,NULL,0,0),('C0293','Thokai DD Churi',4,'H',NULL,NULL,NULL,0,0),('C0296','THOKAI PLAZA',4,'H',NULL,NULL,NULL,0,0),('C0297','DD PLAZA',4,'H',NULL,NULL,NULL,0,0),('C0298','dd plaza',4,'H',NULL,NULL,NULL,0,0),('C0299','D.D CHURI',4,'I',NULL,NULL,NULL,0,0),('C0301','Thokai joy puri churi soru ',4,'G','2010-06-04 19:11:55','b',NULL,1,0.05),('C0302','Thokai joy puri churi soru ',4,'G','2010-06-04 19:12:56','b',NULL,1,0.05),('C0303','Thokai joy puri churi soru ',4,'G','2010-06-04 19:13:06','b',NULL,1,0.05),('C0304','Thokai joy puri churi soru ',4,'G','2010-06-04 19:13:19','b',NULL,1,0.05),('C0305','Thokai joy puri churi soru ',4,'G','2010-06-04 19:13:32','b',NULL,1,0.05),('C0306','Thokai joy puri churi soru ',4,'G','2010-06-04 19:13:43','b',NULL,1,0.05),('C0307','Thokai joy puri churi soru ',4,'G','2010-06-04 19:13:53','b',NULL,1,0.05),('C0308','Thokai joy puri churi soru ',4,'G','2010-06-04 19:14:05','b',NULL,1,0.05),('C0309','Thokai joy puri churi soru ',4,'G','2010-06-04 19:14:13','b',NULL,1,0.05),('C0310','Thokai joy puri churi soru ',4,'G','2010-06-04 19:14:27','b',NULL,1,0.05),('C0311','Thokai joy puri churi soru ',4,'G','2010-06-04 19:16:23','b',NULL,1,0.05),('C0312','Thokai joy puri churi soru ',4,'G','2010-06-04 19:14:46','b',NULL,1,0.05),('C0313','Thokai joy puri churi soru ',4,'G','2010-06-04 19:15:03','b',NULL,1,0.05),('C0314','Thokai joy puri churi soru ',4,'G','2010-06-04 19:15:44','b',NULL,1,0.05),('C0315','Thokai joy puri churi soru ',4,'G','2010-06-04 19:16:43','b',NULL,1,0.05),('C0316','Thokai joy puri churi soru ',4,'G','2010-06-04 19:16:55','b',NULL,1,0.05),('C0317','Thokai joy puri churi soru ',4,'G','2010-06-04 19:17:11','b',NULL,1,0.05),('C0318','Thokai joy puri churi soru ',4,'G','2010-06-04 19:17:20','b',NULL,1,0.05),('C0319','Thokai joypuri Plaza churi',4,'H','2010-06-04 19:17:29','b',NULL,1,0.05),('C0320','Thokai joy puri churi soru ',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0321','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:18:42','b',NULL,1,0.05),('C0322','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:19:02','b',NULL,1,0.05),('C0323','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:19:15','b',NULL,1,0.05),('C0324','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:19:23','b',NULL,1,0.05),('C0325','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:19:32','b',NULL,1,0.05),('C0326','Thokai joypuri mena churi soru',4,'H','2011-01-29 12:22:23','saheb',NULL,1,0.05),('C0327','Thokai joypuri mena churi soru',4,'H','2011-01-29 12:22:36','saheb',NULL,1,0.05),('C0328','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:20:01','b',NULL,1,0.05),('C0329','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:20:15','b',NULL,1,0.05),('C0330','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:28:26','b',NULL,1,0.05),('C0331','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:29:29','b',NULL,1,0.05),('C0332','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:29:46','b',NULL,1,0.05),('C0333','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:30:17','b',NULL,1,0.05),('C0334','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:30:30','b',NULL,1,0.05),('C0335','Thokai joypuri mena churi soru',4,'H','2010-06-04 19:30:53','b',NULL,1,0.05),('C0336','Thokai joypuri churi maghari',4,'H','2010-06-04 19:32:17','b',NULL,1,0.05),('C0337','Thokai joypuri churi maghari',4,'H','2010-06-04 19:33:10','b',NULL,1,0.05),('C0338','Thokai joypuri churi maghari',4,'H','2010-06-04 19:33:21','b',NULL,1,0.05),('C0339','Thokai joypuri churi maghari',4,'H','2010-06-04 19:33:32','b',NULL,1,0.05),('C0340','Thokai joypuri churi maghari',4,'H','2010-06-04 19:34:08','b',NULL,1,0.05),('C0341','Thokai joypuri churi maghari',4,'H','2010-06-04 19:34:18','b',NULL,1,0.05),('C0342','Thokai joypuri churi maghari',4,'H','2010-06-04 19:34:30','b',NULL,1,0.05),('C0343','Thokai joypuri churi maghari',4,'H','2010-06-04 19:35:27','b',NULL,1,0.05),('C0344','Thokai joypuri churi maghari',4,'H','2010-06-04 19:35:55','b',NULL,1,0.05),('C0345','Thokai joypuri churi maghari',4,'H','2010-06-04 19:36:12','b',NULL,1,0.05),('C0346','Thokai joypuri churi maghari',4,'H','2010-06-04 19:36:32','b',NULL,1,0.05),('C0347','Thokai joypuri churi maghari',4,'H','2010-06-04 19:36:53','b',NULL,1,0.05),('C0348','Thokai joypuri churi maghari',4,'H','2010-06-04 19:37:10','b',NULL,1,0.05),('C0349','Thokai joypuri churi maghari',4,'H','2010-06-04 19:37:25','b',NULL,1,0.05),('C0350','Thokai joypuri churi maghari',4,'H','2010-06-04 19:37:43','b',NULL,1,0.05),('C0351','Thokai joypuri churi maghari',4,'H','2010-06-04 19:38:01','b',NULL,1,0.05),('C0352','Thokai joypuri churi maghari',4,'H','2010-06-04 19:38:29','b',NULL,1,0.05),('C0353','Thokai joypuri churi maghari',4,'H','2010-06-04 19:38:44','b',NULL,1,0.05),('C0354','Thokai joypuri churi maghari',4,'H','2010-06-04 19:39:00','b',NULL,1,0.05),('C0355','Thokai joypuri churi maghari',4,'H','2010-06-04 19:39:15','b',NULL,1,0.05),('C0356','Thokai joypuri churi maghari',4,'H','2010-06-04 19:40:11','b',NULL,1,0.05),('C0357','Thokai joypuri churi maghari',4,'H','2010-06-04 19:40:28','b',NULL,1,0.05),('C0358','Thokai joypuri churi maghari',4,'H','2010-06-04 19:40:44','b',NULL,1,0.05),('C0359','Thokai joypuri churi maghari',4,'H','2010-06-04 19:41:00','b',NULL,1,0.05),('C0360','Thokai joypuri churi maghari',4,'H','2010-06-04 19:41:38','b',NULL,1,0.05),('C0363','Thokai joypuri meena churi maghari',4,'G','2010-06-04 19:44:01','b',NULL,1,0.05),('C0365','Thokai joypuri meena churi maghari',4,'I','2010-06-04 19:44:33','b',NULL,1,0.05),('C0368','Thokai joypuri meena churi maghari',4,'H','2010-06-04 19:45:27','b',NULL,1,0.05),('C0369','Thokai joypuri meena churi maghari',4,'H','2010-06-04 19:45:39','b',NULL,1,0.05),('C0370','Thokai joypuri meena churi maghari',4,'H','2010-06-04 19:45:52','b',NULL,1,0.05),('C0371','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:47:03','b',NULL,1,0.05),('C0372','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:48:05','b',NULL,1,0.05),('C0373','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:48:19','b',NULL,1,0.05),('C0374','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:48:32','b',NULL,1,0.05),('C0375','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:48:50','b',NULL,1,0.05),('C0376','Thokai joypuri  churi chowrah',4,'G','2010-06-04 19:49:04','b',NULL,1,0.05),('C0377','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:49:23','b',NULL,1,0.05),('C0378','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:49:43','b',NULL,1,0.05),('C0379','Thokai joypuri  churi chowrah',4,'I','2010-06-04 19:49:58','b',NULL,1,0.05),('C0380','Thokai joypuri  churi chowrah',4,'I','2010-06-04 19:50:18','b',NULL,1,0.05),('C0381','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:50:37','b',NULL,1,0.05),('C0382','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:50:51','b',NULL,1,0.05),('C0383','Thokai joypuri  churi chowrah',4,'I','2010-06-04 19:51:04','b',NULL,1,0.05),('C0384','Thokai joypuri  churi chowrah',4,'H','2010-06-04 19:51:15','b',NULL,1,0.05),('C0385','Thokai joypuri  churi chowrah',4,'I','2010-06-05 11:15:02','sanjoy',NULL,1,0.05),('C0387','PLAZA',4,'G','2010-06-04 19:52:58','b',NULL,1,0.05),('C0388','Thokai joypuri meena churi chowrah',4,'J','2010-06-04 19:53:27','b',NULL,1,0.05),('C0389','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:53:46','b',NULL,1,0.05),('C0390','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:54:09','b',NULL,1,0.05),('C0391','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:54:23','b',NULL,1,0.05),('C0392','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:54:44','b',NULL,1,0.05),('C0393','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:55:00','b',NULL,1,0.05),('C0394','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:55:13','b',NULL,1,0.05),('C0395','Thokai joypuri meena churi chowrah',4,'H','2010-06-04 19:55:29','b',NULL,1,0.05),('C0396','Thokai dd mena churi chowrah',4,'H','2011-01-29 12:25:06','saheb',NULL,1,0.05),('C0397','Thokai Plaja churi',4,'I','2011-01-09 15:35:43','sandip',NULL,1,0.05),('C0398','Thokai Plaja churi',4,'H','2011-01-29 12:25:41','saheb',NULL,1,0.05),('C0399','Thokai Plaja churi',4,'H','2011-01-29 12:26:03','saheb',NULL,1,0.05),('C0400','Thokai churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0401','flat panching churi saru',4,'M','2010-06-05 10:56:55','sanjoy',NULL,1,0.05),('C0402','flat panching churi saru',4,'M','2010-06-05 10:57:28','sanjoy',NULL,1,0.05),('C0403','flat panching churi saru',4,'M','2010-06-05 10:57:38','sanjoy',NULL,1,0.05),('C0404','flat panching churi saru',4,'I','2010-06-05 10:58:09','sanjoy',NULL,1,0.05),('C0405','flat panching churi saru',4,'M','2010-06-05 10:58:19','sanjoy',NULL,1,0.05),('C0406','flat panching churi saru',4,'M','2010-06-05 10:58:31','sanjoy',NULL,1,0.05),('C0407','flat panching churi saru',4,'M','2010-06-05 10:58:51','sanjoy',NULL,1,0.05),('C0408','flat panching churi saru',4,'M','2010-06-05 10:59:11','sanjoy',NULL,1,0.05),('C0409','flat panching churi saru',4,'I','2010-06-05 10:59:20','sanjoy',NULL,1,0.05),('C0410','flat panching churi saru',4,'M','2010-06-05 10:59:32','sanjoy',NULL,1,0.05),('C0411','flat panching churi saru',4,'M','2010-06-05 10:59:41','sanjoy',NULL,1,0.05),('C0412','flat panching churi saru',4,'M','2010-06-05 10:59:50','sanjoy',NULL,1,0.05),('C0413','flat panching churi saru',4,'M','2010-06-05 10:59:58','sanjoy',NULL,1,0.05),('C0414','flat panching churi saru',4,'M','2010-06-05 11:00:06','sanjoy',NULL,1,0.05),('C0415','flat panching churi saru',4,'M','2010-06-05 11:00:16','sanjoy',NULL,1,0.05),('C0416','flat panching churi saru',4,'O','2010-06-05 11:00:25','sanjoy',NULL,1,0.05),('C0417','flat panching churi saru',4,'N','2010-06-05 11:00:34','sanjoy',NULL,1,0.05),('C0418','flat panching churi saru',4,'M','2010-06-05 11:00:43','sanjoy',NULL,1,0.05),('C0419','Churi',4,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0420','flat panching churi saru',4,'M','2010-06-05 11:01:02','sanjoy',NULL,1,0.05),('C0428','flat panching mena churi soru',4,'N','2010-06-05 12:33:50','sanjoy',NULL,1,0.05),('C0430','flat panching mena churi soru',4,'N','2010-06-05 12:34:11','sanjoy',NULL,1,0.05),('C0431','flat panching mena churi soru',4,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0432','flat panching mena churi soru',4,'N','2010-06-05 12:34:29','sanjoy',NULL,1,0.05),('C0433','flat panching mena churi soru',4,'N','2010-06-05 12:34:56','sanjoy',NULL,1,0.05),('C0434','flat panching mena churi soru',4,'N','2010-06-05 12:34:46','sanjoy',NULL,1,0.05),('C0435','flat panching mena churi soru',4,'N','2010-06-05 12:35:07','sanjoy',NULL,1,0.05),('C0436','flat panching churi maghri ',4,'N','2010-06-05 12:38:05','sanjoy',NULL,1,0.05),('C0437','flat panching churi maghri ',4,'N','2010-06-05 12:38:38','sanjoy',NULL,1,0.05),('C0438','flat panching churi maghri ',4,'N','2010-06-05 12:38:46','sanjoy',NULL,1,0.05),('C0439','flat panching churi maghri ',4,'N','2010-06-05 12:38:54','sanjoy',NULL,1,0.05),('C0440','flat panching churi maghri ',4,'N','2010-06-05 12:39:02','sanjoy',NULL,1,0.05),('C0441','flat panching churi maghri ',4,'N','2010-06-05 12:39:12','sanjoy',NULL,1,0.05),('C0442','flat panching churi maghri ',4,'N','2010-06-05 12:39:20','sanjoy',NULL,1,0.05),('C0443','flat panching churi maghri ',4,'N','2010-06-05 12:39:27','sanjoy',NULL,1,0.05),('C0444','flat panching churi maghri ',4,'N','2010-06-05 12:39:37','sanjoy',NULL,1,0.05),('C0445','flat panching churi maghri ',4,'N','2010-06-05 12:39:45','sanjoy',NULL,1,0.05),('C0446','flat panching churi maghri ',4,'N','2011-01-29 12:30:26','saheb',NULL,1,0.05),('C0447','flat panching churi maghri ',4,'N','2010-06-05 12:40:02','sanjoy',NULL,1,0.05),('C0448','flat panching churi maghri ',4,'N','2010-06-05 12:40:10','sanjoy',NULL,1,0.05),('C0449','flat panching churi maghri ',4,'N','2010-06-05 12:40:18','sanjoy',NULL,1,0.05),('C0450','flat panching churi maghri ',4,'N','2010-06-05 12:40:26','sanjoy',NULL,1,0.05),('C0451','churi',4,'N','2011-01-29 16:24:51','saheb',NULL,1,0.05),('C0452','flat panching churi maghri ',4,'N','2010-06-05 12:40:40','sanjoy',NULL,1,0.05),('C0453','flat panching churi maghri ',4,'N','2010-06-05 12:40:50','sanjoy',NULL,1,0.05),('C0454','flat panching churi maghri ',4,'N','2010-06-05 12:40:58','sanjoy',NULL,1,0.05),('C0455','churi',4,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0457','flat panching churi maghri ',4,'N','2010-06-05 12:41:42','sanjoy',NULL,1,0.05),('C0458','flat panching churi maghri ',4,'N','2010-06-05 12:41:54','sanjoy',NULL,1,0.05),('C0459','flat panching churi maghri ',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0460','flat panching churi maghri ',4,'N','2010-06-05 12:42:17','sanjoy',NULL,1,0.05),('C0461','flat panching mena churi soru',4,'N',NULL,NULL,NULL,0,0),('C0463','flat panching mena churi maghri ',4,'O','2010-06-05 12:43:35','sanjoy',NULL,1,0.05),('C0465','flat panching mena churi maghri ',4,'O','2010-06-05 12:44:22','sanjoy',NULL,1,0.05),('C0466','flat panching mena churi maghri ',4,'O','2010-06-05 12:44:31','sanjoy',NULL,1,0.05),('C0468','flat panching mena churi maghri ',4,'O','2010-06-05 12:44:52','sanjoy',NULL,1,0.05),('C0469','flat panching mena churi maghri ',4,'O','2010-06-05 12:45:00','sanjoy',NULL,1,0.05),('C0470','flat panching mena churi maghri ',4,'O','2010-06-05 12:45:08','sanjoy',NULL,1,0.05),('C0471','flat panching churi chowrah',4,'P','2010-06-05 12:45:58','sanjoy',NULL,1,0.05),('C0472','flat panching churi chowrah',4,'P','2010-06-05 12:46:17','sanjoy',NULL,1,0.05),('C0473','flat panching churi chowrah',4,'P','2010-06-05 12:46:27','sanjoy',NULL,1,0.05),('C0474','flat panching churi chowrah',4,'P','2010-06-05 12:46:36','sanjoy',NULL,1,0.05),('C0475','flat panching churi chowrah',4,'P','2010-06-05 12:46:45','sanjoy',NULL,1,0.05),('C0476','flat panching churi chowrah',4,'P','2010-06-05 12:46:54','sanjoy',NULL,1,0.05),('C0477','flat panching churi chowrah',4,'N','2010-06-05 12:47:02','sanjoy',NULL,1,0.05),('C0478','flat panching churi chowrah',4,'N','2010-06-05 12:47:14','sanjoy',NULL,1,0.05),('C0479','flat panching churi chowrah',4,'P','2010-06-05 12:47:23','sanjoy',NULL,1,0.05),('C0480','flat panching churi chowrah',4,'P','2010-06-05 12:47:30','sanjoy',NULL,1,0.05),('C0481','flat panching churi chowrah',4,'P','2010-06-05 12:47:38','sanjoy',NULL,1,0.05),('C0482','flat panching churi chowrah',4,'P','2010-06-05 12:47:48','sanjoy',NULL,1,0.05),('C0483','flat panching churi chowrah',4,'P','2010-06-05 12:48:06','sanjoy',NULL,1,0.05),('C0484','flat panching churi chowrah',4,'P','2010-06-05 12:48:14','sanjoy',NULL,1,0.05),('C0485','flat panching churi chowrah',4,'P','2010-06-05 12:48:23','sanjoy',NULL,1,0.05),('C0486','flat panching mena churi chowrah',4,'Q','2010-06-05 12:49:11','sanjoy',NULL,1,0.05),('C0489','flat panching mena churi chowrah',4,'Q','2010-06-05 12:49:52','sanjoy',NULL,1,0.05),('C0490','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:00','sanjoy',NULL,1,0.05),('C0491','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:08','sanjoy',NULL,1,0.05),('C0492','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:15','sanjoy',NULL,1,0.05),('C0493','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:23','sanjoy',NULL,1,0.05),('C0494','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:33','sanjoy',NULL,1,0.05),('C0495','flat panching mena churi chowrah',4,'Q','2010-06-05 12:50:44','sanjoy',NULL,1,0.05),('C0501','Half round panching churi soru',4,'M','2010-06-05 12:52:14','sanjoy',NULL,1,0.05),('C0502','Half round panching churi soru',4,'M','2010-06-05 12:52:35','sanjoy',NULL,1,0.05),('C0503','Half round panching churi soru',4,'M','2010-06-05 12:52:49','sanjoy',NULL,1,0.05),('C0504','Half round panching churi soru',4,'M','2010-06-05 12:52:58','sanjoy',NULL,1,0.05),('C0505','Half round panching churi soru',4,'M','2010-06-05 12:53:21','sanjoy',NULL,1,0.05),('C0506','Half round panching churi soru',4,'M','2010-06-05 12:53:33','sanjoy',NULL,1,0.05),('C0507','Half round panching churi soru',4,'M','2010-06-05 12:53:44','sanjoy',NULL,1,0.05),('C0508','Half round panching churi soru',4,'M','2010-06-05 12:53:54','sanjoy',NULL,1,0.05),('C0509','Half round panching churi soru',4,'M','2010-06-05 12:54:02','sanjoy',NULL,1,0.05),('C0510','Half round panching churi soru',4,'M','2010-06-05 12:54:11','sanjoy',NULL,1,0.05),('C0511','Half round panching churi soru',4,'M','2010-06-05 12:54:21','sanjoy',NULL,1,0.05),('C0512','Half round panching churi soru',4,'M','2010-06-05 12:54:29','sanjoy',NULL,1,0.05),('C0513','Half round panching churi soru',4,'M','2010-06-05 12:54:43','sanjoy',NULL,1,0.05),('C0514','Half round panching churi soru',4,'M','2010-06-05 12:54:53','sanjoy',NULL,1,0.05),('C0515','Half round panching churi soru',4,'M','2010-06-05 12:55:03','sanjoy',NULL,1,0.05),('C0516','Half round panching mena churi soru',4,'N','2010-06-05 12:55:43','sanjoy',NULL,1,0.05),('C0517','Half round panching mena churi soru',4,'N','2010-06-05 12:55:59','sanjoy',NULL,1,0.05),('C0518','Half round panching mena churi soru',4,'N','2010-06-05 12:56:08','sanjoy',NULL,1,0.05),('C0519','Half round panching mena churi soru',4,'N','2010-06-05 12:56:19','sanjoy',NULL,1,0.05),('C0520','Half round panching mena churi soru',4,'N','2010-06-05 12:56:48','sanjoy',NULL,1,0.05),('C0521','Half round panching churi maghri',4,'N','2010-06-05 12:57:47','sanjoy',NULL,1,0.05),('C0522','Half round panching churi maghari',4,'N','2010-06-05 12:58:35','sanjoy',NULL,1,0.05),('C0523','Half round panching churi maghari',4,'N','2010-06-05 12:58:55','sanjoy',NULL,1,0.05),('C0524','Half round panching churi maghari',4,'N','2010-06-05 12:59:15','sanjoy',NULL,1,0.05),('C0525','Half round panching churi maghari',4,'N','2010-06-05 12:59:27','sanjoy',NULL,1,0.05),('C0526','Half round panching churi maghari',4,'N','2010-06-05 12:59:41','sanjoy',NULL,1,0.05),('C0527','Half round panching churi maghari',4,'N','2010-06-05 12:59:53','sanjoy',NULL,1,0.05),('C0528','Half round panching churi maghari',4,'N','2010-06-05 13:00:02','sanjoy',NULL,1,0.05),('C0529','Half round panching churi maghari',4,'N','2010-06-05 13:00:14','sanjoy',NULL,1,0.05),('C0530','Half round panching churi maghari',4,'N','2010-06-05 13:00:23','sanjoy',NULL,1,0.05),('C0531','Half round panching churi maghari',4,'N','2010-06-05 13:00:33','sanjoy',NULL,1,0.05),('C0532','Half round panching churi maghari',4,'N','2010-06-05 13:00:41','sanjoy',NULL,1,0.05),('C0533','Half round panching churi maghari',4,'N','2010-06-05 13:00:50','sanjoy',NULL,1,0.05),('C0534','Half round panching churi maghari',4,'N','2010-06-05 13:00:57','sanjoy',NULL,1,0.05),('C0535','Half round panching churi maghari',4,'N','2010-06-05 13:01:08','sanjoy',NULL,1,0.05),('C0536','Half round panching churi maghari',4,'N','2010-06-05 13:01:21','sanjoy',NULL,1,0.05),('C0537','Half round panching churi maghari',4,'N','2010-06-05 13:01:33','sanjoy',NULL,1,0.05),('C0538','Half round panching churi maghari',4,'N','2010-06-05 13:01:40','sanjoy',NULL,1,0.05),('C0539','Half round panching churi maghari',4,'N','2010-06-05 13:01:48','sanjoy',NULL,1,0.05),('C0540','Half round panching churi maghari',4,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0541','Half round panching mena churi maghari',4,'O','2010-06-05 13:03:22','sanjoy',NULL,1,0.05),('C0542','Half round panching mena churi maghari',4,'O','2010-06-05 13:03:56','sanjoy',NULL,1,0.05),('C0544','Half round panching mena churi maghari',4,'O','2010-06-05 13:04:22','sanjoy',NULL,1,0.05),('C0545','flat panching churi maghri ',4,'N','2010-06-05 12:41:07','sanjoy',NULL,1,0.05),('C0546','Half round panching mena churi maghari',4,'O','2010-06-05 13:11:55','sanjoy',NULL,1,0.05),('C0547','Half round panching mena churi maghari',4,'O','2010-06-05 13:05:58','sanjoy',NULL,1,0.05),('C0548','Half round panching mena churi maghari',4,'O','2010-06-05 13:20:01','sanjoy',NULL,1,0.05),('C0549','Half round panching mena churi maghari',4,'O','2010-06-05 13:20:12','sanjoy',NULL,1,0.05),('C0550','Half round panching mena churi maghari',4,'O','2010-06-05 13:20:23','sanjoy',NULL,1,0.05),('C0551','tashir panching churi soru',4,'M','2010-06-05 13:22:25','sanjoy',NULL,1,0.05),('C0552','tashir panching churi soru',4,'M','2010-06-05 13:22:46','sanjoy',NULL,1,0.05),('C0553','tashir panching churi soru',4,'M','2010-06-05 13:22:54','sanjoy',NULL,1,0.05),('C0554','tashir panching churi soru',4,'M','2010-06-05 13:23:04','sanjoy',NULL,1,0.05),('C0555','tashir panching churi soru',4,'M','2010-06-05 13:23:11','sanjoy',NULL,1,0.05),('C0556','tashir panching churi soru',4,'M','2010-06-05 13:23:23','sanjoy',NULL,1,0.05),('C0557','tashir panching churi soru',4,'M','2010-06-05 13:23:50','sanjoy',NULL,1,0.05),('C0558','tashir panching churi soru',4,'M','2010-06-05 13:23:58','sanjoy',NULL,1,0.05),('C0559','tashir panching churi soru',4,'M','2010-06-05 13:24:05','sanjoy',NULL,1,0.05),('C0560','tashir panching churi soru',4,'M','2010-06-05 13:24:22','sanjoy',NULL,1,0.05),('C0561','tashir panching churi soru',4,'M','2010-06-05 13:24:31','sanjoy',NULL,1,0.05),('C0562','tashir panching churi soru',4,'M','2010-06-05 13:24:40','sanjoy',NULL,1,0.05),('C0563','tashir panching churi soru',4,'M','2010-06-05 13:24:53','sanjoy',NULL,1,0.05),('C0564','tashir panching churi soru',4,'M','2010-06-05 13:25:04','sanjoy',NULL,1,0.05),('C0565','tashir panching churi soru',4,'M','2010-06-05 13:25:14','sanjoy',NULL,1,0.05),('C0566','tashir panching churi soru',4,'M','2010-06-05 13:25:26','sanjoy',NULL,1,0.05),('C0567','tashir panching churi soru',4,'M','2010-06-05 13:25:40','sanjoy',NULL,1,0.05),('C0568','tashir panching churi soru',4,'M','2010-06-05 13:31:39','sanjoy',NULL,1,0.05),('C0569','tashir panching churi soru',4,'M','2010-06-05 13:38:04','b',NULL,1,0.05),('C0570','tashir panching churi soru',4,'N','2010-06-05 15:48:13','sanjoy',NULL,1,0.05),('C0572','tashir panchin gmena churi soru',4,'N','2010-06-05 16:06:37','sanjoy',NULL,1,0.05),('C0573','tashir panchin gmena churi soru',4,'N','2010-06-05 16:06:53','sanjoy',NULL,1,0.05),('C0574','tashir panchin gmena churi soru',4,'N','2010-06-05 16:07:11','sanjoy',NULL,1,0.05),('C0575','tashir panchin gmena churi soru',4,'N','2010-06-05 16:07:19','sanjoy',NULL,1,0.05),('C0576','tashir panching churi maghari',4,'N','2010-06-05 16:09:05','sanjoy',NULL,1,0.05),('C0577','tashir panching churi maghari',4,'N','2010-06-05 16:09:20','sanjoy',NULL,1,0.05),('C0578','tashir panching churi maghari',4,'N','2010-06-05 16:09:41','sanjoy',NULL,1,0.05),('C0579','tashir panching churi maghari',4,'N','2010-06-05 16:09:47','sanjoy',NULL,1,0.05),('C0580','tashir panching churi maghari',4,'N','2010-06-05 16:09:57','sanjoy',NULL,1,0.05),('C0581','tashir panching churi maghari',4,'N','2010-06-05 16:10:03','sanjoy',NULL,1,0.05),('C0582','tashir panching churi maghari',4,'N','2010-06-05 16:10:21','sanjoy',NULL,1,0.05),('C0583','tashir panching churi maghari',4,'N','2010-06-05 16:10:29','sanjoy',NULL,1,0.05),('C0584','tashir panching churi maghari',4,'N','2010-06-05 16:10:45','sanjoy',NULL,1,0.05),('C0585','tashir panching churi maghari',4,'N','2010-06-05 16:10:54','sanjoy',NULL,1,0.05),('C0586','tashir panching mena churi maghari',4,'O','2010-06-05 16:12:14','sanjoy',NULL,1,0.05),('C0587','tashir panching mena churi maghari',4,'O','2010-06-05 16:22:52','b',NULL,1,0.05),('C0588','tashir panching mena churi maghari',4,'O','2010-06-05 16:22:59','b',NULL,1,0.05),('C0589','tashir panching mena churi maghari',4,'O','2010-06-05 16:23:07','b',NULL,1,0.05),('C0590','tashir panching mena churi maghari',4,'O','2010-06-05 16:23:16','b',NULL,1,0.05),('C0601','Machin chala khal mini bowti soru',4,'I','2010-06-05 16:26:53','b',NULL,1,0.05),('C0602','Machin chala khal mini bowti soru',4,'I','2010-06-05 16:27:01','b',NULL,1,0.05),('C0603','Machin chala khal mini bowti soru',4,'I','2010-06-05 16:27:08','b',NULL,1,0.05),('C0604','Machin chala khal mini bowti soru',4,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0605','Machin chala khal mini bowti soru',4,'I','2010-06-05 16:28:07','b',NULL,1,0.05),('C0606','Machin chala khal mena decaration mini bowti soru',4,'J','2010-06-05 16:31:29','b',NULL,1,0.05),('C0607','Machin chala khal mena decaration mini bowti soru',4,'J','2010-06-05 16:31:40','b',NULL,1,0.05),('C0608','Machin chala khal mena decaration mini bowti soru',4,'J','2010-06-05 16:31:56','b',NULL,1,0.05),('C0609','Machin chala khal mena decaration mini bowti soru',4,'J','2010-06-05 16:32:16','b',NULL,1,0.05),('C0610','Machin chala khal mena decaration mini bowti soru',4,'J','2010-06-05 16:32:33','b',NULL,1,0.05),('C0611','Machin chala khal mini  bowti maghari',4,'J','2010-06-05 16:50:49','sanjoy',NULL,1,0.05),('C0612','Machin chala khal mini  bowti maghari',4,'J','2010-06-05 16:51:13','sanjoy',NULL,1,0.05),('C0613','Machin chala khal mini  bowti maghari',4,'J','2010-06-05 16:51:17','sanjoy',NULL,1,0.05),('C0614','Machin chala khal mini  bowti maghari',4,'J','2010-06-05 16:51:25','sanjoy',NULL,1,0.05),('C0615','Machin chala khal mini  bowti maghari',4,'J','2010-06-05 16:51:30','sanjoy',NULL,1,0.05),('C0616','Machin chala khal mena decaration mini bowti maghari',4,'K','2010-06-05 16:56:16','sanjoy',NULL,1,0.05),('C0617','Machin chala khal mena decaration mini bowti maghari',4,'K','2010-06-05 16:56:06','sanjoy',NULL,1,0.05),('C0618','Machin chala khal mena decaration mini bowti maghari',4,'K','2010-06-05 16:55:57','sanjoy',NULL,1,0.05),('C0619','Machin chala khal mena decaration mini bowti maghari',4,'K','2010-06-05 16:55:34','sanjoy',NULL,1,0.05),('C0620','Machin chala khal mena decaration mini bowti maghari',4,'K','2010-06-05 16:55:28','sanjoy',NULL,1,0.05),('C0621','Machin chala khal mini bowti chowah',4,'K','2010-06-05 16:58:08','sanjoy',NULL,1,0.05),('C0622','Machin chala khal mini bowti chowah',4,'K','2010-06-05 16:58:18','sanjoy',NULL,1,0.05),('C0623','Machin chala khal mini bowti chowah',4,'K','2010-06-05 16:58:27','sanjoy',NULL,1,0.05),('C0624','Machin chala khal mini bowti chowah',4,'K','2010-06-05 16:58:32','sanjoy',NULL,1,0.05),('C0625','Machin chala khal mini bowti chowah',4,'K','2010-06-05 16:58:42','sanjoy',NULL,1,0.05),('C0626','Machin chala khal mena decaration mini bowti chowah',4,'L','2010-06-05 17:01:07','sanjoy',NULL,1,0.05),('C0627','Machin chala khal mena decaration mini bowti chowah',4,'L','2010-06-05 17:02:04','sanjoy',NULL,1,0.05),('C0628','Machin chala khal  decaration mini bowti chowah',4,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0629','Machin chala khal mena decaration mini bowti chowah',4,'L','2010-06-05 17:02:11','sanjoy',NULL,1,0.05),('C0630','Machin chala khal mena decaration mini bowti chowah',4,'L','2010-06-05 17:02:16','sanjoy',NULL,1,0.05),('C0631','Machin chala khal panching mini bowti soru',4,'L','2010-06-05 17:05:11','sanjoy',NULL,1,0.05),('C0632','Machin chala khal panching mini bowti soru',4,'L','2010-06-05 17:05:18','sanjoy',NULL,1,0.05),('C0633','Machin chala khal panching mini bowti soru',4,'L','2010-06-05 17:05:21','sanjoy',NULL,1,0.05),('C0634','Machin chala khal panching mini bowti soru',4,'L','2010-06-05 17:05:25','sanjoy',NULL,1,0.05),('C0635','Machin chala khal panching mini bowti soru',4,'L','2010-06-05 17:05:29','sanjoy',NULL,1,0.05),('C0636','Machin chala khal panching mena decaration mini bowti soru',4,'L','2010-06-05 17:06:47','sanjoy',NULL,1,0.05),('C0637','Machin chala khal panching mena decaration mini bowti soru',4,'L','2010-06-05 17:06:52','sanjoy',NULL,1,0.05),('C0638','Machin chala khal panching mena decaration mini bowti soru',4,'L','2010-06-05 17:06:56','sanjoy',NULL,1,0.05),('C0639','Machin chala khal panching mena decaration mini bowti soru',4,'L','2010-06-05 17:06:59','sanjoy',NULL,1,0.05),('C0640','Machin chala khal panching mena decaration mini bowti soru',4,'L','2010-06-05 17:07:06','sanjoy',NULL,1,0.05),('C0641','Machin chala khal panching  mini bowti maghari',4,'L','2010-06-05 17:08:58','sanjoy',NULL,1,0.05),('C0642','Machin chala khal panching  mini bowti maghari',4,'L','2010-06-05 17:09:06','sanjoy',NULL,1,0.05),('C0643','Machin chala khal panching  mini bowti maghari',4,'L','2010-06-05 17:09:09','sanjoy',NULL,1,0.05),('C0644','Machin chala khal panching  mini bowti maghari',4,'L','2010-06-05 17:09:21','sanjoy',NULL,1,0.05),('C0645','Machin chala khal panching  mini bowti maghari',4,'L','2010-06-05 17:09:30','sanjoy',NULL,1,0.05),('C0647','Machin chala khal panching mena decaration mini bowti maghari',4,'M','2010-06-05 17:11:41','sanjoy',NULL,1,0.05),('C0648','Machin chala khal panching mena decaration mini bowti maghari',4,'M','2010-06-05 17:13:40','sanjoy',NULL,1,0.05),('C0649','Machin chala khal panching mena decaration mini bowti maghari',4,'M','2010-06-05 17:13:52','sanjoy',NULL,1,0.05),('C0650','Machin chala khal panching mena decaration mini bowti maghari',4,'M','2010-06-05 17:13:55','sanjoy',NULL,1,0.05),('C0651','Machin chala khal panching mini bowti chowrah',4,'M','2010-06-05 17:16:11','sanjoy',NULL,1,0.05),('C0652','Machin chala khal panching mini bowti chowrah',4,'M','2010-06-05 17:16:17','sanjoy',NULL,1,0.05),('C0653','Machin chala khal panching mini bowti chowrah',4,'M','2010-06-05 17:16:24','sanjoy',NULL,1,0.05),('C0654','Machin chala khal panching mini bowti chowrah',4,'M','2010-06-05 17:16:30','sanjoy',NULL,1,0.05),('C0655','Machin chala khal panching mini bowti chowrah',4,'M','2010-06-05 17:16:33','sanjoy',NULL,1,0.05),('C0657','Machin chala khal panching mena decaration mini bowti chowrah',4,'N','2010-06-05 17:18:12','sanjoy',NULL,1,0.05),('C0658','Machin chala khal panching mena decaration mini bowti chowrah',4,'N','2010-06-05 17:18:26','sanjoy',NULL,1,0.05),('C0659','Machin chala khal panching mena decaration mini bowti chowrah',4,'N','2010-06-05 17:18:30','sanjoy',NULL,1,0.05),('C0660','Machin chala khal panching mena decaration mini bowti chowrah',4,'N','2010-06-05 17:18:36','sanjoy',NULL,1,0.05),('C0661','Machin chala khal panching mena decaration mini bowti chowrah',4,'J','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0662','Machin chala khal panching mena decaration mini bowti chowrah',4,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0663','Machin chala khal panching mena decaration mini bowti chowrah',4,'J','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0665','Machin chala khal panching mena decaration mini bowti chowrah',4,'J','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0666','Thokai dd mini bowti ',4,'L','2010-06-04 19:57:35','b',NULL,1,0.05),('C0667','Thokai dd mini bowti ',4,'L','2010-06-04 19:58:02','b',NULL,1,0.05),('C0668','Thokai dd mini bowti ',4,'L','2010-06-04 19:58:21','b',NULL,1,0.05),('C0669','Thokai dd mini bowti ',4,'L','2010-06-04 19:58:34','b',NULL,1,0.05),('C0670','Thokai dd mini bowti ',4,'L','2010-06-04 19:59:04','b',NULL,1,0.05),('C0671','Thokai Bowti',4,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0672','Thokai dd mini meena bowti ',4,'M','2010-06-04 20:00:10','b',NULL,1,0.05),('C0673','Thokai dd mini meena bowti ',4,'M','2010-06-04 20:00:33','b',NULL,1,0.05),('C0674','Thokai dd mini meena bowti ',4,'M','2010-06-04 20:00:50','b',NULL,1,0.05),('C0675','Thokai dd mini meena bowti ',4,'M','2010-06-04 20:01:08','b',NULL,1,0.05),('C0676','Thokai bangla mini bowti',4,'K','2010-06-04 20:02:18','b',NULL,1,0.05),('C0677','Thokai bangla mini bowti',4,'K','2010-06-04 20:03:15','b',NULL,1,0.05),('C0678','Thokai bangla mini bowti',4,'K','2010-06-04 20:03:33','b',NULL,1,0.05),('C0679','Thokai bangla mini bowti',4,'K','2010-06-04 20:03:55','b',NULL,1,0.05),('C0680','Thokai bangla mini bowti',4,'K','2010-06-04 20:04:17','b',NULL,1,0.05),('C0681','Thokai bangla mini meeena  bowti',4,'L','2010-06-04 20:05:10','b',NULL,1,0.05),('C0682','Thokai bangla mini meeena  bowti',4,'L','2010-06-04 20:06:15','b',NULL,1,0.05),('C0683','Thokai bangla mini meeena  bowti',4,'L','2010-06-04 20:06:32','b',NULL,1,0.05),('C0684','Thokai bangla mini meeena  bowti',4,'L','2010-06-04 20:06:51','b',NULL,1,0.05),('C0685','Thokai bangla mini meeena  bowti',4,'L','2010-06-04 20:07:04','b',NULL,1,0.05),('C0686','Thokai joypuri mini bowti',4,'L','2010-06-05 09:58:34','sanjoy',NULL,1,0.05),('C0687','Thokai joypuri mini bowti',4,'K','2010-06-05 09:59:35','sanjoy',NULL,1,0.05),('C0688','Thokai joypuri mini bowti',4,'K','2010-06-05 09:59:47','sanjoy',NULL,1,0.05),('C0689','Thokai joypuri mini bowti',4,'K','2010-06-05 09:59:58','sanjoy',NULL,1,0.05),('C0690','Thokai joypuri mini bowti',4,'K','2010-06-05 10:00:23','sanjoy',NULL,1,0.05),('C0691','Thokai joypuri mena decaration mini bowti',4,'L','2010-06-05 10:02:26','sanjoy',NULL,1,0.05),('C0692','Thokai joypuri mena decaration mini bowti',4,'L','2010-06-05 10:03:11','sanjoy',NULL,1,0.05),('C0693','Thokai joypuri mena decaration mini bowti',4,'L','2010-06-05 10:03:22','sanjoy',NULL,1,0.05),('C0694','Thokai joypuri mena decaration mini bowti',4,'L','2010-06-05 10:03:41','sanjoy',NULL,1,0.05),('C0695','Thokai joypuri mena decaration mini bowti',4,'L','2010-06-05 10:03:51','sanjoy',NULL,1,0.05),('C0697','Thokai Mini Bouty',13,'L','2011-01-07 18:53:05','sandip',NULL,1,0.05),('C0699','Thokai Bouty',13,'M','2011-01-11 20:01:07','sandip',NULL,1,0.05),('C0701','Thokai bangala patla soru',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0702','Thokai bangala patla soru',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0703','Thokai bangala patla soru',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0704','Thokai bangala patla soru',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0705','Thokai bangala patla soru',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0706','Thokai bangala patla soru',14,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0707','Thokai bangala patla soru',14,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0708','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0709','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0710','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0711','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0712','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0713','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0714','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0715','Thokai bangala patla mena soru',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0716','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0720','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0721','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0722','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0723','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0724','Thokai bangala patla mena maghari',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0725','Thokai bangala patla chowrah',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0726','Thokai bangala patla mena chowrah',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0727','Thokai bangala patla mena chowrah',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0730','Thokai bangala patla mena chowrah',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0731','Thokai Patla',14,'N','2011-01-09 12:17:28','sandip',NULL,1,0.05),('C0733','Thokai Patla',14,'M','2011-01-15 22:09:54','sandip',NULL,1,0.05),('C0735','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0736','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0737','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0738','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0739','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0740','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0741','Thokai joypuri mena patla soru',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0742','Thokai joypuri mena patla soru',4,'M','2010-06-05 10:28:56','sanjoy',NULL,1,0.05),('C0743','Thokai joypuri patla soru',4,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0744','Thokai joypuri patla soru',4,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0745','Thokai joypuri mena patla soru',4,'M','2010-06-05 10:29:30','sanjoy',NULL,1,0.05),('C0746','Thokai joypuri mena patla maghari',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0747','Thokai joypuri mena patla maghari',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0748','',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0749','Thokai Jaypuri Patla Majhari',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0750','Thokai Jaypuri Patla Majhari',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0751','Thokai joypuri mena patla maghari',4,'N','2010-06-05 10:35:19','sanjoy',NULL,1,0.05),('C0753','Thokai joypuri mena patla maghari',4,'N','2010-06-05 10:36:09','sanjoy',NULL,1,0.05),('C0755','Thokai joypuri mena patla maghari',4,'N','2010-06-05 10:36:31','sanjoy',NULL,1,0.05),('C0756','Thokai Joypuri patla Chowra',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0757','Thokai Joypuri patla Chowra',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0758','Thokai Joypuri patla Chowra',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0759','Thokai Joypuri patla Chowra',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0760','Thokai joypuri patla chowrah',4,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0761','Thokai joypuri mena patla chowrah',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0763','Thokai joypuri mena patla chowrah',14,'N','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C0764','Thokai joypuri mena patla chowrah',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0765','Thokai joypuri mena patla chowrah',4,'O','2010-06-05 10:40:34','sanjoy',NULL,1,0.05),('C0766','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0767','Thokai Patla',14,'M','2011-01-05 12:51:23','b',NULL,1,0.05),('C0768','Thokai Patla',14,'L','2011-01-30 10:14:41','saheb',NULL,1,0.05),('C0769','Thokai Patla',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0770','Thokai Patla',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0771','Thokai dd patla soru',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0772','Thokai  patla soru',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0773','Thokai dd patla soru',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0774','Thokai dd patla soru',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0775','Thokai dd patla soru',14,'L','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C0777','Thokai dd  patla maghari',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0778','Thokai dd  patla maghari',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0779','Thokai dd  patla maghari',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0780','Thokai dd  patla maghari',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0781','Thokai dd  patla maghari',14,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0782','Thokai dd  patla majhari',14,'O','2011-01-18 12:08:39','sandip',NULL,1,0.05),('C0783','Thokai dd  patla maghari',12,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0784','Thokai dd  patla maghari',12,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0785','Thokai dd  patla maghari',12,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0786','Thokai dd mena patla maghari',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0787','MINA PATLA',14,'P',NULL,NULL,NULL,0,0),('C0788','Thokai dd mena patla maghari',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0789','Thokai dd mena patla maghari',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0790','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0791','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0792','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0793','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0794','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0795','Thokai dd  patla chowrah',14,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0797','Thokai D D Patla',14,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0799','Thokai dd mena patla chowrah',10,'Q','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C0800','Thokai dd mena patla chowrah',14,'O','2010-06-05 10:54:29','sanjoy',NULL,1,0.05),('C0805','churi',4,'M','2041-01-01 00:00:00','Raja',NULL,1,0.05),('C0806','flat panching patla soru',4,'M','2010-06-05 17:20:13','sanjoy',NULL,1,0.05),('C0807','flat panching patla soru',4,'M','2010-06-05 17:20:19','sanjoy',NULL,1,0.05),('C0808','flat panching patla soru',4,'M','2010-06-05 17:20:25','sanjoy',NULL,1,0.05),('C0809','flat panching patla soru',4,'M','2010-06-05 17:20:27','sanjoy',NULL,1,0.05),('C0810','flat panching patla soru',4,'M','2010-06-05 17:20:56','sanjoy',NULL,1,0.05),('C0811','flat panching decaration mena patla soru',4,'O','2010-06-05 17:23:16','sanjoy',NULL,1,0.05),('C0812','flat panching decaration mena patla soru',4,'O','2010-06-05 17:23:23','sanjoy',NULL,1,0.05),('C0813','flat panching decaration mena patla soru',4,'O','2010-06-05 17:23:26','sanjoy',NULL,1,0.05),('C0814','flat panching decaration mena patla soru',4,'O','2010-06-05 17:23:30','sanjoy',NULL,1,0.05),('C0815','flat panching decaration mena patla soru',4,'O','2010-06-05 17:23:34','sanjoy',NULL,1,0.05),('C0816','flat panching  patla maghari',4,'N','2010-06-05 17:25:00','sanjoy',NULL,1,0.05),('C0817','flat panching  patla maghari',4,'N','2010-06-05 17:26:11','sanjoy',NULL,1,0.05),('C0818','flat panching  patla maghari',4,'N','2010-06-05 17:26:33','sanjoy',NULL,1,0.05),('C0819','flat panching  patla maghari',4,'N','2010-06-05 17:26:55','sanjoy',NULL,1,0.05),('C0820','flat panching  patla maghari',4,'N','2010-06-05 17:27:06','sanjoy',NULL,1,0.05),('C0821','flat panching  patla maghari',4,'N','2010-06-05 17:27:29','sanjoy',NULL,1,0.05),('C0822','flat panching  patla maghari',4,'N','2010-06-05 17:27:38','sanjoy',NULL,1,0.05),('C0823','flat panching  patla maghari',4,'N','2010-06-05 17:27:44','sanjoy',NULL,1,0.05),('C0824','flat panching  patla maghari',4,'N','2010-06-05 17:27:51','sanjoy',NULL,1,0.05),('C0825','flat panching  patla maghari',4,'N','2010-06-05 17:27:57','sanjoy',NULL,1,0.05),('C0826','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:14','sanjoy',NULL,1,0.05),('C0827','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:29','sanjoy',NULL,1,0.05),('C0828','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:33','sanjoy',NULL,1,0.05),('C0829','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:38','sanjoy',NULL,1,0.05),('C0830','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:53','sanjoy',NULL,1,0.05),('C0831','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:30:58','sanjoy',NULL,1,0.05),('C0832','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:31:04','sanjoy',NULL,1,0.05),('C0833','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:31:13','sanjoy',NULL,1,0.05),('C0834','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:31:17','sanjoy',NULL,1,0.05),('C0835','flat panching decaration mena patla maghari',4,'P','2010-06-05 17:31:23','sanjoy',NULL,1,0.05),('C0836','flat panching patla chowrah',4,'O','2010-06-05 17:32:43','sanjoy',NULL,1,0.05),('C0837','flat panching patla chowrah',4,'O','2010-06-05 17:32:50','sanjoy',NULL,1,0.05),('C0838','flat panching patla chowrah',4,'O','2010-06-05 17:32:55','sanjoy',NULL,1,0.05),('C0839','flat panching patla chowrah',4,'O','2010-06-05 17:32:58','sanjoy',NULL,1,0.05),('C0840','flat panching patla chowrah',4,'O','2010-06-05 17:33:04','sanjoy',NULL,1,0.05),('C0841','flat panching patla chowrah',4,'O','2010-06-05 17:33:06','sanjoy',NULL,1,0.05),('C0842','flat panching patla chowrah',4,'O','2010-06-05 17:33:11','sanjoy',NULL,1,0.05),('C0843','flat panching patla chowrah',4,'O','2010-06-05 17:33:14','sanjoy',NULL,1,0.05),('C0844','flat panching patla chowrah',4,'O','2010-06-05 17:33:21','sanjoy',NULL,1,0.05),('C0845','flat panching patla chowrah',4,'O','2010-06-05 17:33:26','sanjoy',NULL,1,0.05),('C0846','flat panching decaration mena  patla chowrah',4,'Q','2010-06-05 17:34:33','sanjoy',NULL,1,0.05),('C0847','flat panching decaration mena  patla chowrah',4,'Q','2010-06-05 17:34:38','sanjoy',NULL,1,0.05),('C0848','flat panching decaration mena  patla chowrah',4,'Q','2010-06-05 17:34:41','sanjoy',NULL,1,0.05),('C0849','flat panching decaration mena  patla chowrah',4,'Q','2010-06-05 17:34:44','sanjoy',NULL,1,0.05),('C0850','flat panching decaration mena  patla chowrah',4,'Q','2010-06-05 17:34:47','sanjoy',NULL,1,0.05),('C0860','Thokai Patla',14,'W','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0861','Thokai bangal churi chowrah',4,'H','2010-06-04 16:36:57','sanjoy',NULL,1,0.05),('C0862','Thokai bangal churi chowrah',4,'H','2010-06-03 19:15:22','sanjoy',NULL,1,0.05),('C0863','Thokai bangal churi chowrah',4,'H','2010-06-03 19:15:37','sanjoy',NULL,1,0.05),('C0864','Thokai bangal churi chowrah',4,'H','2010-06-03 19:15:50','sanjoy',NULL,1,0.05),('C0865','Thokai bangal churi chowrah',4,'H','2010-06-03 19:16:09','sanjoy',NULL,1,0.05),('C0866','Thokai bangal churi chowrah',4,'H','2010-06-03 19:16:21','sanjoy',NULL,1,0.05),('C0867','Thokai bangal churi chowrah',4,'H','2010-06-03 19:16:42','sanjoy',NULL,1,0.05),('C0868','Thokai bangal churi chowrah',4,'H','2010-06-03 19:16:54','sanjoy',NULL,1,0.05),('C0869','Thokai bangal churi chowrah',4,'H','2010-06-03 19:28:48','sanjoy',NULL,1,0.05),('C0870','Thokai bangal churi chowrah',4,'I','2010-06-03 19:17:26','sanjoy',NULL,1,0.05),('C0871','Thokai bangal churi chowrah',4,'H','2010-06-03 19:17:41','sanjoy',NULL,1,0.05),('C0872','Thokai bangal churi chowrah',4,'H','2010-06-03 19:17:52','sanjoy',NULL,1,0.05),('C0873','Thokai bangal churi chowrah',4,'H','2010-06-03 19:18:04','sanjoy',NULL,1,0.05),('C0874','Thokai bangal churi chowrah',4,'H','2010-06-03 19:18:17','sanjoy',NULL,1,0.05),('C0875','Thokai bangal churi chowrah',4,'H','2010-06-03 19:18:31','sanjoy',NULL,1,0.05),('C0876','Thokai bangal churi chowrah',4,'H','2010-06-03 19:18:43','sanjoy',NULL,1,0.05),('C0877','Thokai bangal churi chowrah',4,'H','2010-06-04 16:38:01','sanjoy',NULL,1,0.05),('C0878','Thokai bangal churi chowrah',4,'H','2010-06-04 16:38:26','sanjoy',NULL,1,0.05),('C0879','Thokai bangal churi chowrah',4,'H','2010-06-04 16:38:39','sanjoy',NULL,1,0.05),('C0880','Thokai bangal churi chowrah',4,'H','2010-06-03 19:33:45','sanjoy',NULL,1,0.05),('C0881','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:43:29','sanjoy',NULL,1,0.05),('C0882','Thokai bangal mena churi chowrah',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0883','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:44:58','sanjoy',NULL,1,0.05),('C0884','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:45:20','sanjoy',NULL,1,0.05),('C0885','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:45:38','sanjoy',NULL,1,0.05),('C0886','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:45:52','sanjoy',NULL,1,0.05),('C0887','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:46:17','sanjoy',NULL,1,0.05),('C0888','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:46:39','sanjoy',NULL,1,0.05),('C0889','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:46:56','sanjoy',NULL,1,0.05),('C0890','Thokai bangal mena churi chowrah',4,'I','2010-06-04 16:47:12','sanjoy',NULL,1,0.05),('C0900','flat panching patla soru',4,'K','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0901','Thokai bangala bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0902','Thokai bangala bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0903','Thokai bangala bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0904','Thokai bangala bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0905','Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0906','Thokai bangala bowti mena soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0907','Thokai bangala bowti mena soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0908','Thokai bangala bowti mena soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0909','Thokai bangala bowti mena soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0910','Thokai bangala bowti mena soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0911','Thokai bangala bowti  maghri',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0912','Thokai bangala bowti  maghri',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0913','Thokai bangala bowti  maghri',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0914','Thokai bangala bowti  maghri',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0915','Thokai bangala bowti  maghri',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0917','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0918','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0920','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0921','Thokai bangala bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0922','Thokai bangala bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0923','Thokai bangala bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0924','Thokai bangala bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0925','Thokai bangala bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0926','Thokai bangala bowti mena chowrah',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0928','Thokai bangala bowti mena chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0929','Thokai bangala bowti mena chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0930','Thokai bangala bowti mena chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0931','Thokai Bouty',13,'M','2011-01-09 15:43:07','sandip',NULL,1,0.05),('C0932','Thokai Bouty',13,'M','2011-01-22 20:15:23','sanjoy',NULL,1,0.05),('C0933','Thokai Bouty',13,'N','2011-01-09 09:54:04','sandip',NULL,1,0.05),('C0934','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0935','Bouty',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0936','Thokai joypuri bowti soru',13,'L','2011-01-18 21:59:14','sandip',NULL,1,0.05),('C0937','Thokai joypuri bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0938','Thokai joypuri bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0939','Thokai joypuri bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0940','Thokai joypuri bowti soru',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0941','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0942','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0943','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0944','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0945','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0946','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0947','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0948','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0949','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0950','Thokai joypuri mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0951','Thokai joypuri mena bowti maghari',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0953','Thokai Joypuri Mina Bowti Majhari',13,'N','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C0955','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0956','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0957','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0958','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0959','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0960','Thokai joypuri bowti chowrah',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0961','Thokai joypuri mena bowti chowrah',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0962','Thokai joypuri mena bowti chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0963','Thokai joypuri mena bowti chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0964','Thokai joypuri mena bowti chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0965','Thokai joypuri mena bowti chowrah',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0966','Thokai Bouty',13,'M','2011-01-08 13:39:52','sandip',NULL,1,0.05),('C0967','Thokai Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C0968','Thokai Bouty',13,'M','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C0969','Thokai Bouty',13,'M','2011-01-09 10:43:07','sandip',NULL,1,0.05),('C0970','Bouty',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0971','Thokai dd bowti soru',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0972','Thokai dd bowti soru',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0973','Thokai dd bowti soru',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0974','Thokai dd bowti soru',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0975','Thokai dd bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0976','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0977','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0978','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0979','Thokai dd  mena bowti soru',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0980','Thokai dd  mena bowti soru',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0981','Thokai dd  mena bowti soru',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0982','Thokai dd  mena bowti soru',13,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0983','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0984','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0985','Thokai dd  mena bowti soru',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0986','Thokai dd Bowti Majhari',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0987','Thokai dd Bowti Majhari',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0988','Thokai dd Mena Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0989','Thokai dd Mena Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0990','Thokai dd Bowti Chowrah',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0991','Thokai dd Bowti Chowrah',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0992','Thokai dd Bowti Chowrah',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0993','Thokai dd Bowti Chowrah',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0994','Thokai dd Bowti Chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0995','Thokai dd Bowti Chowrah',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0996','Thokai dd  mena bowti chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0997','Thokai dd  mena bowti chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0998','Thokai dd  mena bowti chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C0999','Thokai dd  mena bowti chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1000','Thokai dd  mena bowti chowrah',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1001','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1002','thikai joypuri konkon soru',15,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1003','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1004','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1005','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1006','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1007','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1008','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1009','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1010','thikai joypuri konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1011','Thokai Joypuri Mena Konkon Soru',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1012','Thokai Joypuri Mena Konkon Soru',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1013','Thokai Joypuri Mena Konkon Soru',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1014','Thokai Joypuri Mena Konkon Soru',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1015','Thokai Joypuri Mena Konkon Soru',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1016','Thokai Joypuri  Konkon Majhari',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1017','Thokai Joypuri  Konkon Majhari',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1018','Thokai Joypuri  Konkon Majhari',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1019','Thokai Joypuri  Konkon Majhari',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1020','Thokai Joypuri  Konkon Majhari',15,'N','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1021','Thokai Joypuri Mina Konkon Majhari',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1022','Thokai Joypuri Mina Konkon Majhari',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1023','Thokai Joypuri Mina Konkon Majhari',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1024','Thokai Joypuri Mina Konkon Majhari',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1025','Thokai Konkon Majhari',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1026','Thokai Joypuri Konkon Chowrah',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1027','Thokai Joypuri Konkon Chowrah',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1028','Thokai Joypuri Konkon Chowrah',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1029','Thokai Joypuri Konkon Chowrah',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1030','Thokai Joypuri Konkon Chowrah',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1031','Thokai Joypuri Mina Konkon Chowrah',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1032','Thokai Joypuri Mina Konkon Chowrah',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1033','Thokai Joypuri Mina Konkon Chowrah',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1034','Thokai Joypuri Mina Konkon Chowrah',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1035','Thokai Joypuri Mina Konkon Chowrah',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1036','Thokai Kankan',15,'O','2011-01-11 19:48:32','sandip',NULL,1,0.05),('C1037','Thokai Kankan',15,'O','2011-01-09 10:44:07','sandip',NULL,1,0.05),('C1038','Kankan',15,'O','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1039','Thokai Kankan',15,'O','2011-01-11 19:48:19','sandip',NULL,1,0.05),('C1040','Kankan',15,'O','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C1041','Thokai dd Konkon Soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1042','Thokai dd Konkon Soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1043','Thokai dd Konkon Soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1044','Thokai dd Konkon Soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1045','Thokai dd Konkon Soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1046','Thokai dd Mina Konkon Soru',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1047','Thokai dd Mina Konkon Soru',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1048','Thokai dd Mina Konkon Soru',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1049','Thokai dd Mina Konkon Soru',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1050','Thokai dd Mina Konkon Soru',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1051','Thokai dd  Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1052','Thokai dd  Konkon Majhari',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1053','Thokai dd  Konkon Majhari',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1054','Thokai dd  Konkon Majhari',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1055','Thokai dd  Konkon Majhari',15,'P','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1056','Thokai dd Mina Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1057','Thokai dd Mina Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1058','Thokai dd Mina Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1059','Thokai dd Mina Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1060','Thokai dd Mina Konkon Majhari',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1061','Thokai Kankan',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1062','Thokai Kankan',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1063','Thikai DD Konkon Chwrah',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1064','Thokai Kankan',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1065','Thokai Kankan',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1066','Thokai Kankan',15,'R',NULL,NULL,NULL,0,0),('C1067','Thokai Joypuri Mina Konkon Chowrah',15,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1068','Thokai Joypuri Mina Konkon Chowrah',15,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1069','Thokai Joypuri Mina Konkon Chowrah',15,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1070','Thokai Joypuri Mina Konkon Chowrah',15,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1081','panching konkon soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1082','panching konkon soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1083','panching konkon soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1084','panching konkon soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1085','panching konkon soru',15,'O','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1086','Panching Decaration Mina Konkon Soru',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1087','Panching Decaration Mina Konkon Soru',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1088','Panching Decaration Mina Konkon Soru',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1089','Panching Decaration Mina Konkon Soru',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1090','Panching Decaration Mina Konkon Soru',15,'Q','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C1091','panching  konkon maghari',15,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1092','panching  konkon maghari',15,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1093','panching  konkon maghari',15,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1094','panching  konkon maghari',15,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1095','panching  konkon maghari',15,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1098','Panching Decaration Mina Konkon Maghari',15,'R','0000-00-00 00:00:00','avik',NULL,1,0.05),('C1101','Panching Konkon Chowrah',15,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1102','Panching Konkon Chowrah',15,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1103','Panching Konkon Chowrah',15,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1104','Panching Konkon Chowrah',15,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1105','Panching Konkon Chowrah',15,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1106','panching decaration mena konkon chowrah',15,'S','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1107','panching decaration mena konkon chowrah',15,'S','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1108','panching decaration mena konkon chowrah',15,'S','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1109','panching decaration mena konkon chowrah',15,'S','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1110','panching decaration mena konkon chowrah',15,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1116','panching bowti soru ',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1117','Panching Bowti Soru ',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1118','Panching Bowti Soru ',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1119','Panching Bowti Soru ',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1120','Panching Bowti Soru ',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1121','Panching Decaration Mina Bowti Soru ',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1122','Panching Decaration Mina Bowti Soru ',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1123','Panching Decaration Mina Bowti Soru ',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1124','Panching Decaration Mina Bowti Soru ',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1125','Panching Decaration Mina Bowti Soru ',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1126','Panching  Bowti Majhari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1127','Panching  Bowti Majhari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1128','Panching  Bowti Majhari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1129','Panching  Bowti Majhari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1130','Panching  Bowti Majhari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1131','Panching Bowti Mina Majhari',13,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1132','Panching Bowti Mina Majhari',13,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1133','Panching Bowti Mina Majhari',13,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1134','Panching Bowti Mina Majhari',13,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1135','Panching Bowti Mina Majhari',13,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1136','panching bowti chowrah',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1137','panching bowti chowrah',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1138','panching bowti chowrah',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1139','panching bowti chowrah',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1140','panching bowti chowrah',13,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1141','panching decaration mena  bowti chowrah',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1142','panching decaration mena  bowti chowrah',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1143','Panching Decaration Mena  Bowti Chowrah',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1144','Panching Decaration Mena  Bowti Chowrah',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1145','Panching Decaration Mena  Bowti Chowrah',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1151','Thokai dd Bijil Daya bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1152','Thokai dd Bijil Daya bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1153','Thokai dd Bijil Daya bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1154','Thokai dd Bijil Daya Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1155','Thokai dd Bijil Daya Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1156','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1157','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1158','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1159','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1160','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1161','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1162','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1163','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1164','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1165','Thokai dd Bijil Daya Mina Bowti Majhari',13,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1166','Thokai dd  Bijil Daya Mina Bowti Chowrah',13,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1167','Thokai dd  Bijil Daya Mina Bowti Chowrah',13,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1168','Thokai dd  Bijil Daya Mina Bowti Chowrah',13,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1169','Thokai dd  Bijil Daya Mina Bowti Chowrah',13,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1170','Thokai dd  Bijil Daya Mina Bowti Chowrah',13,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1171','Thokai Joypuri  Bijil Daya Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1172','Thokai Joypuri  Bijil Daya Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1173','Thokai Joypuri  Bijil Daya Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1174','Thokai Joypuri  Bijil Daya Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1175','Thokai Joypuri  Bijil Daya Bowti Majhari',13,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1176','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1177','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1178','Thikai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1179','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1180','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1181','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1182','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1183','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1184','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1185','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1186','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1187','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1188','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1189','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1190','Thokai Joypuri  Bijil Daya Mina Bowti Majhari',13,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1201','Thokai dd Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1202','Thokai dd Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1203','Thokai dd Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1204','Thokai dd Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1205','Thokai dd Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1206','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1207','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1208','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1209','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1210','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1211','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1212','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1213','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1214','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1215','Thokai dd Bijil Daya Mina Konkon Majhari',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1216','Thokai dd Bijil Daya Mina Konkon Chowrah',15,'T','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1217','Thokai dd Bijil Daya Mina Konkon Chowrah',15,'T','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1218','Thokai dd Bijil Daya Mina Konkon Chowrah',15,'T','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1219','Thokai dd Bijil Daya Mina Konkon Chowrah',15,'T','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1220','Thokai dd Bijil Daya Mina Konkon Chowrah',15,'T','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1221','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1222','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1223','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1224','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1225','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1226','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1227','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1228','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1229','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1230','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1231','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1232','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1233','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1234','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1235','Thokai Joypuri  Bijil Daya Konkon Majhari',15,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1236','Thokai Joypuri  Bijil Daya Mina Konkon Chowrah',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1237','Thokai Joypuri  Bijil Daya Mina Konkon Chowrah',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1238','Thokai Joypuri  Bijil Daya Mina Konkon Chowrah',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1239','Thokai Joypuri  Bijil Daya Mina Konkon Chowrah',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1240','Thokai Joypuri  Bijil Daya Mina Konkon Chowrah',15,'S','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1251','hand chala churi soru',4,'M','2010-06-06 10:37:44','sanjoy',NULL,1,0.05),('C1252','hand chala churi soru',4,'M','2010-06-06 10:37:51','sanjoy',NULL,1,0.05),('C1253','hand chala churi soru',4,'M','2010-06-06 10:37:54','sanjoy',NULL,1,0.05),('C1254','hand chala churi soru',4,'M','2010-06-06 10:38:02','sanjoy',NULL,1,0.05),('C1255','hand chala churi soru',4,'M','2010-06-06 10:38:06','sanjoy',NULL,1,0.05),('C1256','hand chala churi maghari',4,'N','2010-06-06 10:39:23','sanjoy',NULL,1,0.05),('C1257','hand chala churi maghari',4,'N','2010-06-06 10:39:33','sanjoy',NULL,1,0.05),('C1258','hand chala churi maghari',4,'N','2010-06-06 10:39:38','sanjoy',NULL,1,0.05),('C1259','hand chala churi maghari',4,'N','2010-06-06 10:39:40','sanjoy',NULL,1,0.05),('C1260','hand chala churi maghari',4,'N','2010-06-06 10:39:44','sanjoy',NULL,1,0.05),('C1261','hand chala churi chowrah',4,'O','2010-06-06 10:40:27','sanjoy',NULL,1,0.05),('C1262','hand chala churi chowrah',4,'O','2010-06-06 10:40:29','sanjoy',NULL,1,0.05),('C1263','hand chala churi chowrah',4,'O','2010-06-06 10:40:33','sanjoy',NULL,1,0.05),('C1264','hand chala churi chowrah',4,'O','2010-06-06 10:40:36','sanjoy',NULL,1,0.05),('C1265','hand chala churi chowrah',4,'O','2010-06-06 10:40:38','sanjoy',NULL,1,0.05),('C1266','hand chala mini bowti soru ',4,'N','2010-06-06 10:41:55','sanjoy',NULL,1,0.05),('C1267','hand chala mini bowti soru ',4,'N','2010-06-06 10:42:00','sanjoy',NULL,1,0.05),('C1268','hand chala mini bowti soru ',4,'N','2010-06-06 10:42:09','sanjoy',NULL,1,0.05),('C1269','hand chala mini bowti soru ',4,'N','2010-06-06 10:42:11','sanjoy',NULL,1,0.05),('C1270','hand chala mini bowti soru ',4,'N','2010-06-06 10:42:14','sanjoy',NULL,1,0.05),('C1271','hand chala mini bowti maghari',4,'O','2010-06-06 10:43:19','sanjoy',NULL,1,0.05),('C1272','hand chala mini bowti maghari',4,'O','2010-06-06 10:43:23','sanjoy',NULL,1,0.05),('C1273','hand chala mini bowti maghari',4,'O','2010-06-06 10:43:25','sanjoy',NULL,1,0.05),('C1274','hand chala mini bowti maghari',4,'O','2010-06-06 10:43:27','sanjoy',NULL,1,0.05),('C1275','hand chala mini bowti maghari',4,'O','2010-06-06 10:43:31','sanjoy',NULL,1,0.05),('C1276','hand chala mini bowti chowrah',4,'P','2010-06-06 10:44:10','sanjoy',NULL,1,0.05),('C1277','hand chala mini bowti chowrah',4,'P','2010-06-06 10:44:15','sanjoy',NULL,1,0.05),('C1278','hand chala mini bowti chowrah',4,'P','2010-06-06 10:44:27','sanjoy',NULL,1,0.05),('C1279','hand chala mini bowti chowrah',4,'P','2010-06-06 10:44:32','sanjoy',NULL,1,0.05),('C1280','hand chala mini bowti chowrah',4,'P','2010-06-06 10:44:36','sanjoy',NULL,1,0.05),('C1281','hand chala decaration churi',4,'P','2010-06-06 10:45:23','sanjoy',NULL,1,0.05),('C1282','hand chala decaration churi',4,'P','2010-06-06 10:45:26','sanjoy',NULL,1,0.05),('C1283','hand chala decaration churi',4,'P','2010-06-06 10:45:28','sanjoy',NULL,1,0.05),('C1284','hand chala decaration churi',4,'P','2010-06-06 10:45:30','sanjoy',NULL,1,0.05),('C1285','hand chala decaration churi',4,'P','2010-06-06 10:45:33','sanjoy',NULL,1,0.05),('C1286','hand chala decaration mini bowti',4,'Q','2010-06-06 10:46:33','sanjoy',NULL,1,0.05),('C1287','hand chala decaration mini bowti',4,'Q','2010-06-06 10:46:38','sanjoy',NULL,1,0.05),('C1288','hand chala decaration mini bowti',4,'Q','2010-06-06 10:46:40','sanjoy',NULL,1,0.05),('C1289','hand chala decaration mini bowti',4,'Q','2010-06-06 10:46:42','sanjoy',NULL,1,0.05),('C1290','hand chala decaration mini bowti',4,'Q','2010-06-06 10:46:44','sanjoy',NULL,1,0.05),('C1301','taser khal churi soru',4,'I','2010-06-06 10:49:11','sanjoy',NULL,1,0.05),('C1302','taser khal churi soru',4,'I','2010-06-06 10:49:13','sanjoy',NULL,1,0.05),('C1303','taser khal churi soru',4,'I','2010-06-06 10:49:15','sanjoy',NULL,1,0.05),('C1304','taser khal churi soru',4,'I','2010-06-06 10:49:17','sanjoy',NULL,1,0.05),('C1305','taser khal churi soru',4,'I','2010-06-06 10:49:19','sanjoy',NULL,1,0.05),('C1306','taser khal mena churi soru',4,'J','2010-06-06 10:50:01','sanjoy',NULL,1,0.05),('C1307','taser khal mena churi soru',4,'J','2010-06-06 10:50:05','sanjoy',NULL,1,0.05),('C1308','taser khal mena churi soru',4,'J','2010-06-06 10:50:06','sanjoy',NULL,1,0.05),('C1309','taser khal mena churi soru',4,'J','2010-06-06 10:50:08','sanjoy',NULL,1,0.05),('C1310','taser khal mena churi soru',4,'J','2010-06-06 10:50:10','sanjoy',NULL,1,0.05),('C1311','taser khal panching churi soru',4,'J','2010-06-06 10:51:29','sanjoy',NULL,1,0.05),('C1312','taser khal panching churi soru',4,'J','2010-06-06 10:51:33','sanjoy',NULL,1,0.05),('C1313','taser khal panching churi soru',4,'J','2010-06-06 10:51:34','sanjoy',NULL,1,0.05),('C1314','taser khal panching churi soru',4,'J','2010-06-06 10:51:36','sanjoy',NULL,1,0.05),('C1315','taser khal panching churi soru',4,'J','2010-06-06 10:51:38','sanjoy',NULL,1,0.05),('C1316','taser khal churi maghari',4,'J','2010-06-06 10:53:22','sanjoy',NULL,1,0.05),('C1317','taser khal churi maghari',4,'J','2010-06-06 10:53:24','sanjoy',NULL,1,0.05),('C1318','taser khal churi maghari',4,'J','2010-06-06 10:53:25','sanjoy',NULL,1,0.05),('C1319','taser khal churi maghari',4,'J','2010-06-06 10:53:27','sanjoy',NULL,1,0.05),('C1320','Tesire Khal Churi Majhari',4,'L','2010-06-06 10:53:29','sanjoy',NULL,1,0.05),('C1321','taser khal mena churi maghari',4,'K','2011-01-31 18:17:51','saheb',NULL,1,0.05),('C1322','taser khal mena churi maghari',4,'K','2011-01-31 18:18:07','saheb',NULL,1,0.05),('C1323','taser khal mena churi maghari',4,'K','2011-01-31 18:18:24','saheb',NULL,1,0.05),('C1324','khal bauty',4,'K','2011-01-31 18:19:26','saheb',NULL,1,0.05),('C1325','taser khal mena churi maghari',4,'K','2011-01-31 18:19:37','saheb',NULL,1,0.05),('C1326','taser khal panching churi maghari',4,'K','2011-01-31 18:19:51','saheb',NULL,1,0.05),('C1327','taser khal panching churi maghari',4,'K','2011-01-31 18:20:12','saheb',NULL,1,0.05),('C1328','taser khal panching churi maghari',4,'K','2011-01-31 18:20:24','saheb',NULL,1,0.05),('C1329','taser khal panching churi maghari',4,'K','2011-01-31 18:20:41','saheb',NULL,1,0.05),('C1330','taser khal panching churi maghari',4,'K','2011-01-31 18:20:53','saheb',NULL,1,0.05),('C1331','taser khal churi chowrah',4,'K','2010-06-06 10:58:35','sanjoy',NULL,1,0.05),('C1332','taser khal churi chowrah',4,'K','2011-01-31 18:21:10','saheb',NULL,1,0.05),('C1333','taser khal churi chowrah',4,'K','2011-01-31 18:21:29','saheb',NULL,1,0.05),('C1334','taser khal churi chowrah',4,'K','2011-01-31 18:21:43','saheb',NULL,1,0.05),('C1335','taser khal churi chowrah',4,'K','2011-01-31 18:23:32','saheb',NULL,1,0.05),('C1336','taser khal mena  churi chowrah',4,'L','2010-06-06 11:00:22','sanjoy',NULL,1,0.05),('C1337','taser khal mena  churi chowrah',4,'L','2010-06-06 11:00:28','sanjoy',NULL,1,0.05),('C1338','taser khal mena  churi chowrah',4,'L','2010-06-06 11:00:30','sanjoy',NULL,1,0.05),('C1339','taser khal mena  churi chowrah',4,'L','2010-06-06 11:00:31','sanjoy',NULL,1,0.05),('C1340','taser khal mena  churi chowrah',4,'L','2010-06-06 11:00:33','sanjoy',NULL,1,0.05),('C1341','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:24','sanjoy',NULL,1,0.05),('C1342','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:42','sanjoy',NULL,1,0.05),('C1343','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:45','sanjoy',NULL,1,0.05),('C1344','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:48','sanjoy',NULL,1,0.05),('C1345','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:51','sanjoy',NULL,1,0.05),('C1346','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:54','sanjoy',NULL,1,0.05),('C1347','taser khal panching churi chowrah',4,'L','2010-06-06 11:01:56','sanjoy',NULL,1,0.05),('C1348','taser khal panching churi chowrah',4,'L','2010-06-06 11:02:01','sanjoy',NULL,1,0.05),('C1349','taser khal panching churi chowrah',4,'L','2010-06-06 11:02:05','sanjoy',NULL,1,0.05),('C1350','taser khal panching churi chowrah',4,'L','2010-06-06 11:02:08','sanjoy',NULL,1,0.05),('C1356','half round khal churi soru',4,'I','2010-06-06 11:04:17','sanjoy',NULL,1,0.05),('C1357','half round khal churi soru',4,'I','2010-06-06 11:04:33','sanjoy',NULL,1,0.05),('C1358','half round khal churi soru',4,'I','2010-06-06 11:04:36','sanjoy',NULL,1,0.05),('C1359','half round khal churi soru',4,'I','2010-06-06 11:04:39','sanjoy',NULL,1,0.05),('C1360','half round khal churi soru',4,'I','2010-06-06 11:04:41','sanjoy',NULL,1,0.05),('C1361','half round khal mena churi soru',4,'J','2010-06-06 11:05:28','sanjoy',NULL,1,0.05),('C1362','half round khal mena churi soru',4,'J','2010-06-06 11:05:33','sanjoy',NULL,1,0.05),('C1363','half round khal mena churi soru',4,'J','2010-06-06 11:05:37','sanjoy',NULL,1,0.05),('C1364','half round khal mena churi soru',4,'J','2010-06-06 11:05:48','sanjoy',NULL,1,0.05),('C1365','half round khal mena churi soru',4,'J','2010-06-06 11:05:51','sanjoy',NULL,1,0.05),('C1366','half round khal panching mena churi soru',4,'J','2010-06-06 11:06:37','sanjoy',NULL,1,0.05),('C1367','half round khal panching mena churi soru',4,'J','2010-06-06 11:06:39','sanjoy',NULL,1,0.05),('C1368','half round khal panching mena churi soru',4,'J','2010-06-06 11:06:41','sanjoy',NULL,1,0.05),('C1369','half round khal panching mena churi soru',4,'J','2010-06-06 11:06:43','sanjoy',NULL,1,0.05),('C1370','half round khal panching mena churi soru',4,'J','2010-06-06 11:06:45','sanjoy',NULL,1,0.05),('C1371','half round khal churi maghari ',4,'J','2010-06-06 11:07:23','sanjoy',NULL,1,0.05),('C1372','half round khal churi maghari ',4,'K','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1373','half round khal churi maghari ',4,'K','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1374','half round khal churi maghari ',4,'J','2010-06-06 11:07:30','sanjoy',NULL,1,0.05),('C1375','half round khal churi maghari ',4,'J','2010-06-06 11:07:32','sanjoy',NULL,1,0.05),('C1376','half round khal mena churi maghari ',4,'K','2010-06-06 11:08:29','sanjoy',NULL,1,0.05),('C1377','half round khal mena churi maghari ',4,'K','2010-06-06 11:08:34','sanjoy',NULL,1,0.05),('C1378','half round khal mena churi maghari ',4,'K','2010-06-06 11:08:36','sanjoy',NULL,1,0.05),('C1379','half round khal mena churi maghari ',4,'K','2010-06-06 11:08:38','sanjoy',NULL,1,0.05),('C1380','half round khal mena churi maghari ',4,'K','2010-06-06 11:08:39','sanjoy',NULL,1,0.05),('C1381','half round khal panching mena churi maghari ',4,'K','2010-06-06 11:09:13','sanjoy',NULL,1,0.05),('C1382','half round khal panching mena churi maghari ',4,'K','2010-06-06 11:09:16','sanjoy',NULL,1,0.05),('C1383','half round khal panching mena churi maghari ',4,'K','2010-06-06 11:09:18','sanjoy',NULL,1,0.05),('C1384','half round khal panching mena churi maghari ',4,'K','2010-06-06 11:09:20','sanjoy',NULL,1,0.05),('C1385','half round khal panching mena churi maghari ',4,'K','2010-06-06 11:09:51','sanjoy',NULL,1,0.05),('C1386','half round khal churi chowrah',4,'K','2010-06-06 11:17:10','sanjoy',NULL,1,0.05),('C1387','half round khal churi chowrah',4,'K','2010-06-06 11:17:13','sanjoy',NULL,1,0.05),('C1388','half round khal churi chowrah',4,'K','2010-06-06 11:17:15','sanjoy',NULL,1,0.05),('C1389','half round khal churi chowrah',4,'K','2010-06-06 11:17:17','sanjoy',NULL,1,0.05),('C1390','half round khal churi chowrah',4,'K','2010-06-06 11:17:19','sanjoy',NULL,1,0.05),('C1391','half round khal mean churi chowrah',4,'L','2010-06-06 11:17:56','sanjoy',NULL,1,0.05),('C1392','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:01','sanjoy',NULL,1,0.05),('C1393','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:02','sanjoy',NULL,1,0.05),('C1394','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:04','sanjoy',NULL,1,0.05),('C1395','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:06','sanjoy',NULL,1,0.05),('C1396','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:08','sanjoy',NULL,1,0.05),('C1397','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:09','sanjoy',NULL,1,0.05),('C1398','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:11','sanjoy',NULL,1,0.05),('C1399','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:13','sanjoy',NULL,1,0.05),('C1400','half round khal mean churi chowrah',4,'L','2010-06-06 11:18:18','sanjoy',NULL,1,0.05),('C1401','half round khal panching mean churi chowrah',4,'L','2010-06-06 11:18:53','sanjoy',NULL,1,0.05),('C1402','half round khal panching mean churi chowrah',4,'L','2010-06-06 11:18:58','sanjoy',NULL,1,0.05),('C1403','half round khal panching mean churi chowrah',4,'G','2010-06-06 11:19:04','sanjoy',NULL,1,0.05),('C1404','half round khal panching mean churi chowrah',4,'H','2010-06-06 11:19:05','sanjoy',NULL,1,0.05),('C1405','THOKAI CHURI',4,'H','2010-06-06 11:19:08','sanjoy',NULL,1,0.05),('C1406','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1407','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1408','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1409','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1410','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1411','3pol  khal churi soru',4,'I','2010-06-06 11:22:08','sanjoy',NULL,1,0.05),('C1412','Thokai Churi',4,'G','2010-06-06 11:22:11','sanjoy',NULL,1,0.05),('C1413','Thokai Churi',4,'G','2010-06-06 11:22:13','sanjoy',NULL,1,0.05),('C1414','THOKAI CHURI',4,'G','2010-06-06 11:22:15','sanjoy',NULL,1,0.05),('C1415','Thokai Churi',4,'G','2010-06-06 11:22:17','sanjoy',NULL,1,0.05),('C1416','Thokai Churi',4,'G','2010-06-06 11:23:30','sanjoy',NULL,1,0.05),('C1417','Thokai Churi',4,'G','2010-06-06 11:23:34','sanjoy',NULL,1,0.05),('C1418','Thokai Churi',4,'G','2010-06-06 11:23:36','sanjoy',NULL,1,0.05),('C1419','CHURI',4,'G','2010-06-06 11:23:38','sanjoy',NULL,1,0.05),('C1420','3pol  khal mena churi soru',4,'J','2010-06-06 11:23:40','sanjoy',NULL,1,0.05),('C1421','3pol  khal panching churi soru',4,'H','2010-06-06 11:24:43','sanjoy',NULL,1,0.05),('C1422','CHURI',4,'G','2010-06-06 11:24:50','sanjoy',NULL,1,0.05),('C1423','CHURI',4,'G','2010-06-06 11:24:52','sanjoy',NULL,1,0.05),('C1424','CHURI',4,'G','2010-06-06 11:24:54','sanjoy',NULL,1,0.05),('C1425','3pol  khal panching churi soru',4,'G','2010-06-06 11:24:56','sanjoy',NULL,1,0.05),('C1426','CHURI',4,'G','2010-06-06 11:27:16','sanjoy',NULL,1,0.05),('C1427','CHURI',4,'G','2010-06-06 11:27:21','sanjoy',NULL,1,0.05),('C1428','CHURI',4,'G','2010-06-06 11:27:26','sanjoy',NULL,1,0.05),('C1429','CHURI',4,'G','2010-06-06 11:27:31','sanjoy',NULL,1,0.05),('C1430','CHURI',4,'G','2010-06-06 11:28:59','sanjoy',NULL,1,0.05),('C1431','churi',4,'G','2010-06-06 11:29:06','sanjoy',NULL,1,0.05),('C1432','churi',4,'G','2010-06-06 11:29:09','sanjoy',NULL,1,0.05),('C1433','churi',4,'G','2010-06-06 11:29:13','sanjoy',NULL,1,0.05),('C1434','churi',4,'G','2010-06-06 11:29:17','sanjoy',NULL,1,0.05),('C1435','churi',4,'G','2010-06-06 11:29:22','sanjoy',NULL,1,0.05),('C1436','churi',4,'G','2010-06-06 11:30:22','sanjoy',NULL,1,0.05),('C1437','3pol  khal panching churi maghari',4,'G','2010-06-06 11:30:25','sanjoy',NULL,1,0.05),('C1438','3pol  khal panching churi maghari',4,'G','2010-06-06 11:30:27','sanjoy',NULL,1,0.05),('C1439','3pol  khal panching churi maghari',4,'H','2010-06-06 11:30:29','sanjoy',NULL,1,0.05),('C1440','3pol  khal panching churi maghari',4,'G','2010-06-06 11:30:30','sanjoy',NULL,1,0.05),('C1441','3pol  khal churi chowrah ',4,'K','2010-06-06 11:31:57','sanjoy',NULL,1,0.05),('C1442','3pol  khal churi chowrah ',4,'K','2010-06-06 11:31:59','sanjoy',NULL,1,0.05),('C1443','3pol  khal churi chowrah ',4,'G','2010-06-06 11:32:01','sanjoy',NULL,1,0.05),('C1444','THOKAI CHURI ',4,'G','2010-06-06 11:32:04','sanjoy',NULL,1,0.05),('C1445','3pol  khal churi chowrah ',4,'G','2010-06-06 11:32:07','sanjoy',NULL,1,0.05),('C1446','CHURI ',4,'G','2010-06-06 11:32:08','sanjoy',NULL,1,0.05),('C1447','3pol  khal churi chowrah ',4,'H','2010-06-06 11:32:10','sanjoy',NULL,1,0.05),('C1448','3pol  khal churi chowrah ',4,'G','2010-06-06 11:32:12','sanjoy',NULL,1,0.05),('C1449','3pol  khal churi chowrah ',4,'G','2010-06-06 11:32:14','sanjoy',NULL,1,0.05),('C1450','3pol  khal churi chowrah ',4,'G','2010-06-06 11:32:16','sanjoy',NULL,1,0.05),('C1451','3pol  khal mena churi chowrah ',4,'H','2010-06-06 11:33:31','sanjoy',NULL,1,0.05),('C1452','3pol  khal mena churi chowrah ',4,'G','2010-06-06 11:33:34','sanjoy',NULL,1,0.05),('C1453','3pol  khal mena churi chowrah ',4,'G','2010-06-06 11:33:36','sanjoy',NULL,1,0.05),('C1454','3pol  khal mena churi chowrah ',4,'L','2010-06-06 11:33:38','sanjoy',NULL,1,0.05),('C1455','3pol  khal mena churi chowrah ',4,'L','2010-06-06 11:33:40','sanjoy',NULL,1,0.05),('C1456','3pol  khal panching churi chowrah ',4,'L','2010-06-06 11:35:02','sanjoy',NULL,1,0.05),('C1457','3pol  khal panching churi chowrah ',4,'L','2010-06-06 11:35:05','sanjoy',NULL,1,0.05),('C1458','3pol  khal panching churi chowrah ',4,'L','2010-06-06 11:35:07','sanjoy',NULL,1,0.05),('C1459','3pol  khal panching churi chowrah ',4,'L','2010-06-06 11:35:11','sanjoy',NULL,1,0.05),('C1460','3pol  khal panching churi chowrah ',4,'L','2010-06-06 11:35:16','sanjoy',NULL,1,0.05),('C1466','chowrah khal bowti 15mm',4,'O','2010-06-05 17:45:50','sanjoy',NULL,1,0.05),('C1467','chowrah khal bowti 15mm',4,'O','2010-06-05 17:45:56','sanjoy',NULL,1,0.05),('C1468','chowrah khal mena  bowti 15mm',4,'P','2010-06-05 17:46:58','sanjoy',NULL,1,0.05),('C1469','chowrah khal mena  bowti 15mm',4,'P','2010-06-05 17:47:06','sanjoy',NULL,1,0.05),('C1470','chowrah khal panching mena bowti 15mm',4,'Q','2010-06-05 17:47:57','sanjoy',NULL,1,0.05),('C1471','chowrah khal panching mena bowti 15mm',4,'Q','2010-06-05 17:48:02','sanjoy',NULL,1,0.05),('C1472','chowrah khal decaration bowti 15mm',4,'R','2010-06-05 17:49:10','sanjoy',NULL,1,0.05),('C1473','chowrah khal decaration bowti 15mm',4,'R','2010-06-05 17:49:15','sanjoy',NULL,1,0.05),('C1474','chowrah khal decaration mena bowti 15mm',4,'S','2010-06-05 17:50:57','sanjoy',NULL,1,0.05),('C1475','chowrah khal decaration mena bowti 15mm',4,'S','2010-06-05 17:50:49','sanjoy',NULL,1,0.05),('C1476','chowrah khal bowti 20mm',4,'P','2010-06-05 17:51:51','sanjoy',NULL,1,0.05),('C1477','chowrah khal bowti 20mm',4,'P','2010-06-05 17:52:02','sanjoy',NULL,1,0.05),('C1478','chowrah khal mena bowti 20mm',4,'Q','2010-06-05 17:52:40','sanjoy',NULL,1,0.05),('C1479','chowrah khal mena bowti 20mm',4,'Q','2010-06-05 17:52:44','sanjoy',NULL,1,0.05),('C1480','chowrah khal panching mena bowti 20mm',4,'R','2010-06-05 17:53:26','sanjoy',NULL,1,0.05),('C1481','chowrah khal panching mena bowti 20mm',4,'R','2010-06-05 17:53:34','sanjoy',NULL,1,0.05),('C1482','chowrah khal decaration bowti 20mm',4,'S','2010-06-05 17:54:24','sanjoy',NULL,1,0.05),('C1483','chowrah khal decaration bowti 20mm',4,'S','2010-06-05 17:54:28','sanjoy',NULL,1,0.05),('C1484','chowrah khal decaration mena bowti 20mm',4,'T','2010-06-05 17:55:06','sanjoy',NULL,1,0.05),('C1485','chowrah khal decaration mena bowti 20mm',4,'T','2010-06-05 17:55:12','sanjoy',NULL,1,0.05),('C1486','chowrah khal bowti 25mm',4,'Q','2010-06-05 17:55:50','sanjoy',NULL,1,0.05),('C1487','chowrah khal bowti 25mm',4,'Q','2010-06-05 17:55:55','sanjoy',NULL,1,0.05),('C1488','chowrah khal mena bowti 25mm',4,'R','2010-06-05 17:56:26','sanjoy',NULL,1,0.05),('C1489','chowrah khal mena bowti 25mm',4,'R','2010-06-05 17:56:30','sanjoy',NULL,1,0.05),('C1490','chowrah khal panching mena bowti 25mm',4,'S','2010-06-05 17:57:57','sanjoy',NULL,1,0.05),('C1491','chowrah khal panching mena bowti 25mm',4,'S','2010-06-05 17:58:02','sanjoy',NULL,1,0.05),('C1492','chowrah khal decaration bowti 25mm',4,'T','2010-06-05 17:58:45','sanjoy',NULL,1,0.05),('C1493','chowrah khal decaration bowti 25mm',4,'T','2010-06-05 17:58:52','sanjoy',NULL,1,0.05),('C1494','chowrah khal decaration mena bowti 25mm',4,'U','2010-06-05 18:02:16','sanjoy',NULL,1,0.05),('C1495','chowrah khal decaration mena bowti 25mm',4,'U','2010-06-05 18:02:23','sanjoy',NULL,1,0.05),('C1501','1 tarar baki churi',4,'H','2010-06-06 10:00:31','sanjoy',NULL,1,0.05),('C1502','1 tarar baki churi',4,'G','2010-06-06 10:00:43','sanjoy',NULL,1,0.05),('C1503','1 tarar baki churi',4,'H','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1504','1 tarar baki churi',4,'H','2010-06-06 10:01:10','sanjoy',NULL,1,0.05),('C1505','1 tarar baki churi',4,'F','2010-06-06 10:01:21','sanjoy',NULL,1,0.05),('C1506','1 tarar panching baki churi',4,'H','2010-06-06 10:01:35','sanjoy',NULL,1,0.05),('C1507','1 tarar panching baki churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1508','1 tarar panching baki churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1509','1 tarar panching baki churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1510','1 tarar panching baki churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1511','1 tarar mena baki churi',4,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C1512','1 tarer  beki  churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C1513','1 tarar mena baki churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C1514','1 tarar mena baki churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C1515','1 tarar mena baki churi',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C1516','2 tarar baki churi',4,'N','2010-06-06 10:05:17','sanjoy',NULL,1,0.05),('C1517','2 tarar baki churi',4,'N','2010-06-06 10:05:22','sanjoy',NULL,1,0.05),('C1518','2 tarar baki churi',4,'N','2010-06-06 10:05:25','sanjoy',NULL,1,0.05),('C1519','2 tarar baki churi',4,'N','2010-06-06 10:05:52','sanjoy',NULL,1,0.05),('C1520','2 tarar baki churi',4,'N','2010-06-06 10:05:55','sanjoy',NULL,1,0.05),('C1521','2 tarar baki churi',4,'N','2010-06-06 10:05:57','sanjoy',NULL,1,0.05),('C1522','2 tarar baki churi',4,'N','2010-06-06 10:06:00','sanjoy',NULL,1,0.05),('C1523','2 tarar baki churi',4,'N','2010-06-06 10:06:03','sanjoy',NULL,1,0.05),('C1524','2 tarar baki churi',4,'N','2010-06-06 10:06:06','sanjoy',NULL,1,0.05),('C1525','2 tarar baki churi',4,'N','2010-06-06 10:06:15','sanjoy',NULL,1,0.05),('C1526','2 tarar baki churi',4,'N','2010-06-06 10:06:17','sanjoy',NULL,1,0.05),('C1527','2 tarar baki churi',4,'N','2010-06-06 10:06:21','sanjoy',NULL,1,0.05),('C1528','2 tarar baki churi',4,'N','2010-06-06 10:06:24','sanjoy',NULL,1,0.05),('C1529','2 tarar baki churi',4,'N','2010-06-06 10:06:27','sanjoy',NULL,1,0.05),('C1530','2 tarar baki churi',4,'N','2010-06-06 10:06:30','sanjoy',NULL,1,0.05),('C1531','2 tarar baki churi',4,'N','2010-06-06 10:06:33','sanjoy',NULL,1,0.05),('C1532','2 tarar baki churi',4,'N','2010-06-06 10:06:36','sanjoy',NULL,1,0.05),('C1533','2 tarar baki churi',4,'N','2010-06-06 10:06:40','sanjoy',NULL,1,0.05),('C1534','2 tarar baki churi',4,'N','2010-06-06 10:06:47','sanjoy',NULL,1,0.05),('C1535','2 tarar baki churi',4,'N','2010-06-06 10:06:52','sanjoy',NULL,1,0.05),('C1536','2 tarar panching baki churi',4,'O','2010-06-06 10:07:59','sanjoy',NULL,1,0.05),('C1537','2 tarar panching baki churi',4,'O','2010-06-06 10:08:04','sanjoy',NULL,1,0.05),('C1538','2 tarar panching baki churi',4,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1539','2 tarar panching baki churi',4,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1540','2 tarar panching baki churi',4,'M','2010-06-06 10:08:15','sanjoy',NULL,1,0.05),('C1541','2 tarar panching baki churi',4,'M','2010-06-06 10:08:29','sanjoy',NULL,1,0.05),('C1542','2 tarar panching baki churi',4,'I','2010-06-06 10:08:32','sanjoy',NULL,1,0.05),('C1543','2 tarar panching baki churi',4,'G','2010-06-06 10:08:34','sanjoy',NULL,1,0.05),('C1544','2 tarar panching baki churi',4,'N','2010-06-06 10:08:40','sanjoy',NULL,1,0.05),('C1545','2 tarar panching baki churi',4,'N','2010-06-06 10:08:43','sanjoy',NULL,1,0.05),('C1546','2 tarar mena baki churi',4,'R','2010-06-06 10:10:29','sanjoy',NULL,1,0.05),('C1547','2 tarar mena baki churi',4,'U','2010-06-06 10:10:55','sanjoy',NULL,1,0.05),('C1548','2 tarar mena baki churi',4,'U','2010-06-06 10:10:57','sanjoy',NULL,1,0.05),('C1549','2 tarar mena baki churi',4,'U','2010-06-06 10:11:00','sanjoy',NULL,1,0.05),('C1550','2 tarar mena baki churi',4,'U','2010-06-06 10:11:02','sanjoy',NULL,1,0.05),('C1551','2 tarar mena baki churi',4,'P','2010-06-06 10:11:04','sanjoy',NULL,1,0.05),('C1552','2 tarar mena baki churi',4,'P','2010-06-06 10:11:07','sanjoy',NULL,1,0.05),('C1553','2 tarar mena baki churi',4,'N','2010-06-06 10:11:09','sanjoy',NULL,1,0.05),('C1554','2 tarar mena baki churi',4,'P','2010-06-06 10:11:14','sanjoy',NULL,1,0.05),('C1555','2 tarar mena baki churi',4,'P','2010-06-06 10:11:16','sanjoy',NULL,1,0.05),('C1556','3 tarar baki churi',4,'P','2010-06-06 10:11:59','sanjoy',NULL,1,0.05),('C1557','3 tarar baki churi',4,'P','2010-06-06 10:12:12','sanjoy',NULL,1,0.05),('C1558','3 tarar baki churi',4,'P','2010-06-06 10:12:14','sanjoy',NULL,1,0.05),('C1559','3 tarar baki churi',4,'P','2010-06-06 10:12:16','sanjoy',NULL,1,0.05),('C1560','3 tarar baki churi',4,'P','2010-06-06 10:12:18','sanjoy',NULL,1,0.05),('C1561','3 tarar baki churi',4,'P','2010-06-06 10:12:19','sanjoy',NULL,1,0.05),('C1562','3 tarar baki churi',4,'P','2010-06-06 10:12:21','sanjoy',NULL,1,0.05),('C1563','3 tarar baki churi',4,'P','2010-06-06 10:12:24','sanjoy',NULL,1,0.05),('C1564','3 tarar baki churi',4,'P','2010-06-06 10:12:37','sanjoy',NULL,1,0.05),('C1565','3 tarar baki churi',4,'P','2010-06-06 10:12:40','sanjoy',NULL,1,0.05),('C1566','3 tarar panching  baki churi',4,'Q','2010-06-06 10:13:51','sanjoy',NULL,1,0.05),('C1567','3 tarar panching  baki churi',4,'Q','2010-06-06 10:13:55','sanjoy',NULL,1,0.05),('C1568','3 tarar panching  baki churi',4,'Q','2010-06-06 10:13:57','sanjoy',NULL,1,0.05),('C1569','2 tarar panching  baki churi',4,'T','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1570','3 tarar panching  baki churi',4,'R','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1571','3 tarar mena baki churi',4,'R','2010-06-06 10:14:48','sanjoy',NULL,1,0.05),('C1572','3 tarar mena baki churi',4,'R','2010-06-06 10:14:53','sanjoy',NULL,1,0.05),('C1573','3 tarar mena baki churi',4,'R','2010-06-06 10:14:55','sanjoy',NULL,1,0.05),('C1574','3 tarar mena baki churi',4,'R','2010-06-06 10:14:57','sanjoy',NULL,1,0.05),('C1575','3 tarar mena baki churi',4,'P','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1576','4 tarar baki churi',4,'Q','2010-06-06 10:16:19','sanjoy',NULL,1,0.05),('C1577','4 tarar baki churi',4,'Q','2010-06-06 10:16:23','sanjoy',NULL,1,0.05),('C1578','4 tarar baki churi',4,'Q','2010-06-06 10:16:25','sanjoy',NULL,1,0.05),('C1579','4 tarar baki churi',4,'Q','2010-06-06 10:16:27','sanjoy',NULL,1,0.05),('C1580','4 tarar baki churi',4,'Q','2010-06-06 10:16:29','sanjoy',NULL,1,0.05),('C1581','4 tarar panching baki churi',4,'R','2010-06-06 10:17:40','sanjoy',NULL,1,0.05),('C1582','4 tarar panching baki churi',4,'R','2010-06-06 10:17:47','sanjoy',NULL,1,0.05),('C1583','4 tarar panching baki churi',4,'R','2010-06-06 10:17:49','sanjoy',NULL,1,0.05),('C1584','4 tarar panching baki churi',4,'R','2010-06-06 10:17:51','sanjoy',NULL,1,0.05),('C1585','4 tarar panching baki churi',4,'R','2010-06-06 10:17:53','sanjoy',NULL,1,0.05),('C1586','4 tarar mena baki churi',4,'S','2010-06-06 10:18:33','sanjoy',NULL,1,0.05),('C1587','4 tarar baki churi',4,'S','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1588','4 tarar mena baki churi',4,'S','2010-06-06 10:18:39','sanjoy',NULL,1,0.05),('C1589','2 tarar  baki churi',4,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1590','4 tarar mena baki churi',4,'M','2010-06-06 10:18:45','sanjoy',NULL,1,0.05),('C1591','Bekey Churi',4,'M','2011-01-07 19:07:30','sandip',NULL,1,0.05),('C1592','Bekey Churi',4,'M','2011-01-23 20:23:11','sandip',NULL,1,0.05),('C1593','Bekey Churi',4,'O','2011-01-07 19:02:35','sandip',NULL,1,0.05),('C1594','Bekey churi',4,'M','2011-02-07 10:08:37','avik',NULL,1,0.05),('C1595','churi',4,'P','2011-02-16 11:09:48','sandip',NULL,1,0.05),('C1597','2 tarar baki churi regi chara',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1598','Bekey Churi',4,'M','2011-01-16 18:41:19','sandip',NULL,1,0.05),('C1599','churi',4,'T','2011-01-24 15:42:05','sanjoy',NULL,1,0.05),('C1600','Bekey Churi',4,'T','2011-01-15 10:38:53','sandip',NULL,1,0.05),('C1601','thokai bangala konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C16010','thokai bangala konkon mena soru',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1602','thokai bangala konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1603','thokai bangala konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1604','thokai bangala konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1605','thokai bangala konkon soru',15,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C1606','thokai bangala konkon mena soru',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1607','thokai bangala konkon mena soru',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1608','thokai bangala konkon mena soru',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1609','thokai bangala konkon',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1610','thokai konkon majhari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1611','thokai bangla konkon majhari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1612','THOKAI KANKAN',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1613','thokai bangala konkon mena majhari',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1614','thokai bangala konkon mena majhari',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1615','thokai bangala konkon mena majhari',15,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1616','thokai bangala konkon mena maghari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1617','thokai bangala konkon mena maghari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1618','thokai bangala konkon mena maghari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1619','thokai bangala konkon mena maghari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1620','thokai bangala konkon mena maghari',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1621','thokai bangala konkon chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1622','thokai bangala konkon chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1623','thokai bangala konkon chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1624','thokai bangala konkon chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1625','thokai bangala konkon chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1626','thikai bangala konkon mena chowrah',15,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1627','thikai bangala konkon mena chowrah',15,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1628','thikai bangala konkon mena chowrah',15,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1629','thikai bangala konkon mena chowrah',15,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1630','thikai bangala konkon mena chowrah',15,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1631','Thokai Kankan',15,'O','2011-01-09 15:40:45','sandip',NULL,1,0.05),('C1632','Thokai Kankan',15,'O','2011-01-07 11:07:08','sandip',NULL,1,0.05),('C1633','kankan',15,'N',NULL,NULL,NULL,0,0),('C1635','thokai bangala konkon mena majhari',15,'O',NULL,NULL,NULL,0,0),('C1636','Thokai bangla mini konkon',15,'O','2010-06-06 10:21:59','sanjoy',NULL,1,0.05),('C1637','thokai bangala mini konkon',15,'O','2010-06-06 10:22:03','sanjoy',NULL,1,0.05),('C1638','Thokai bangala konkon mena majhari',15,'M',NULL,NULL,NULL,0,0),('C1639','thokai bangala konkon mena maghari',15,'M',NULL,NULL,NULL,0,0),('C1640','Thokai bangala konkon mena majhari',15,'M',NULL,NULL,NULL,0,0),('C1641','Thokai bangla konkon',15,'M','2010-06-06 10:22:59','sanjoy',NULL,1,0.05),('C1642','thokai bangala mini mena konkon',15,'N','2010-06-06 10:23:04','sanjoy',NULL,1,0.05),('C1643','konkon',4,'N','2010-06-06 10:23:06','sanjoy',NULL,1,0.05),('C1644','konkon',4,'N','2010-06-06 10:23:08','sanjoy',NULL,1,0.05),('C1645','thokai bangala mini mena konkon',4,'N','2010-06-06 10:23:10','sanjoy',NULL,1,0.05),('C1646','KANKAN',15,'N',NULL,NULL,NULL,0,0),('C1647','THOKAI KANKAN',15,'N',NULL,NULL,NULL,0,0),('C1648','kankan',15,'N',NULL,NULL,NULL,0,0),('C1651','thokai dd  mini  konkon',4,'M','2010-06-06 10:25:38','sanjoy',NULL,1,0.05),('C1652','thokai dd  mini  konkon',4,'M','2010-06-06 10:25:40','sanjoy',NULL,1,0.05),('C1653','thokai dd  mini  konkon',4,'M','2010-06-06 10:25:42','sanjoy',NULL,1,0.05),('C1654','thokai dd  mini  konkon',4,'M','2010-06-06 10:25:44','sanjoy',NULL,1,0.05),('C1655','thokai dd  mini  konkon',4,'M','2010-06-06 10:25:46','sanjoy',NULL,1,0.05),('C1656','thokai dd mena mini  konkon',4,'N','2010-06-06 10:26:18','sanjoy',NULL,1,0.05),('C1657','thokai dd mena mini  konkon',4,'N','2010-06-06 10:26:22','sanjoy',NULL,1,0.05),('C1658','thokai dd mena mini  konkon',4,'N','2010-06-06 10:26:24','sanjoy',NULL,1,0.05),('C1659','thokai dd mena mini  konkon',4,'N','2010-06-06 10:26:26','sanjoy',NULL,1,0.05),('C1660','thokai dd mena mini  konkon',4,'N','2010-06-06 10:26:39','sanjoy',NULL,1,0.05),('C1666','thokai joypuri  mini  konkon',4,'L','2010-06-06 10:27:31','sanjoy',NULL,1,0.05),('C1667','thokai joypuri  mini  konkon',4,'L','2010-06-06 10:27:35','sanjoy',NULL,1,0.05),('C1668','thokai joypuri  mini  konkon',4,'L','2010-06-06 10:27:36','sanjoy',NULL,1,0.05),('C1669','thokai joypuri  mini  konkon',4,'L','2010-06-06 10:27:38','sanjoy',NULL,1,0.05),('C1670','thokai joypuri  mini  konkon',4,'L','2010-06-06 10:27:40','sanjoy',NULL,1,0.05),('C1671','thokai joypuri mena mini  konkon',4,'M','2010-06-06 10:28:23','sanjoy',NULL,1,0.05),('C1672','thokai joypuri mena mini  konkon',4,'M','2010-06-06 10:28:35','sanjoy',NULL,1,0.05),('C1673','thokai joypuri mena mini  konkon',4,'M','2010-06-06 10:28:38','sanjoy',NULL,1,0.05),('C1674','thokai joypuri mena mini  konkon',4,'M','2010-06-06 10:28:41','sanjoy',NULL,1,0.05),('C1675','thokai joypuri mena mini  konkon',4,'M','2010-06-06 10:28:45','sanjoy',NULL,1,0.05),('C1678','panjabi bala taser ',4,'N','2010-06-06 11:42:30','sanjoy',NULL,1,0.05),('C1679','panjabi bala taser ',4,'N','2010-06-06 11:42:33','sanjoy',NULL,1,0.05),('C1680','panjabi bala taser ',4,'N','2010-06-06 11:42:52','sanjoy',NULL,1,0.05),('C1681','panjabi bala teshiray soru',4,'N','2010-06-06 11:44:09','sanjoy',NULL,1,0.05),('C1682','panjabi bala half round ',4,'O','2010-06-06 11:44:11','sanjoy',NULL,1,0.05),('C1683','panjabi bala mena half round ',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1684','panjabi bala mena half round ',4,'P','2010-06-06 11:45:25','sanjoy',NULL,1,0.05),('C1685','panjabi bala mena half round ',4,'P','2010-06-06 11:45:27','sanjoy',NULL,1,0.05),('C1686','panjabi bala flat panching ',4,'P','2010-06-06 11:46:53','sanjoy',NULL,1,0.05),('C1687','panjabi bala flat panching ',4,'P','2010-06-06 11:46:56','sanjoy',NULL,1,0.05),('C1688','panjabi bala flat panching ',4,'P','2010-06-06 11:47:02','sanjoy',NULL,1,0.05),('C1689','panjabi bala flat panching mena',4,'Q','2010-06-06 11:47:47','sanjoy',NULL,1,0.05),('C1690','panjabi bala flat panching mena',4,'Q','2010-06-06 11:47:50','sanjoy',NULL,1,0.05),('C1691','panjabi bala flat panching mena',4,'Q','2010-06-06 11:47:55','sanjoy',NULL,1,0.05),('C1692','panjabi bala flat decaration',4,'R','2010-06-06 11:49:16','sanjoy',NULL,1,0.05),('C1693','panjabi bala flat decaration',4,'R','2010-06-06 11:49:18','sanjoy',NULL,1,0.05),('C1694','panjabi bala flat decaration',4,'R','2010-06-06 11:49:23','sanjoy',NULL,1,0.05),('C1695','panjabi bala flat decaration mena',4,'S','2010-06-06 11:49:45','sanjoy',NULL,1,0.05),('C1696','panjabi bala flat decaration mena',4,'S','2010-06-06 11:49:49','sanjoy',NULL,1,0.05),('C1697','panjabi bala flat decaration mena',4,'S','2010-06-06 11:49:51','sanjoy',NULL,1,0.05),('C1699','Khal Bala',4,'R','2011-01-16 21:33:36','sandip',NULL,1,0.05),('C1700','Kankan',15,'R','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C1701','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1702','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1703','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1704','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('C1705','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1706','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('C1707','Thikai dd churi saru',4,'G',NULL,NULL,NULL,0,0),('C1708','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1709','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('C1710','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1711','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1713','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1714','Thokai Ckuri',4,'G',NULL,NULL,NULL,0,0),('C1715','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('C1716','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1717','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1718','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1719','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1720','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1721','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1722','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1723','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1724','CHURI',4,'K',NULL,NULL,NULL,0,0),('C1725','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1726','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1727','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1728','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1729','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1730','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('C1731','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1732','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1733','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1734','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1735','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('C1737','CHURI',4,'H',NULL,NULL,NULL,0,0),('C1738','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1739','thokai churi',12,'G',NULL,NULL,NULL,0,0),('C1740','thokai churi',12,'G',NULL,NULL,NULL,0,0),('C1741','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1742','Churi',12,'G',NULL,NULL,NULL,0,0),('C1743','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1746','thokai churi',12,'K',NULL,NULL,NULL,0,0),('C1748','thokai churi',12,'K',NULL,NULL,NULL,0,0),('C1749','Thokai Churi',12,'K',NULL,NULL,NULL,0,0),('C1750','THOKAI CHURI',12,'H',NULL,NULL,NULL,0,0),('C1751','Thokai Churi',12,'I',NULL,NULL,NULL,0,0),('C1752','Thokai Churi',12,'H',NULL,NULL,NULL,0,0),('C1754','churi',12,'G',NULL,NULL,NULL,0,0),('C1755','THOKAI CHURI',12,'H',NULL,NULL,NULL,0,0),('C1756','Thokai Churi',12,'H',NULL,NULL,NULL,0,0),('C1757','thokai churi',12,'G',NULL,NULL,NULL,0,0),('C1758','THOKAI CHURI',12,'I',NULL,NULL,NULL,0,0),('C1759','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1760','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1761','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1762','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1763','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1769','thokai churi',12,'K',NULL,NULL,NULL,0,0),('C1770','churi',12,'G',NULL,NULL,NULL,0,0),('C1771','TKOKAI CHURI',12,'I',NULL,NULL,NULL,0,0),('C1773','thokai churi',12,'H',NULL,NULL,NULL,0,0),('C1774','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1776','thokai churi',4,'G',NULL,NULL,NULL,0,0),('C1779','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1780','Thokai Churi',12,'G',NULL,NULL,NULL,0,0),('C1781','Churi',4,'G',NULL,NULL,NULL,0,0),('C1782','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C1784','thokai churi',12,'G',NULL,NULL,NULL,0,0),('C1785','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1786','churi',4,'G',NULL,NULL,NULL,0,0),('C1788','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('C1789','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('C1790','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1791','churi',4,'H',NULL,NULL,NULL,0,0),('C1792','churi',4,'G',NULL,NULL,NULL,0,0),('C1793','churi',4,'G',NULL,NULL,NULL,0,0),('C1794','churi',4,'G',NULL,NULL,NULL,0,0),('C1795','CHURI',4,'G',NULL,NULL,NULL,0,0),('C1796','churi',4,'G',NULL,NULL,NULL,0,0),('C2001','8MM panching mina patla',4,'K','2010-06-06 13:46:44','sanjoy',NULL,1,0.05),('C2002','8MM panching mina patla',4,'K','2010-06-06 13:46:50','sanjoy',NULL,1,0.05),('C2003','8MM panching mina patla',4,'K','2010-06-06 13:46:52','sanjoy',NULL,1,0.05),('C2004','8MM panching mina patla',4,'K','2010-06-06 13:46:54','sanjoy',NULL,1,0.05),('C2005','8MM panching mina patla',4,'K','2010-06-06 13:46:55','sanjoy',NULL,1,0.05),('C2006','9MM panching mina patla',4,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2007','9MM panching mina patla',4,'L','2010-06-06 13:47:40','sanjoy',NULL,1,0.05),('C2008','9MM panching mina patla',4,'L','2010-06-06 13:47:42','sanjoy',NULL,1,0.05),('C2009','9MM panching mina patla',4,'L','2010-06-06 13:47:45','sanjoy',NULL,1,0.05),('C2010','9MM panching mina patla',4,'L','2010-06-06 13:47:48','sanjoy',NULL,1,0.05),('C2011','10MM panching mina patla',4,'M','2010-06-06 13:48:26','sanjoy',NULL,1,0.05),('C2012','10MM panching mina patla',4,'M','2010-06-06 13:48:28','sanjoy',NULL,1,0.05),('C2013','10MM panching mina patla',4,'M','2010-06-06 13:48:30','sanjoy',NULL,1,0.05),('C2014','10MM panching mina patla',4,'M','2010-06-06 13:48:32','sanjoy',NULL,1,0.05),('C2015','10MM panching mina patla',4,'M','2010-06-06 13:48:35','sanjoy',NULL,1,0.05),('C2016','11MM panching mina patla',4,'N','2010-06-06 13:49:28','sanjoy',NULL,1,0.05),('C2017','11MM panching mina patla',4,'N','2010-06-06 13:49:30','sanjoy',NULL,1,0.05),('C2018','11MM panching mina patla',4,'N','2010-06-06 13:49:32','sanjoy',NULL,1,0.05),('C2019','11MM panching mina patla',4,'N','2010-06-06 13:49:34','sanjoy',NULL,1,0.05),('C2020','11MM panching mina patla',4,'N','2010-06-06 13:49:36','sanjoy',NULL,1,0.05),('C2021','12MM panching mina patla',4,'O','2010-06-06 13:49:53','sanjoy',NULL,1,0.05),('C2022','12MM panching mina patla',4,'O','2010-06-06 13:49:55','sanjoy',NULL,1,0.05),('C2023','12MM panching mina patla',4,'O','2010-06-06 13:49:57','sanjoy',NULL,1,0.05),('C2024','12MM panching mina patla',4,'O','2010-06-06 13:49:59','sanjoy',NULL,1,0.05),('C2025','12MM panching mina patla',4,'O','2010-06-06 13:50:01','sanjoy',NULL,1,0.05),('C2027','13MM panching mina patla',4,'P','2010-06-06 13:50:33','sanjoy',NULL,1,0.05),('C2028','13MM panching mina patla',4,'P','2010-06-06 13:50:34','sanjoy',NULL,1,0.05),('C2029','13MM panching mina patla',4,'P','2010-06-06 13:50:36','sanjoy',NULL,1,0.05),('C2030','13MM panching mina patla',4,'P','2010-06-06 13:50:40','sanjoy',NULL,1,0.05),('C2031','14MM panching mina patla',4,'Q','2010-06-06 13:50:53','sanjoy',NULL,1,0.05),('C2032','14MM panching mina patla',4,'Q','2010-06-06 13:50:56','sanjoy',NULL,1,0.05),('C2033','14MM panching mina patla',4,'Q','2010-06-06 13:50:57','sanjoy',NULL,1,0.05),('C2034','14MM panching mina patla',4,'Q','2010-06-06 13:50:59','sanjoy',NULL,1,0.05),('C2035','14MM panching mina patla',4,'Q','2010-06-06 13:51:01','sanjoy',NULL,1,0.05),('C2036','15MM panching mina patla',4,'R','2010-06-06 13:51:12','sanjoy',NULL,1,0.05),('C2037','15MM panching mina patla',4,'R','2010-06-06 13:51:15','sanjoy',NULL,1,0.05),('C2038','15MM panching mina patla',4,'R','2010-06-06 13:51:17','sanjoy',NULL,1,0.05),('C2039','15MM panching mina patla',4,'R','2010-06-06 13:51:18','sanjoy',NULL,1,0.05),('C2040','15MM panching mina patla',4,'R','2010-06-06 13:51:20','sanjoy',NULL,1,0.05),('C2041','16MM panching mina patla',4,'S','2010-06-06 13:51:34','sanjoy',NULL,1,0.05),('C2042','16MM panching mina patla',4,'S','2010-06-06 13:51:36','sanjoy',NULL,1,0.05),('C2043','16MM panching mina patla',4,'S','2010-06-06 13:51:38','sanjoy',NULL,1,0.05),('C2044','16MM panching mina patla',4,'S','2010-06-06 13:51:40','sanjoy',NULL,1,0.05),('C2045','16MM panching mina patla',4,'S','2010-06-06 13:51:42','sanjoy',NULL,1,0.05),('C2046','17MM panching mina patla',4,'T','2010-06-06 13:52:00','sanjoy',NULL,1,0.05),('C2047','17MM panching mina patla',4,'T','2010-06-06 13:52:02','sanjoy',NULL,1,0.05),('C2048','17MM panching mina patla',4,'T','2010-06-06 13:52:04','sanjoy',NULL,1,0.05),('C2049','17MM panching mina patla',4,'T','2010-06-06 13:52:06','sanjoy',NULL,1,0.05),('C2050','17MM panching mina patla',4,'T','2010-06-06 13:52:08','sanjoy',NULL,1,0.05),('C2051','18MM panching mina patla',4,'U','2010-06-06 13:52:20','sanjoy',NULL,1,0.05),('C2052','18MM panching mina patla',4,'U','2010-06-06 13:52:22','sanjoy',NULL,1,0.05),('C2053','18MM panching mina patla',4,'U','2010-06-06 13:52:24','sanjoy',NULL,1,0.05),('C2054','18MM panching mina patla',4,'U','2010-06-06 13:52:26','sanjoy',NULL,1,0.05),('C2055','18MM panching mina patla',4,'U','2010-06-06 13:52:28','sanjoy',NULL,1,0.05),('C2056','19MM panching mina patla',4,'V','2010-06-06 13:52:47','sanjoy',NULL,1,0.05),('C2057','19MM panching mina patla',4,'V','2010-06-06 13:52:49','sanjoy',NULL,1,0.05),('C2058','19MM panching mina patla',4,'V','2010-06-06 13:52:51','sanjoy',NULL,1,0.05),('C2059','19MM panching mina patla',4,'V','2010-06-06 13:52:53','sanjoy',NULL,1,0.05),('C2060','19MM panching mina patla',4,'V','2010-06-06 13:52:55','sanjoy',NULL,1,0.05),('C2061','20MM panching mina patla',4,'W','2010-06-06 13:53:15','sanjoy',NULL,1,0.05),('C2062','20MM panching mina patla',4,'W','2010-06-06 13:53:17','sanjoy',NULL,1,0.05),('C2063','20MM panching mina patla',4,'W','2010-06-06 13:53:19','sanjoy',NULL,1,0.05),('C2064','20MM panching mina patla',4,'W','2010-06-06 13:53:21','sanjoy',NULL,1,0.05),('C2065','20MM panching mina patla',4,'W','2010-06-06 13:53:23','sanjoy',NULL,1,0.05),('C2071','half round panching churi  chowrah ',4,'O','2010-06-06 13:54:38','sanjoy',NULL,1,0.05),('C2072','half round panching churi  chowrah ',4,'O','2010-06-06 13:54:40','sanjoy',NULL,1,0.05),('C2073','half round panching churi  chowrah ',4,'O','2010-06-06 13:54:42','sanjoy',NULL,1,0.05),('C2074','half round panching churi  chowrah ',4,'O','2010-06-06 13:54:44','sanjoy',NULL,1,0.05),('C2075','half round panching churi  chowrah ',4,'O','2010-06-06 13:54:46','sanjoy',NULL,1,0.05),('C2076','half round panching  mena churi  chowrah ',4,'P','2011-01-31 18:34:29','saheb',NULL,1,0.05),('C2077','half round panching  mena churi  chowrah ',4,'P','2011-01-31 18:34:40','saheb',NULL,1,0.05),('C2078','half round panching  mena churi  chowrah ',4,'P','2011-01-31 18:34:57','saheb',NULL,1,0.05),('C2079','half round panching  mena churi  chowrah ',4,'P','2011-01-31 18:35:08','saheb',NULL,1,0.05),('C2080','half round panching  mena churi  chowrah ',4,'P','2011-01-31 18:36:51','saheb',NULL,1,0.05),('C2081','taser panching churi  chowrah ',4,'P','2011-01-31 18:37:05','saheb',NULL,1,0.05),('C2082','taser panching churi  chowrah ',4,'P','2011-01-31 18:37:21','saheb',NULL,1,0.05),('C2083','taser panching churi  chowrah ',4,'P','2011-01-31 18:37:34','saheb',NULL,1,0.05),('C2084','taser panching churi  chowrah ',4,'P','2011-01-31 18:37:59','saheb',NULL,1,0.05),('C2085','taser panching churi  chowrah ',4,'P','2011-01-31 18:38:08','saheb',NULL,1,0.05),('C2086','taser panching mena churi  chowrah ',4,'Q','2010-06-06 13:57:11','sanjoy',NULL,1,0.05),('C2087','taser panching mena churi  chowrah ',4,'Q','2010-06-06 13:57:13','sanjoy',NULL,1,0.05),('C2088','taser panching mena churi  chowrah ',4,'Q','2010-06-06 13:57:15','sanjoy',NULL,1,0.05),('C2089','taser panching mena churi  chowrah ',4,'Q','2010-06-06 13:57:17','sanjoy',NULL,1,0.05),('C2090','taser panching mena churi  chowrah ',4,'Q','2010-06-06 13:57:19','sanjoy',NULL,1,0.05),('C2101','half round khal panching soru ',4,'J','2010-06-06 13:59:10','sanjoy',NULL,1,0.05),('C2102','half round khal panching soru ',4,'J','2010-06-06 13:59:13','sanjoy',NULL,1,0.05),('C2103','half round khal panching soru ',4,'J','2010-06-06 13:59:15','sanjoy',NULL,1,0.05),('C2104','half round khal panching soru ',4,'J','2010-06-06 13:59:16','sanjoy',NULL,1,0.05),('C2105','half round khal panching soru ',4,'J','2010-06-06 13:59:18','sanjoy',NULL,1,0.05),('C2106','half round khal panching decaration mina ',4,'Q','2010-06-06 14:00:19','sanjoy',NULL,1,0.05),('C2107','half round khal panching decaration mina ',4,'Q','2010-06-06 14:00:22','sanjoy',NULL,1,0.05),('C2108','half round khal panching decaration mina ',4,'Q','2010-06-06 14:00:24','sanjoy',NULL,1,0.05),('C2109','half round khal panching decaration mina ',4,'Q','2010-06-06 14:00:26','sanjoy',NULL,1,0.05),('C2110','half round khal panching decaration mina ',4,'Q','2010-06-06 14:00:35','sanjoy',NULL,1,0.05),('C2111','half round khal panching maghari ',4,'K','2010-06-06 14:01:19','sanjoy',NULL,1,0.05),('C2112','half round khal panching maghari ',4,'Q','2010-06-06 14:01:21','sanjoy',NULL,1,0.05),('C2113','half round khal panching maghari ',4,'Q','2010-06-06 14:01:23','sanjoy',NULL,1,0.05),('C2114','half round khal panching maghari ',4,'Q','2010-06-06 14:01:25','sanjoy',NULL,1,0.05),('C2115','half round khal panching maghari ',4,'Q','2010-06-06 14:01:27','sanjoy',NULL,1,0.05),('C2116','half round khal panching decaration mena maghari ',4,'M','2010-06-06 14:02:24','sanjoy',NULL,1,0.05),('C2117','half round khal panching decaration mena maghari ',4,'M','2010-06-06 14:02:27','sanjoy',NULL,1,0.05),('C2118','half round khal panching decaration mena maghari ',4,'M','2010-06-06 14:02:30','sanjoy',NULL,1,0.05),('C2119','half round khal panching decaration mena maghari ',4,'M','2010-06-06 14:02:32','sanjoy',NULL,1,0.05),('C2120','half round khal panching decaration mena maghari ',4,'M','2010-06-06 14:02:35','sanjoy',NULL,1,0.05),('C2121','half round khal panching chowrah ',4,'L','2010-06-06 14:03:21','sanjoy',NULL,1,0.05),('C2122','half round khal panching chowrah ',4,'L','2010-06-06 14:03:23','sanjoy',NULL,1,0.05),('C2123','half round khal panching chowrah ',4,'L','2010-06-06 14:03:25','sanjoy',NULL,1,0.05),('C2124','half round khal panching chowrah ',4,'L','2010-06-06 14:03:27','sanjoy',NULL,1,0.05),('C2125','half round khal panching chowrah ',4,'L','2010-06-06 14:03:29','sanjoy',NULL,1,0.05),('C2126','half round khal panching chowrah ',4,'L','2010-06-06 14:03:31','sanjoy',NULL,1,0.05),('C2127','half round khal panching decaration mena chowrah ',4,'N','2010-06-06 14:04:41','sanjoy',NULL,1,0.05),('C2128','half round khal panching decaration mena chowrah ',4,'N','2010-06-06 14:04:42','sanjoy',NULL,1,0.05),('C2129','half round khal panching decaration mena chowrah ',4,'N','2010-06-06 14:04:44','sanjoy',NULL,1,0.05),('C2130','half round khal panching decaration mena chowrah ',4,'N','2010-06-06 14:04:50','sanjoy',NULL,1,0.05),('C2136','9MM chowrah khal bowti ',4,'J','2010-06-06 14:34:01','sanjoy',NULL,1,0.05),('C2137','9MM chowrah khal bowti ',4,'J','2010-06-06 14:34:04','sanjoy',NULL,1,0.05),('C2138','9MM chowrah khal panching ',4,'K','2010-06-06 14:34:54','sanjoy',NULL,1,0.05),('C2139','9MM chowrah khal panching ',4,'K','2010-06-06 14:34:56','sanjoy',NULL,1,0.05),('C2140','9MM chowrah panching mena',4,'L','2010-06-06 14:35:54','sanjoy',NULL,1,0.05),('C2141','9MM chowrah panching mena',4,'L','2010-06-06 14:35:57','sanjoy',NULL,1,0.05),('C2142','9MM panching decaration mena',4,'M','2010-06-06 14:37:11','sanjoy',NULL,1,0.05),('C2143','9MM panching decaration mena',4,'M','2010-06-06 14:37:15','sanjoy',NULL,1,0.05),('C2144','10MM chowrah  khal bowti ',4,'K','2010-06-06 14:38:29','sanjoy',NULL,1,0.05),('C2145','10MM chowrah  khal bowti ',4,'K','2010-06-06 14:38:36','sanjoy',NULL,1,0.05),('C2146','10MM chowrah  khal panching',4,'L','2010-06-06 14:40:41','sanjoy',NULL,1,0.05),('C2147','10MM chowrah  khal panching',4,'L','2010-06-06 14:40:53','sanjoy',NULL,1,0.05),('C2148','10MM chowrah panching mena ',4,'M','2010-06-06 14:42:11','sanjoy',NULL,1,0.05),('C2149','10MM chowrah panching mena ',4,'M','2010-06-06 14:42:13','sanjoy',NULL,1,0.05),('C2150','10MM panching decaration  mena ',4,'N','2010-06-06 14:43:10','sanjoy',NULL,1,0.05),('C2151','10MM panching decaration  mena ',4,'N','2010-06-06 14:43:39','sanjoy',NULL,1,0.05),('C2152','11MM chowrah khal bowti ',4,'L','2010-06-06 14:45:30','sanjoy',NULL,1,0.05),('C2153','11MM chowrah khal bowti ',4,'L','2010-06-06 14:45:32','sanjoy',NULL,1,0.05),('C2154','11MM chowrah khal panching ',4,'M','2010-06-06 14:46:20','sanjoy',NULL,1,0.05),('C2155','11MM chowrah khal panching ',4,'M','2010-06-06 14:46:23','sanjoy',NULL,1,0.05),('C2156','11MM chowrah panching mena  ',4,'N','2010-06-06 14:47:22','sanjoy',NULL,1,0.05),('C2157','11MM chowrah panching mena  ',4,'N','2010-06-06 14:47:25','sanjoy',NULL,1,0.05),('C2158','11MM panching decaration mena  ',4,'O','2011-01-31 18:38:52','saheb',NULL,1,0.05),('C2159','11MM panching decaration mena  ',4,'O','2011-01-31 18:39:03','saheb',NULL,1,0.05),('C2160','12MM chowrah khal bowti ',4,'M','2010-06-06 14:49:40','sanjoy',NULL,1,0.05),('C2161','12MM chowrah khal bowti ',4,'M','2010-06-06 14:49:42','sanjoy',NULL,1,0.05),('C2162','12MM chowrah khal panching ',4,'N','2010-06-06 14:51:48','sanjoy',NULL,1,0.05),('C2163','12MM chowrah khal panching ',4,'N','2010-06-06 14:51:50','sanjoy',NULL,1,0.05),('C2164','12MM chowrah panching mena',4,'O','2010-06-06 14:52:23','sanjoy',NULL,1,0.05),('C2165','12MM chowrah panching mena',4,'O','2010-06-06 14:52:26','sanjoy',NULL,1,0.05),('C2166','12MM panching decaration mena',4,'P','2010-06-06 14:53:09','sanjoy',NULL,1,0.05),('C2167','12MM panching decaration mena',4,'P','2010-06-06 14:53:14','sanjoy',NULL,1,0.05),('C2168','13MM chowrah khal bowti ',4,'N','2010-06-06 14:54:27','sanjoy',NULL,1,0.05),('C2169','13MM chowrah khal bowti ',4,'N','2010-06-06 14:54:30','sanjoy',NULL,1,0.05),('C2170','13MM chowrah khal panching',4,'O','2011-01-31 18:39:28','saheb',NULL,1,0.05),('C2171','13MM chowrah khal panching',4,'O','2011-01-31 18:39:40','saheb',NULL,1,0.05),('C2172','13MM chowrah panching mena',4,'P','2010-06-06 14:55:53','sanjoy',NULL,1,0.05),('C2174','13MM chowrah panching mena',4,'P','2010-06-06 14:56:01','sanjoy',NULL,1,0.05),('C2175','13MM panching decaration mena',4,'Q','2010-06-06 14:57:41','sanjoy',NULL,1,0.05),('C2176','14MM chowrah khal bowti ',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2177','14MM chowrah khal bowti ',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2178','14MM chowrah khal panching ',4,'P','2010-06-06 14:59:11','sanjoy',NULL,1,0.05),('C2179','14MM chowrah khal panching ',4,'P','2010-06-06 14:59:15','sanjoy',NULL,1,0.05),('C2180','14MM chowrah panching mena',4,'Q','2010-06-06 14:59:41','sanjoy',NULL,1,0.05),('C2181','14MM chowrah panching mena',4,'Q','2010-06-06 15:00:09','sanjoy',NULL,1,0.05),('C2182','14MM panching decaration mena',4,'R','2010-06-06 15:01:00','sanjoy',NULL,1,0.05),('C2183','14MM panching decaration mena',4,'R','2010-06-06 15:01:04','sanjoy',NULL,1,0.05),('C2201','Thokai Patla',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2202','Thokai Bouty',13,'M','2011-01-09 15:44:08','sandip',NULL,1,0.05),('C2203','Thokai Bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2204','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2205','Thokai Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2206','Thokai Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2207','Thokai Bouty',13,'M','2011-01-22 13:23:40','sanjoy',NULL,1,0.05),('C2208','Thokai Bouty',13,'N','2011-01-08 13:43:04','sandip',NULL,1,0.05),('C2209','Thokai Bouty',13,'M','2011-01-09 12:23:53','sandip',NULL,1,0.05),('C2210','Thokai Bouty',13,'M','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C2211','Thokai Bouty',13,'M','2011-01-14 19:09:35','sandip',NULL,1,0.05),('C2212','Thokai Bouty',13,'M','2011-01-07 13:06:06','sandip',NULL,1,0.05),('C2213','Thokai Bouty',13,'M','2011-01-07 10:26:14','sandip',NULL,1,0.05),('C2214','Thokai Bouty',13,'M','2011-01-07 19:10:35','sandip',NULL,1,0.05),('C2215','Thokai Bouty',13,'M','2011-01-09 12:24:07','sandip',NULL,1,0.05),('C2216','Bouty',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2217','Thokai Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2218','Thokai Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2219','Thokai Bouty',13,'M','2011-01-26 09:59:02','saheb',NULL,1,0.05),('C2220','Thokai Patla',14,'M','0000-00-00 00:00:00','b',NULL,1,0.05),('C2222','Bouty',13,'M','2041-10-01 00:00:00','sanjoy',NULL,1,0.05),('C2224','Thokai Bouty',13,'L','2041-07-03 00:00:00','sukanta',NULL,1,0.05),('C2225','Thokai Patla',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2226','Thokai Patla',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2227','Thokai Patla',14,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2228','Bouty',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2230','Thokai Bouty',13,'M','2011-01-14 21:26:57','sandip',NULL,1,0.05),('C2231','Thokai Bouty',13,'M','2011-02-05 19:12:31','sandip',NULL,1,0.05),('C2232','Thokai Bouty',13,'M','2011-01-22 20:14:48','sanjoy',NULL,1,0.05),('C2233','Thokai Bouty',13,'M','2011-01-23 19:25:53','sandip',NULL,1,0.05),('C2235','Thokai Bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2236','Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2237','Bouty',13,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2238','Bouty',13,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2239','Thokai bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2240','Thokai bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2241','Thokai Bangla Bowti',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2242','Thokai Bangla Bowti',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2243','BOUTY',13,'L',NULL,NULL,NULL,0,0),('C2249','patla',14,'N',NULL,NULL,NULL,0,0),('C2250','Thokai Patla',14,'L','0000-00-00 00:00:00','manoka',NULL,1,0.05),('C2251','PATLA',14,'N',NULL,NULL,NULL,0,0),('C2253','Thokai Patla',14,'M','2011-01-25 14:14:53','sandip',NULL,1,0.05),('C2254','Thokai Patla',14,'L','2011-01-25 20:11:10','b',NULL,1,0.05),('C2255','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2256','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2257','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2258','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2259','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2260','Thokai Patla',14,'M','2011-01-07 12:08:11','sandip',NULL,1,0.05),('C2261','Thokai Patla',14,'M','2011-01-08 13:34:14','sandip',NULL,1,0.05),('C2262','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2264','Thokai Patla',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2265','Thokai Patla',14,'L','2011-01-08 13:33:31','sandip',NULL,1,0.05),('C2267','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2268','Thokai Patla',14,'M','0000-00-00 00:00:00','avik',NULL,1,0.05),('C2270','Thokai Patla',14,'M','2041-05-07 00:00:00','sanjoy',NULL,1,0.05),('C2271','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2272','Thokai Patla',14,'M','2011-01-25 20:10:51','b',NULL,1,0.05),('C2273','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2274','Thokai Patla',14,'M','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2276','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2277','Thokai Patla',14,'M','2011-01-08 13:35:17','sandip',NULL,1,0.05),('C2278','Thokai Patla',14,'M',NULL,NULL,NULL,0,0),('C2279','Thokai Patla',14,'M','2011-01-30 19:58:10','sandip',NULL,1,0.05),('C2280','Thokai Patla',14,'M','2011-02-06 19:38:42','sandip',NULL,1,0.05),('C2281','Thokai Patla',14,'M','2011-01-23 19:33:58','sandip',NULL,1,0.05),('C2282','Bouty',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2283','Thokai Patla',14,'N','2011-01-08 13:36:33','sandip',NULL,1,0.05),('C2285','Thokai Patla',14,'M','2011-01-30 12:25:20','sanjoy',NULL,1,0.05),('C2286','Bouty',13,'L','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2287','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2288','Thokai Patla',14,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2289','Thokai Patla',14,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2290','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2292','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2293','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2294','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2295','Thokai Patla',14,'M','2041-04-07 00:00:00','Raja',NULL,1,0.05),('C2296','THOKAI BOUTY',13,'M',NULL,NULL,NULL,1,0.05),('C2297','patla',14,'M',NULL,NULL,NULL,0,0),('C2298','patla',14,'L',NULL,NULL,NULL,0,0),('C2299','Patla',14,'L',NULL,NULL,NULL,0,0),('C2300','Patla',14,'L',NULL,NULL,NULL,0,0),('C2301','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2302','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2303','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2304','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2305','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2306','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2307','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2308','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2309','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2310','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2311','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2312','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2313','Thokai patla soru',14,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2319','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2320','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2321','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2322','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2323','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2324','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2325','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2326','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2327','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2328','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2329','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2330','Thokai Patla',14,'L','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2331','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2332','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2333','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2334','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2335','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2336','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2337','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2338','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2339','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2340','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2341','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2342','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2343','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2344','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2345','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2346','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2347','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2348','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2349','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2350','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2351','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2352','THOKAI PATLA',14,'M',NULL,NULL,NULL,0,0),('C2353','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('C2354','THOKAI PATLA',14,'N',NULL,NULL,NULL,0,0),('C2355','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2356','THOLAI PATLA',14,'N',NULL,NULL,NULL,0,0),('C2357','THOKAI PATLA',14,'N',NULL,NULL,NULL,0,0),('C2358','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2360','patla',14,'N',NULL,NULL,NULL,0,0),('C2363','bouty',13,'M',NULL,NULL,NULL,0,0),('C2364','PATLA',14,'N',NULL,NULL,NULL,0,0),('C2365','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2366','PATLA',14,'N',NULL,NULL,NULL,0,0),('C2367','Bouty',13,'M',NULL,NULL,NULL,0,0),('C2368','PATLA',12,'L',NULL,NULL,NULL,0,0),('C2369','PATLA',14,'L',NULL,NULL,NULL,0,0),('C2370','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2371','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2372','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2373','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2374','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2375','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2376','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2377','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2378','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2379','Thokai Patla',14,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2380','Thokai Patla',14,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2381','PATLA',14,'N',NULL,NULL,NULL,0,0),('C2382','Patla',14,'M',NULL,NULL,NULL,0,0),('C2383','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('C2384','mina patla',10,'N',NULL,NULL,NULL,0,0),('C2385','PATLA',14,'L',NULL,NULL,NULL,0,0),('C2386','PATLA',14,'L',NULL,NULL,NULL,0,0),('C2387','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2388','PATLA',14,'L',NULL,NULL,NULL,0,0),('C2389','PATLA',14,'L',NULL,NULL,NULL,0,0),('C2390','PATLA',14,'M',NULL,NULL,NULL,0,0),('C2392','Patla',14,'M',NULL,NULL,NULL,0,0),('C2393','Patla',14,'L',NULL,NULL,NULL,0,0),('C2394','PATLA',10,'M',NULL,NULL,NULL,0,0),('C2395','patla',10,'O',NULL,NULL,NULL,0,0),('C2396','patla',14,'L',NULL,NULL,NULL,0,0),('C2397','patla',14,'L',NULL,NULL,NULL,0,0),('C2398','patla',14,'N',NULL,NULL,NULL,0,0),('C2399','patla',14,'M',NULL,NULL,NULL,0,0),('C2403','Thokai Churi',12,'G','2041-08-01 00:00:00','Raja',NULL,1,0.05),('C2404','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2406','Thokai Churi',12,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2407','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2408','CHURI',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2409','Thokai churi',12,'H',NULL,NULL,NULL,0,0),('C2410','Thokai churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2413','Thokai churi',4,'G','2011-01-25 12:08:02','sandip',NULL,1,0.05),('C2415','Thokai Churi',12,'G','2011-01-08 10:14:59','sandip',NULL,1,0.05),('C2416','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2417','churi',4,'G','2011-02-16 12:33:19','sanjoy',NULL,1,0.05),('C2418','PLAZA',4,'H','2011-02-13 18:39:59','sandip',NULL,1,0.05),('C2419','Thokai Churi',4,'G','2011-01-05 12:47:46','b',NULL,1,0.05),('C2420','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2421','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2422','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2423','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2424','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2425','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2426','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2427','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2428','Thokai Churi Plaza',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2429','churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2430','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2431','Thokai churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2432','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2433','Thokai churi',4,'G','2011-02-09 17:44:52','sandip',NULL,1,0.05),('C2434','churi',4,'G','2011-02-11 20:06:55','sandip',NULL,1,0.05),('C2435','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2436','Thokai churi',4,'G','2011-01-08 12:15:37','sandip',NULL,1,0.05),('C2437','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2438','Thokai churi',4,'G','2011-01-14 21:25:42','sandip',NULL,1,0.05),('C2439','Thokai churi',4,'G','2011-02-11 11:42:35','avik',NULL,1,0.05),('C2440','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2441','Thokai Churi',12,'G','2011-01-07 12:15:07','sandip',NULL,1,0.05),('C2442','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2443','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2444','Thokai Churi',4,'G','2011-01-09 12:25:08','sandip',NULL,1,0.05),('C2445','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('C2446','Thokai churi',4,'G','2011-01-14 21:26:14','sandip',NULL,1,0.05),('C2447','Thokai churi',4,'G','2011-01-16 21:32:05','sandip',NULL,1,0.05),('C2448','Thokai churi',4,'G','2011-01-23 18:32:11','sandip',NULL,1,0.05),('C2449','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2450','Thokai Churi',12,'G','2011-01-07 16:13:44','b',NULL,1,0.05),('C2451','Thokai Churi Bangla',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2452','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2453','Thokai churi',4,'G','2011-01-12 19:15:21','sandip',NULL,1,0.05),('C2454','Thokai Churi Bangla',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2455','churi',4,'G','2011-01-26 18:41:09','sanjoy',NULL,1,0.05),('C2456','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2457','Thokai Churi Bangla',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2458','Thokai Churi Bangla',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2459','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2460','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2461','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2462','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2463','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2464','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2465','Thokai churi',4,'G','2011-01-09 16:38:30','sandip',NULL,1,0.05),('C2466','Thokai churi',4,'G','2011-01-22 10:19:55','sanjoy',NULL,1,0.05),('C2467','churi',4,'G','0000-00-00 00:00:00','b',NULL,1,0.05),('C2468','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2469','churi',4,'G','2011-01-24 19:19:29','sandip',NULL,1,0.05),('C2470','churi',4,'G','2011-02-09 16:53:08','sanjoy',NULL,1,0.05),('C2471','Thokai churi',4,'G','2011-01-14 10:35:25','sandip',NULL,1,0.05),('C2472','Thokai churi',4,'G','2011-01-14 10:35:43','sandip',NULL,1,0.05),('C2473','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2474','thokai bangla churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C2475','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2476','Thokai Churi',4,'G','2011-01-22 20:12:38','sanjoy',NULL,1,0.05),('C2477','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2478','Thokai churi',4,'G','2011-02-09 17:45:30','sandip',NULL,1,0.05),('C2479','Thokai Churi',4,'G','2011-01-14 12:34:29','sandip',NULL,1,0.05),('C2480','Thokai churi',4,'G','2011-02-09 17:45:22','sandip',NULL,1,0.05),('C2481','Thokai Churi Bangla',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2482','Thokai Churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2483','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2484','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2485','Thokai Churi',4,'G','2011-01-25 14:13:21','sandip',NULL,1,0.05),('C2486','Thokai Churi',12,'G','2011-01-07 16:17:02','b',NULL,1,0.05),('C2487','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2488','Thokai Churi',12,'G','2011-01-05 12:48:51','b',NULL,1,0.05),('C2489','Thokai Churi',4,'G','2011-01-09 10:38:13','sandip',NULL,1,0.05),('C2490','Thokai churi',4,'G','2011-01-25 14:16:56','sandip',NULL,1,0.05),('C2491','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2492','Thokai churi',4,'G','2011-01-18 20:57:01','sandip',NULL,1,0.05),('C2493','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2494','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2495','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2496','Thokai Churi',12,'G','2011-01-09 11:04:31','sandip',NULL,1,0.05),('C2497','Thokai Churi',4,'G','2011-01-30 12:07:51','sanjoy',NULL,1,0.05),('C2498','Thokai Churi',4,'G','2011-01-09 10:38:55','sandip',NULL,1,0.05),('C2499','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2500','Thokai Churi Bangla',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2501','bouty',13,'M',NULL,NULL,NULL,0,0),('C2502','bouty',13,'M',NULL,NULL,NULL,0,0),('C2503','bouty',13,'M',NULL,NULL,NULL,0,0),('C2504','bouty',13,'M',NULL,NULL,NULL,0,0),('C2701','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2702','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2703','Thokai Bowty',13,'N','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2704','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2705','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2706','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2707','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2708','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2709','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2710','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2711','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2712','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2713','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2714','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2715','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2716','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2717','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2718','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2719','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2720','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2721','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2722','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2723','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2724','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2725','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2726','Bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2727','Thokai Bowty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2728','Bouty',13,'M','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2729','Bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2730','Bouty',13,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2731','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2732','THOKAI BAUTY',13,'M',NULL,NULL,NULL,0,0),('C2733','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2734','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2735','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2736','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2737','New Model',0,'M',NULL,NULL,NULL,0,0),('C2738','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2739','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2740','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2741','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2742','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2743','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2744','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2745','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2746','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2747','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2748','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2749','Thokai Bouty',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C2751','Bouty',13,'N',NULL,NULL,NULL,0,0),('C2753','BOUTY',13,'O',NULL,NULL,NULL,0,0),('C2754','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2755','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2756','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2757','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2758','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2759','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2760','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2761','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2762','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2763','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2764','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2765','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2766','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2767','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2768','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2769','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2770','Thokai Bouty',13,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C2771','Thokai Bauty',13,'L',NULL,NULL,NULL,0,0),('C2772','CHURI',3,'L',NULL,'sanjoy',NULL,1,0.05),('C2773','CHURI',3,'L',NULL,'sanjoy',NULL,1,0.05),('C2774','bouty',13,'L',NULL,NULL,NULL,0,0),('C2775','THOKAI BAUTY',13,'M',NULL,NULL,NULL,0,0),('C2776','BOUTY',13,'L',NULL,NULL,NULL,0,0),('C2780','BOUTY',13,'L',NULL,NULL,NULL,0,0),('C2782','Thokai Bauty',13,'L',NULL,NULL,NULL,0,0),('C2783','Thokai Bauty',13,'L',NULL,NULL,NULL,0,0),('C2784','Thokai Bauty',13,'L',NULL,NULL,NULL,0,0),('C2785','bouty',13,'M',NULL,NULL,NULL,0,0),('C2786','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2787','Bauti',13,'M',NULL,NULL,NULL,0,0),('C2788','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2789','bouty',13,'M',NULL,NULL,NULL,0,0),('C2790','THOKAI BOWTY',13,'M',NULL,NULL,NULL,0,0),('C2791','Thokai Bouty',13,'M',NULL,NULL,NULL,0,0),('C2792','THOKAI BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2793','BOUTY',13,'N',NULL,NULL,NULL,0,0),('C2794','Bouty',13,'M',NULL,NULL,NULL,0,0),('C2795','Bouty',13,'M',NULL,NULL,NULL,0,0),('C2796','Bouty',13,'M',NULL,NULL,NULL,0,0),('C2797','bouty',13,'N',NULL,NULL,NULL,0,0),('C2798','Bouty',13,'M',NULL,NULL,NULL,0,0),('C2799','BOUTY',13,'M',NULL,NULL,NULL,0,0),('C2800','Bouty',13,'N',NULL,NULL,NULL,0,0),('C3001','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3002','CHURI',4,'H',NULL,NULL,NULL,0,0),('C3003','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3004','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3005','Churi',4,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C3006','Thokai churi',4,'H','2011-01-10 10:34:15','sandip',NULL,1,0.05),('C3007','New Model',0,'G',NULL,NULL,NULL,0,0),('C3008','Thokai churi',4,'F','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3009','Thokai churi',4,'G','2011-01-10 10:34:38','sandip',NULL,1,0.05),('C3010','Thokai churi',4,'G','2011-01-15 10:39:20','sandip',NULL,1,0.05),('C3011','Thokai churi',4,'G','0000-00-00 00:00:00','avik',NULL,1,0.05),('C3014','Thokai churi',4,'G','2011-02-04 20:29:01','b',NULL,1,0.05),('C3015','Thokai churi',4,'G','2011-01-09 11:38:39','sandip',NULL,1,0.05),('C3016','Thokai churi',4,'G','2011-01-26 11:39:08','sandip',NULL,1,0.05),('C3018','Thokai Churi',12,'F','2011-01-07 10:25:04','sandip',NULL,1,0.05),('C3020','Thokai churi Plaza',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3021','Thokai Plaza',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3022','Thokai Churi',4,'H','2011-01-14 19:07:23','sandip',NULL,1,0.05),('C3023','churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3024','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3025','Churi',4,'G','2041-12-09 00:00:00','sukanta',NULL,1,0.05),('C3026','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3027','churi',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3028','Thokai Churi',4,'H','2011-01-25 10:15:21','sandip',NULL,1,0.05),('C3029','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3030','Thokai Plaza churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3031','Thokai Churi',12,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C3032','churi',4,'G','2011-01-24 15:24:37','sanjoy',NULL,1,0.05),('C3033','Thokai churi',4,'H','2011-01-14 10:36:15','sandip',NULL,1,0.05),('C3034','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3035','Thokai churi',4,'H','2011-01-30 12:12:28','sanjoy',NULL,1,0.05),('C3036','',4,'F','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3037','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3038','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3039','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3040','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3041','Thokai churi',4,'I','2011-02-09 18:04:33','sandip',NULL,1,0.05),('C3042','Thokai Churi',4,'H','0000-00-00 00:00:00','Raja',NULL,1,0.05),('C3043','CHURI',4,'G',NULL,NULL,NULL,0,0),('C3044','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3046','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3047','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3049','Thokai churi',4,'H','2011-01-28 12:24:09','sandip',NULL,1,0.05),('C3050','churi',4,'I','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3051','Thokai churi',4,'I','2011-01-10 10:35:16','sandip',NULL,1,0.05),('C3052','churi',4,'I','2011-02-16 12:35:14','sanjoy',NULL,1,0.05),('C3053','Thokai churi',4,'I','2011-01-15 18:04:15','sandip',NULL,1,0.05),('C3054','Thokai churi',4,'H','2011-01-24 18:52:34','sandip',NULL,1,0.05),('C3055','Thokai Churi',12,'G','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C3056','Thokai churi',4,'F','2011-02-11 20:48:50','sanjoy',NULL,1,0.05),('C3057','Thokai churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3059','Thokai churi',4,'I','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3060','Thokai churi',4,'H','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3061','Thokai Churi',4,'H','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3062','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3063','Thokai Churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3064','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3065','Thokai churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('C3066','Thokai Joypuri Churi',4,'H','2041-07-04 00:00:00','Raja',NULL,1,0.05),('C3067','Thokai Joypuri Churi',4,'G','2041-12-07 00:00:00','Raja',NULL,1,0.05),('C3068','Thokai Joypuri plaza Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3069','churi',4,'H','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C3070','churi',4,'H','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C3071','churi',4,'H','0000-00-00 00:00:00','saheb',NULL,1,0.05),('C3072','Thokai Joypuri plaza Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('C3073','Thokai Churi',12,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3074','Thokai Churi',12,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3075','Thokai Churi',12,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3076','Thokai Churi',12,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('C3077','Thokai Churi Plaza',4,'H',NULL,NULL,NULL,0,0),('C3078','PLAZA',4,'H',NULL,NULL,NULL,0,0),('C3079','PLAZA',4,'H',NULL,NULL,NULL,0,0),('C3080','Thokai Plaza',4,'I',NULL,NULL,NULL,0,0),('C3081','THOKAI PLAZA',4,'I',NULL,NULL,NULL,0,0),('C3082','THOKAI CHURI',4,'I',NULL,NULL,NULL,0,0),('C3083','THOKAI CHURI',4,'I',NULL,NULL,NULL,0,0),('C3084','THOKAI PLAZA',4,'I',NULL,NULL,NULL,0,0),('C3085','THOKAI PLAZA',4,'I',NULL,NULL,NULL,0,0),('C3086','Thokai Plaza',4,'I',NULL,NULL,NULL,0,0),('C3089','New Model',4,'H',NULL,NULL,NULL,0,0),('C3115','New Model',12,'G',NULL,NULL,NULL,0,0),('C4001','curi',4,'G',NULL,NULL,NULL,0,0),('C4002','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4003','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4004','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4005','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4006','PLAZA',12,'H',NULL,NULL,NULL,0,0),('C4007','CHURI',12,'H',NULL,NULL,NULL,0,0),('C4008','CHURI',4,'H',NULL,NULL,NULL,0,0),('C4009','CHURI',12,'H',NULL,NULL,NULL,0,0),('C4010','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4011','CHURI',4,'H',NULL,NULL,NULL,0,0),('C4012','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4013','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4014','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4015','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4016','CHURI',4,'G',NULL,NULL,NULL,0,0),('C4017','CHURI',4,'G',NULL,NULL,NULL,0,0),('F0002','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('F0003','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('F0312','fancy noa',18,'v',NULL,NULL,NULL,0,0),('F1223','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('F1224','TEENAGER',3,'N',NULL,NULL,NULL,1,0.05),('F1225','TEENAGER',3,'Q',NULL,NULL,NULL,1,0.05),('F1226','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('F1227','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('F1228','TEENAGER',3,'V',NULL,NULL,NULL,1,0.05),('F1232','TEENAGER',3,'M',NULL,NULL,NULL,1,0.05),('F1234','TEENAGER',3,'P',NULL,NULL,NULL,1,0.05),('H1702','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1703','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1704','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1705','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1706','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1707','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1708','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1709','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1710','Holo 3MM Churi',19,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1711','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1712','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1713','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1714','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1715','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1716','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1717','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1718','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1719','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1720','Holo 3MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1721','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1722','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1723','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1724','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1725','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1726','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1727','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1728','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1729','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1730','Holo 3MM Decaration Mina Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1734','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1735','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1736','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1737','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1738','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1739','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1740','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1741','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1742','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1743','Holo 4MM Churi',19,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1744','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1745','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1746','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1747','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1748','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1749','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1750','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1751','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1752','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1753','Holo 4MM Decaration Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1754','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1755','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1756','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1757','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1758','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1759','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1760','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1761','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1762','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1763','Holo 4MM Decaration Mina churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1767','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1768','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1769','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1770','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1771','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1772','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1773','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1774','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1775','Holo 5MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1776','Holo 3MM Churi',19,'K','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1777','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1778','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1779','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1780','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1781','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1782','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1783','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1784','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1785','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1786','Holo 5MM Decaration Churi',19,'L','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1787','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1788','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1789','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1790','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1791','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1792','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1793','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1794','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1795','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1796','Holo 5MM Decaration Mina Churi',19,'M','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1801','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1802','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1803','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1804','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1805','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1806','Holo 6MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1807','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1808','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1809','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1810','Holo 6MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1811','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1812','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1813','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1814','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1815','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1816','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1817','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1818','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1819','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1820','Holo 6MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1821','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1822','Holo 6MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1823','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1824','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1825','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1826','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1827','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1828','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1829','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1830','Holo 6MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1831','HOLLOW',18,'U',NULL,NULL,NULL,0,0),('H1832','HOLLO',18,'U',NULL,NULL,NULL,0,0),('H1833','HOLO',18,'U',NULL,NULL,NULL,0,0),('H1834','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1835','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1836','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1837','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1838','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1839','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1841','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1842','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1843','Holo 7MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1844','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1845','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1846','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1847','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1848','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1849','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1850','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1851','Holo 7MM Decoration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1852','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1853','Holo 7MM Decaration Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1854','Holo 7MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1855','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1856','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1857','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1858','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1859','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1860','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1861','Holo 7MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1862','Holo 7MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1863','Holo 7MM Decaration Mina Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1867','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1868','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1869','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1870','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1871','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1872','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1873','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1874','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1875','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1876','Holo 8MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1877','Holo 8MM Decaration  Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1878','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1879','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1880','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1881','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1882','Holo 8MM Decaration  Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1883','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1884','Holo 8MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1885','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1886','Holo 8MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1887','Holo 8 M.M.Decoration Mina Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1888','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1889','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1890','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1891','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1892','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1893','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1894','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1895','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1896','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1897','Holo 8MM Decaration Mina  churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1898','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1899','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1901','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1902','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1903','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1904','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1905','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1906','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1907','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1908','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1909','Holo 9MM Churi',19,'U','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1910','Holo 9MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1911','Holo 9MM Decoration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1912','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1913','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1914','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1915','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1916','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1917','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1918','Holo 9MM Decaration  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1919','Holo 9MM Decoration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1920','Holo 9MM Decoration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1921','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1922','Holo 9MM Decoration  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1923','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1924','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1925','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1926','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1927','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1928','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1929','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1930','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1931','Holo 9MM Decaration Mina  Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1932','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1933','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1934','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1935','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1936','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1937','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1938','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1939','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1940','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1941','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1942','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1943','Holo 10MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1944','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1945','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1946','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1947','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1948','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1949','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1950','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('H1951','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1952','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1953','Holo 10MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1954','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1955','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1956','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1957','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1958','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1959','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1960','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1961','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1962','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1963','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1964','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1965','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1966','Holo 10MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1967','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1968','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1969','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1970','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1971','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1972','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1973','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1974','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1975','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1976','Holo 11MM Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1977','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1978','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1979','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1980','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1981','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1982','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1983','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1984','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1985','Holo 11MM Decaration Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1986','HOLLOW',18,'V',NULL,NULL,NULL,0,0),('H1987','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1988','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1989','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1990','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1991','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1992','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1993','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1994','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1995','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H1996','Holo 11MM Decaration Mina Churi',19,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('H2040','HALF ROUND NAKSA ',19,'V',NULL,NULL,NULL,0,0),('H2101','hOLLOW',19,'U',NULL,NULL,NULL,0,0),('H2102','Hollow',18,'U',NULL,NULL,NULL,0,0),('H2103','Hollow',18,'U',NULL,NULL,NULL,0,0),('H2104','HOLLOW',18,'U',NULL,NULL,NULL,0,0),('H2105','HOLLOW',18,'U',NULL,NULL,NULL,0,0),('H2106','HOLLOW',18,'U',NULL,NULL,NULL,0,0),('H2113','Hollow',19,'U',NULL,NULL,NULL,0,0),('H2114','HOLLOW',18,'Q',NULL,NULL,NULL,0,0),('H2116','Hollow',19,'U',NULL,NULL,NULL,0,0),('I3101','THAKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('I3102','churi',4,'G',NULL,NULL,NULL,0,0),('I3103','churi',4,'G',NULL,NULL,NULL,0,0),('I3104','churi',4,'H',NULL,NULL,NULL,0,0),('I3105','churi',4,'G',NULL,NULL,NULL,0,0),('I3106','churi',4,'G',NULL,NULL,NULL,0,0),('L0001','BALA',3,'X',NULL,NULL,NULL,0,0),('L0002','BALA',3,'X',NULL,NULL,NULL,0,0),('L0003','BALA',3,'X',NULL,NULL,NULL,0,0),('L0004','BALA',3,'X',NULL,NULL,NULL,0,0),('L0005','BALA',3,'X',NULL,NULL,NULL,0,0),('L0006','BALA',3,'X',NULL,NULL,NULL,0,0),('L0007','BALA',3,'X',NULL,NULL,NULL,0,0),('L0008','BALA',3,'X',NULL,NULL,NULL,0,0),('L0009','BALA',3,'X',NULL,NULL,NULL,0,0),('L0010','BALA',3,'X',NULL,NULL,NULL,0,0),('L0011','BALA',3,'X',NULL,NULL,NULL,0,0),('L0012','BALA',3,'X',NULL,NULL,NULL,0,0),('L0013','BALA',3,'X',NULL,NULL,NULL,0,0),('L0014','BALA',3,'X',NULL,NULL,NULL,0,0),('L0015','BALA',3,'X',NULL,NULL,NULL,0,0),('L0016','BALA',3,'X',NULL,NULL,NULL,0,0),('L0017','BALA',3,'X',NULL,NULL,NULL,0,0),('L0018','Bala',3,'X',NULL,NULL,NULL,0,0),('L0019','BALA',3,'X',NULL,NULL,NULL,0,0),('L0020','bala',3,'X',NULL,NULL,NULL,0,0),('L0021','BALA',3,'X',NULL,NULL,NULL,0,0),('L0022','BALA',3,'X',NULL,NULL,NULL,0,0),('L0023','BALA',3,'X',NULL,NULL,NULL,0,0),('L0024','BALA',3,'X',NULL,NULL,NULL,0,0),('L0025','bala',3,'X',NULL,NULL,NULL,0,0),('L0026','BALA',3,'X',NULL,NULL,NULL,0,0),('L0027','BALA',3,'X',NULL,NULL,NULL,0,0),('L0028','Bala',3,'X',NULL,NULL,NULL,0,0),('L0029','BALA',4,'X',NULL,NULL,NULL,0,0),('L0030','BALA',4,'X',NULL,NULL,NULL,0,0),('L0031','BALA',4,'X',NULL,NULL,NULL,0,0),('L0032','BALA',4,'X',NULL,NULL,NULL,0,0),('L0040','BALA',3,'X',NULL,NULL,NULL,0,0),('L0041','BALA',3,'X',NULL,NULL,NULL,0,0),('L0043','BALA',3,'X',NULL,NULL,NULL,0,0),('L0044','BALA',3,'X',NULL,NULL,NULL,0,0),('L0045','BALA',3,'X',NULL,NULL,NULL,0,0),('L0046','BALA',3,'X',NULL,NULL,NULL,0,0),('L0047','BALA',3,'X',NULL,NULL,NULL,0,0),('L0048','BALA',3,'X',NULL,NULL,NULL,0,0),('L0049','BALA',3,'X',NULL,NULL,NULL,0,0),('L0050','BALA',3,'X',NULL,NULL,NULL,0,0),('L0051','BALA',3,'X',NULL,NULL,NULL,0,0),('L0052','BALA',3,'X',NULL,NULL,NULL,0,0),('L0053','BALA',3,'X',NULL,NULL,NULL,0,0),('L0054','BALA',3,'X',NULL,NULL,NULL,0,0),('L0055','BALA',3,'X',NULL,NULL,NULL,0,0),('L0056','BALA',3,'X',NULL,NULL,NULL,0,0),('L0057','bala',4,'X',NULL,NULL,NULL,0,0),('L0058','BALA',4,'X',NULL,NULL,NULL,0,0),('L0059','BALA',4,'X',NULL,NULL,NULL,0,0),('L0060','BALA',4,'X',NULL,NULL,NULL,0,0),('L0061','BALA',4,'X',NULL,NULL,NULL,0,0),('L0062','BALA',4,'X',NULL,NULL,NULL,0,0),('L0063','BALA',4,'X',NULL,NULL,NULL,0,0),('L0064','BALA',4,'X',NULL,NULL,NULL,0,0),('L0065','BALA',16,'X',NULL,NULL,NULL,0,0),('L0066','BALA',16,'X',NULL,NULL,NULL,0,0),('L0067','BALA',15,'X',NULL,NULL,NULL,0,0),('L0068','BALA',4,'X',NULL,NULL,NULL,0,0),('L0069','Bala Naksa',16,'X',NULL,NULL,NULL,0,0),('L0074','Soru Noksha Bala',4,'X',NULL,NULL,NULL,0,0),('L0075','BALA',4,'X',NULL,NULL,NULL,0,0),('L0087','Soru Naksha Bala',4,'X',NULL,NULL,NULL,0,0),('L0101','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0102','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0103','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0104','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0105','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0106','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0107','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0108','BALA',3,'Y',NULL,NULL,NULL,0,0),('L0109','MINA BALA',3,'Y',NULL,NULL,NULL,0,0),('L0110','BALA',3,'Y',NULL,NULL,NULL,0,0),('M0021','Mina Thokai Churi Soru',17,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0071','Thokai bangal mena churi majari',17,'H','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0261','Thokai dd mena churi majhari',17,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('M0263','Thokai dd mena churi majhari',17,'G','2011-01-14 19:04:48','sandip',NULL,1,0.05),('M0264','Mina Churi',17,'G','2011-01-12 19:14:34','sandip',NULL,1,0.05),('M0265','Thokai dd mena churi majhari',17,'G','2011-01-14 18:38:12','sandip',NULL,1,0.05),('M0266','Thokai dd Mina Churi Majhari',17,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('M0268','MINA',4,'H',NULL,NULL,NULL,0,0),('M0269','Thokai dd mena churi majhari',4,'I',NULL,NULL,NULL,0,0),('M0281','Thokai dd mena churi chowrah',17,'H','2011-01-10 18:50:08','sandip',NULL,1,0.05),('M0282','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:15:44','saheb',NULL,1,0.05),('M0283','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:17:59','saheb',NULL,1,0.05),('M0284','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:18:13','saheb',NULL,1,0.05),('M0285','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:17:02','saheb',NULL,1,0.05),('M0286','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:17:46','saheb',NULL,1,0.05),('M0287','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:17:35','saheb',NULL,1,0.05),('M0288','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:18:26','saheb',NULL,1,0.05),('M0289','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:18:36','saheb',NULL,1,0.05),('M0290','Thokai dd mena churi chowrah',17,'H','2011-01-29 12:17:23','saheb',NULL,1,0.05),('M0300','MINA CHURI',4,'H',NULL,NULL,NULL,0,0),('M0361','Thokai joypuri meena churi majhari',17,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0362','Thokai joypuri meena churi maghari',17,'H','2011-01-15 18:50:36','sandip',NULL,1,0.05),('M0364','Thokai joypuri meena churi majhari',17,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0366','Thokai joypuri meena churi majhari',17,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0367','Thokai joypuri meena churi maghari',17,'I','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0386','Thokai joypuri meena churi chowrah',17,'H','2011-02-04 19:07:37','sandip',NULL,1,0.05),('M0421','flat panching mena churi soru',17,'N','2011-01-15 18:47:36','sandip',NULL,1,0.05),('M0423','Flat Panching Meena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0424','Flat Panching Meena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0425','Flat Panching Mena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0426','Flat Panching Meena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0427','Flat Panching Meena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0428','Flat Panching Meena Churi Soru',17,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0429','flat panching mena churi soru',17,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('M0431','CHURI',3,'O',NULL,'sanjoy',NULL,1,0.05),('M0461','flat panching mena churi majhari ',17,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0462','Flat Panching Mina Churi Majhri ',4,'O','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('M0464','Flat Panching Meena Churi Majhari ',17,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0465','Flat Panching Meena Churi Majhari ',17,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0467','flat panching mena churi maghri ',4,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0488','flat panching mena churi chowrah',4,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0543','Half round panching mena churi maghari',17,'O','2041-02-05 00:00:00','Raja',NULL,1,0.05),('M0571','tashir panchin gmena churi soru',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0646','Machin chala khal panching mena decaration mini bowti maghari',17,'M','0000-00-00 00:00:00','saheb',NULL,1,0.05),('M0656','mechine chela panching mini bowti',4,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0716','Mina Thokai patla',10,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0717','Mina Thokai patla',10,'N','2011-01-09 11:40:19','sandip',NULL,1,0.05),('M0718','Mina thokai Patla ',10,'N','2010-11-20 15:34:18','b',NULL,1,0.05),('M0719','Mina Thokai patla',10,'N','2011-01-09 11:40:08','sandip',NULL,1,0.05),('M0727','Mina Thokai patla',10,'O','2011-01-09 16:34:20','sandip',NULL,1,0.05),('M0728','Thokai bangala patla mena chowrah',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0729','Mina Thokai patla',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0741','Mina Thokai patla',10,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0752','Thokai joypuri mena patla maghari',10,'N','2011-02-04 21:24:48','sandip',NULL,1,0.05),('M0753','Thokai joypuri mena patla maghari',10,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0754','Thokai joypuri mena patla maghari',10,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0761','Thokai joypuri mena patla maghari',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0762','Thokai joypuri mena patla chowrah',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0765','Thokai joypuri mena patla chowrah',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0776','Thokai dd mena patla soru',10,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0780','Thokai dd  patla maghari',14,'O',NULL,NULL,NULL,0,0),('M0786','Mina Thokai patla',10,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0787','Thokai dd mena patla soru',10,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0788','Thokai joypuri mena patla maghari',10,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0790','Mina Thokai patla',10,'M','0000-00-00 00:00:00','avik',NULL,1,0.05),('M0796','Mina Thokai patla',10,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0797','Thokai dd mena patla chowrah',10,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0798','Thokai dd mena patla chowrah',10,'Q','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0800','Thokai dd mena patla chowrah',14,'O',NULL,NULL,NULL,0,0),('M0851','Thokai Chowra Patla',10,'X','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0852','Thokai Chowra Patla',10,'X','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0853','Mina Patla',10,'X','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0916','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0917','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('M0918','Thokai bangala bowti  mena maghri',13,'N','2011-02-16 19:11:11','sanjoy',NULL,1,0.05),('M0919','Thokai bangala bowti  mena maghri',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0927','Thokai bangala bowti mena chowrah',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0952','Thokai joypuri mena bowti maghari',13,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M0954','Thokai joypuri mena bowti maghari',13,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M1066','Thikai DD mena konkon chwrah',15,'R','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M2026','13MM panching mina patla',17,'P','0000-00-00 00:00:00','sandip',NULL,1,0.05),('M2391','MINA PATLA',14,'M',NULL,NULL,NULL,0,0),('M2400','MINA PATLA',10,'N',NULL,NULL,NULL,0,0),('N0101','noa',16,'I',NULL,NULL,NULL,0,0),('N0102','noa',16,'I',NULL,NULL,NULL,0,0),('N0103','noa',16,'I',NULL,NULL,NULL,0,0),('N0104','noa',16,'I',NULL,NULL,NULL,0,0),('N0105','noa',16,'H',NULL,NULL,NULL,0,0),('N0106','noa',16,'I',NULL,NULL,NULL,0,0),('N0107','noa',16,'I',NULL,NULL,NULL,0,0),('N0108','noa',16,'I',NULL,NULL,NULL,0,0),('N0109','noa',16,'H',NULL,NULL,NULL,0,0),('N0110','noa',16,'I',NULL,NULL,NULL,0,0),('N2040','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2041','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2042','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2043','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2044','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2045','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2046','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2047','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2048','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2049','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2050','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2051','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2052','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N2053','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2054','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2055','HALF ROUND NAKSA ',18,'U',NULL,NULL,NULL,0,0),('N2056','HALF ROUND NAKSA ',19,'U',NULL,NULL,NULL,0,0),('N6001','NOA',4,'v',NULL,NULL,NULL,0,0),('N6002','NOA',4,'v',NULL,NULL,NULL,0,0),('N6003','NOA',4,'v',NULL,NULL,NULL,0,0),('N6004','NOA',4,'v',NULL,NULL,NULL,0,0),('N6005','Noa',4,'W',NULL,NULL,NULL,0,0),('N6006','NOA',4,'W',NULL,NULL,NULL,0,0),('N6007','NOA',4,'W',NULL,NULL,NULL,0,0),('N6008','NOA',4,'W',NULL,NULL,NULL,0,0),('N6009','NOA',4,'W',NULL,NULL,NULL,0,0),('N6010','NOA',4,'W',NULL,NULL,NULL,0,0),('N6011','NOA',4,'W',NULL,NULL,NULL,0,0),('N6012','NOA',4,'W',NULL,NULL,NULL,0,0),('N6013','NOA',4,'W',NULL,NULL,NULL,0,0),('N6014','NOA',4,'W',NULL,NULL,NULL,0,0),('N6015','NOA',4,'W',NULL,NULL,NULL,0,0),('N6016','NOA',4,'W',NULL,NULL,NULL,0,0),('N6017','NOA',4,'W',NULL,NULL,NULL,0,0),('N6018','NOA',4,'W',NULL,NULL,NULL,0,0),('N6019','NOA',4,'v',NULL,NULL,NULL,0,0),('N6020','NOA',4,'W',NULL,NULL,NULL,0,0),('N6021','NOA',4,'v',NULL,NULL,NULL,0,0),('N6022','NOA',4,'v',NULL,NULL,NULL,0,0),('N6023','NOA',4,'v',NULL,NULL,NULL,0,0),('N6024','NOA',4,'v',NULL,NULL,NULL,0,0),('N6025','NOA',4,'V',NULL,NULL,NULL,0,0),('N6026','NOA',4,'v',NULL,NULL,NULL,0,0),('N6027','NOA',4,'v',NULL,NULL,NULL,0,0),('N6028','New Model',3,'W',NULL,NULL,NULL,0,0),('N6029','baby',3,'W',NULL,NULL,NULL,0,0),('N6030','bangale',3,'W',NULL,NULL,NULL,0,0),('N6031','BANGAL',3,'W',NULL,NULL,NULL,0,0),('N6032','bangale',3,'W',NULL,NULL,NULL,0,0),('N6033','BANGALE',3,'W',NULL,NULL,NULL,0,0),('N6034','BANGALE',3,'W',NULL,NULL,NULL,0,0),('N6035','bangale',3,'W',NULL,NULL,NULL,0,0),('N6036','BANGALE',3,'W',NULL,NULL,NULL,0,0),('N6037','New Model',0,'U',NULL,NULL,NULL,0,0),('N6038','BANGALE',4,'v',NULL,NULL,NULL,0,0),('N6039','bangale',3,'W',NULL,NULL,NULL,0,0),('N6040','bangale',4,'W',NULL,NULL,NULL,0,0),('N6041','bangale',3,'W',NULL,NULL,NULL,0,0),('N6042','bangale',4,'W',NULL,NULL,NULL,0,0),('N6043','bangale',4,'W',NULL,NULL,NULL,0,0),('N6044','bangale',4,'W',NULL,NULL,NULL,0,0),('N6045','bangale',4,'W',NULL,NULL,NULL,0,0),('N6046','bangale',4,'W',NULL,NULL,NULL,0,0),('N6047','BANGLE',4,'W',NULL,NULL,NULL,0,0),('N6048','BANGLE',4,'W',NULL,NULL,NULL,0,0),('N6049','NOA',4,'W',NULL,NULL,NULL,0,0),('N6050','NOA',4,'W',NULL,NULL,NULL,0,0),('N6051','NOA',4,'W',NULL,NULL,NULL,0,0),('N6052','NOA',4,'W',NULL,NULL,NULL,0,0),('N6053','NOA',4,'W',NULL,NULL,NULL,0,0),('N6054','NOA',4,'W',NULL,NULL,NULL,0,0),('N6055','NOA',4,'W',NULL,NULL,NULL,0,0),('N6056','NOA',4,'W',NULL,NULL,NULL,0,0),('N6057','NOA',4,'W',NULL,NULL,NULL,0,0),('N6058','2 Tar Beki Nowa',16,'W',NULL,NULL,NULL,0,0),('N6059','Nowa',16,'W',NULL,NULL,NULL,0,0),('N6060','3 TAR BEKI NOWA',16,'W',NULL,NULL,NULL,0,0),('N6061','Mina 6025',16,'X',NULL,NULL,NULL,0,0),('N6062','Mina 6036',16,'X',NULL,NULL,NULL,0,0),('N6063','6032 Ar Mina Nowa',16,'X',NULL,NULL,NULL,0,0),('N6064','6034 Ar Mina Nowa',16,'X',NULL,NULL,NULL,0,0),('N6065','6055 Ar Mina Nowa',16,'X',NULL,NULL,NULL,0,0),('N6066','6047 Ar Mina Nowa',16,'X',NULL,NULL,NULL,0,0),('N6067','N6055 R mina',16,'X',NULL,NULL,NULL,0,0),('P111','PALA',12,'AA',NULL,NULL,NULL,0,0),('P112','PALA',12,'AA',NULL,NULL,NULL,0,0),('P113','PALA',12,'AA',NULL,NULL,NULL,0,0),('P114','PALA',12,'AA',NULL,NULL,NULL,0,0),('P115','PALA',12,'AA',NULL,NULL,NULL,0,0),('P116','Pala',12,'AA',NULL,NULL,NULL,0,0),('P117','Pala',12,'AA',NULL,NULL,NULL,0,0),('P118','PALA',12,'AA',NULL,NULL,NULL,0,0),('P119','PALA',12,'AA',NULL,NULL,NULL,0,0),('P120','PALA',12,'AA',NULL,NULL,NULL,0,0),('P121','PALA',12,'AA',NULL,NULL,NULL,0,0),('P122','PALA',12,'AA',NULL,NULL,NULL,0,0),('P123','PALA',12,'AA',NULL,NULL,NULL,0,0),('P124','PALA',12,'AA',NULL,NULL,NULL,0,0),('P125','PALA',12,'AA',NULL,NULL,NULL,0,0),('S0088','',5,'A','0000-00-00 00:00:00','a',NULL,1,0.05),('S8001','',5,'E','2010-06-07 16:13:36','sanjoy',NULL,1,0.05),('S8002','',5,'F','2010-06-07 16:13:55','sanjoy',NULL,1,0.05),('S8003','',5,'G','2010-06-07 16:14:09','sanjoy',NULL,1,0.05),('S8004','',5,'E','2010-06-07 16:14:27','sanjoy',NULL,1,0.05),('S8005','',5,'F','2010-06-07 16:14:31','sanjoy',NULL,1,0.05),('S8007','',5,'G','2010-06-07 16:16:36','sanjoy',NULL,1,0.05),('S8009','',5,'F','2010-06-07 16:18:15','sanjoy',NULL,1,0.05),('S8010','',5,'G','2010-06-07 16:18:40','sanjoy',NULL,1,0.05),('S8011','',5,'D','2010-06-07 16:19:19','sanjoy',NULL,1,0.05),('S8012','',5,'G','2010-06-07 16:19:31','sanjoy',NULL,1,0.05),('S8013','',5,'G','2010-06-07 16:19:33','sanjoy',NULL,1,0.05),('S8014','',5,'G','2010-06-07 16:19:39','sanjoy',NULL,1,0.05),('S8015','',5,'E','2010-06-07 16:19:59','sanjoy',NULL,1,0.05),('S8016','',5,'J','2010-06-07 16:20:08','sanjoy',NULL,1,0.05),('S8017','',5,'J','2010-06-07 16:20:14','sanjoy',NULL,1,0.05),('S8018','',5,'G','2010-06-07 16:20:22','sanjoy',NULL,1,0.05),('S8019','',5,'J','2010-06-07 16:20:29','sanjoy',NULL,1,0.05),('S8020','',5,'H','2010-06-07 16:20:40','sanjoy',NULL,1,0.05),('S8021','',5,'H','2010-06-07 16:21:12','sanjoy',NULL,1,0.05),('S8022','',5,'H','2010-06-07 16:21:14','sanjoy',NULL,1,0.05),('S8023','',5,'H','2010-06-07 16:21:15','sanjoy',NULL,1,0.05),('S8024','',5,'H','2010-06-07 16:21:17','sanjoy',NULL,1,0.05),('S8025','',5,'E','2010-06-07 16:21:33','sanjoy',NULL,1,0.05),('S8026','',5,'G','2010-06-07 16:21:47','sanjoy',NULL,1,0.05),('S8027','',5,'I','2010-06-07 16:21:55','sanjoy',NULL,1,0.05),('S8029','',5,'H','2010-06-07 16:22:16','sanjoy',NULL,1,0.05),('S8031','',5,'E','2010-06-07 16:22:53','sanjoy',NULL,1,0.05),('S8032','',5,'G','2010-06-07 16:23:18','sanjoy',NULL,1,0.05),('S8034','',5,'G','2010-06-07 16:23:29','sanjoy',NULL,1,0.05),('S8035','',5,'G','2010-06-07 16:23:36','sanjoy',NULL,1,0.05),('T3101','thokai churi',4,'G',NULL,NULL,NULL,0,0),('T3102','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T3103','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T3104','THOKAI CHURI',12,'H',NULL,NULL,NULL,0,0),('T3105','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T3106','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T3107','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T3108','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T3109','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T3110','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T3111','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T3112','New Model',12,'G',NULL,NULL,NULL,0,0),('T3113','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T3114','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3115','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3116','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3117','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3118','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3119','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3120','CHURI',4,'H',NULL,NULL,NULL,0,0),('T3121','CHURI',4,'H',NULL,NULL,NULL,0,0),('T3122','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3123','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3124','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T3125','CHURI',12,'G',NULL,NULL,NULL,0,0),('T3126','CHURI',12,'G',NULL,NULL,NULL,0,0),('T3129','churi',12,'H',NULL,NULL,NULL,0,0),('T3130','churi',12,'G',NULL,NULL,NULL,0,0),('T3131','churi',12,'G',NULL,NULL,NULL,0,0),('T3132','churi',12,'G',NULL,NULL,NULL,0,0),('T3133','churi',12,'G',NULL,NULL,NULL,0,0),('T3134','churi',12,'H',NULL,NULL,NULL,0,0),('T3135','churi',12,'G',NULL,NULL,NULL,0,0),('T3136','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('T3137','THOKAI',4,'H',NULL,NULL,NULL,0,0),('T3138','THOKAI',4,'H',NULL,NULL,NULL,0,0),('T3139','THOKAI',4,'G',NULL,NULL,NULL,0,0),('T3140','churi',12,'H',NULL,NULL,NULL,0,0),('T3141','churi',12,'G',NULL,NULL,NULL,0,0),('T3142','churi',12,'G',NULL,NULL,NULL,0,0),('T3143','churi',12,'G',NULL,NULL,NULL,0,0),('T3144','churi',12,'G',NULL,NULL,NULL,0,0),('T3145','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3146','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3147','CHURI',4,'G',NULL,NULL,NULL,0,0),('T3148','CHURI',4,'G',NULL,NULL,NULL,0,0),('T4901','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4902','Thokai Churi',12,'G','0000-00-00 00:00:00','b',NULL,1,0.05),('T4903','Thokai Churi',12,'H',NULL,NULL,NULL,0,0),('T4904','Thokai Churi',12,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('T4905','Thokai Churi',12,'G','2011-02-05 19:05:08','sandip',NULL,1,0.05),('T4906','Thokai Churi',12,'G','2011-02-04 21:06:51','sandip',NULL,1,0.05),('T4907','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4908','Thokai Churi',12,'G','2011-02-16 13:15:38','sandip',NULL,1,0.05),('T4909','Thokai Churi',12,'G','2011-02-05 19:05:53','sandip',NULL,1,0.05),('T4910','Thokai Churi',12,'G','2011-01-08 10:21:23','sandip',NULL,1,0.05),('T4911','Thokai Churi',12,'G','2011-01-08 10:20:57','sandip',NULL,1,0.05),('T4912','Thokai Churi',12,'G','2011-02-16 13:17:28','sandip',NULL,1,0.05),('T4913','Thokai Churi',12,'G','2011-01-29 15:30:50','saheb',NULL,1,0.05),('T4914','Thokai Churi',12,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('T4915','Thokai Churi',12,'G','2011-02-05 19:12:14','sandip',NULL,1,0.05),('T4916','churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4917','Churi',4,'G','2041-01-03 00:00:00','Raja',NULL,1,0.05),('T4918','Thokai Churi',12,'G','2011-01-30 12:05:54','sanjoy',NULL,1,0.05),('T4919','Thokai Churi',12,'G','2011-02-01 11:44:21','sandip',NULL,1,0.05),('T4920','Thokai Churi',12,'G','2011-02-09 16:47:29','sanjoy',NULL,1,0.05),('T4921','Thokai Churi',12,'G','2011-02-13 10:20:11','avik',NULL,1,0.05),('T4922','Thokai Churi',12,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('T4923','Thokai Churi',12,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('T4924','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4925','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4926','churi',4,'G','0000-00-00 00:00:00','sandip',NULL,1,0.05),('T4927','THOKAI CHURI',12,'G',NULL,NULL,NULL,0,0),('T4929','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4930','churi',4,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4931','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4932','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4933','churi',4,'H','2041-04-06 00:00:00','Raja',NULL,1,0.05),('T4934','Churi',4,'H','2041-08-03 00:00:00','sukanta',NULL,1,0.05),('T4935','churi',4,'G','2041-04-06 00:00:00','Raja',NULL,1,0.05),('T4936','churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4937','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4938','churi',4,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('T4939','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4940','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4941','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4942','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4943','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4944','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4945','Thokai Churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4946','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4947','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4948','THOKAI  CHURI',4,'H',NULL,NULL,NULL,0,0),('T4949','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4951','churi',4,'G',NULL,NULL,NULL,0,0),('T4952','Thokai Churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4953','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4954','THOKAI CHURI',4,'G',NULL,NULL,NULL,1,0.05),('T4956','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4957','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4958','THOKAI CHURI',4,'G',NULL,NULL,NULL,1,0.05),('T4959','thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4960','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4961','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4962','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4963','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4964','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4965','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4966','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4967','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4968','Thokai Churi',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4971','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4972','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('T4973','THOKAI CHURI',4,'G',NULL,NULL,NULL,1,0.05),('T4974','THOKAI CHURI',4,'G',NULL,NULL,NULL,1,0.05),('T4975','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4976','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T4977','Thokai Churi',4,'G','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('T4978','Thokai Churi',4,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4979','churi',4,'G','0000-00-00 00:00:00','saheb',NULL,1,0.05),('T4980','churi',4,'G','0000-00-00 00:00:00','saheb',NULL,1,0.05),('T4981','churi',4,'G','0000-00-00 00:00:00','saheb',NULL,1,0.05),('T4982','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4983','Thokai Churi',12,'H','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4984','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4985','Thokai Churi',12,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('T4986','Thokai Churi',4,'G',NULL,NULL,NULL,0,0),('T4987','thokai churi',12,'K',NULL,NULL,NULL,0,0),('T4990','New Model',4,'H',NULL,NULL,NULL,0,0),('T4991','New Model',0,'G',NULL,NULL,NULL,0,0),('T4992','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T4993','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T4994','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T4995','THOKAI CHURI',4,'G',NULL,NULL,NULL,0,0),('T4996','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('T4997','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X0001','PATLA',14,'I','2011-01-07 18:17:31','sandip',NULL,1,0.05),('X0002','Thokai Bangla Churi Soru ',4,'I','2011-01-09 15:19:13','sandip',NULL,1,0.05),('X0003','SAMPLE',16,'H','2011-01-10 09:49:49','sandip',NULL,1,0.05),('X0004','Sample',16,'W','2011-01-19 13:21:07','sandip',NULL,1,0.05),('X0005','Sample',16,'N','2011-01-23 14:26:06','sanjoy',NULL,1,0.05),('X0006','taser khal churi soru',16,'W','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0007','KANKAN',16,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0008','Sample',16,'W','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0009','Xsample',16,'X','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0010','Half round churi',16,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0011','3 tarar baki churi',16,'W','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0012','Xsample',16,'X','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0013','Xsample',16,'X','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0014','Xsample',16,'W','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0015','Xsample',16,'W','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0016','Xsample',16,'Q','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0017','Xsample',16,'W','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0018','Xsample',16,'X','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0019','Xsample',16,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0020','Xsample',16,'W','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0021','Xsample',16,'X','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0022','Xsample',16,'N','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0023','XSample',16,'W','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0024','XSample',16,'W','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0025','XSample',16,'W','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0026','Sample',16,'O','0000-00-00 00:00:00','sandip',NULL,1,0.05),('X0027','Xsample',16,'I','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0028','Xsample',16,'I','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0029','XSample',16,'X','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0030','XSample',16,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0031','XSample',16,'X','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0032','XSample',16,'W','2041-05-03 00:00:00','Raja',NULL,1,0.05),('X0033','Thokai Bangla Churi Soru ',4,'I','2041-06-09 00:00:00','Raja',NULL,1,0.05),('X0034','XSample',16,'M','2041-07-01 00:00:00','Raja',NULL,1,0.05),('X0035','XSample',16,'O','2041-09-05 00:00:00','Raja',NULL,1,0.05),('X0036','XSample',16,'G','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0037','sample',16,'N','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0038','Xsample',16,'G','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0039','Xsample',16,'K','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0040','Thokai bangla churi majhari',4,'H','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0041','Xsample',16,'N','0000-00-00 00:00:00','Raja',NULL,1,0.05),('X0050','X sample',16,'J','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0051','Thokai bangal churi majhari',4,'H',NULL,NULL,NULL,0,0),('X0052','Xsample',16,'R','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0053','Xsample',16,'R','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0054','Xsample',16,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('X0055','Thokai bangal churi majhari',4,'H','0000-00-00 00:00:00','sukanta',NULL,1,0.05),('X0056','Xsample',16,'R','0000-00-00 00:00:00','saheb',NULL,1,0.05),('X0057','Xsample',16,'V','0000-00-00 00:00:00','sanjoy',NULL,1,0.05),('X0070','Thokai bangal churi majhari',4,'I',NULL,NULL,NULL,0,0),('X0088','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('X0097','BOTHSIDE Thokai churi',4,'L',NULL,NULL,NULL,0,0),('X0100','FLAT CHURI',4,'I',NULL,NULL,NULL,0,0),('X0112','Machain chela khal bouty',4,'N',NULL,NULL,NULL,0,0),('X0170','Machin chala flat churi chowrah',4,'J',NULL,NULL,NULL,0,0),('X0196','Both Machin chala flat mena churi chowrah',4,'J',NULL,NULL,NULL,0,0),('X0219','BOTH SIDE',4,'I',NULL,NULL,NULL,0,0),('X0242','PLAZA BOTH SIDE',4,'I',NULL,NULL,NULL,0,0),('X0248','thokai dd churi  maghari',4,'K',NULL,NULL,NULL,0,0),('X0257','PLAZA',4,'I',NULL,NULL,NULL,0,0),('X0264','Mina Churi',4,'H',NULL,NULL,NULL,0,0),('X0271','thokai dd churi chowrah',4,'J',NULL,NULL,NULL,0,0),('X0277','thokai dd churi chowrah',4,'I',NULL,NULL,NULL,0,0),('X0278','DD PLAZA',4,'I',NULL,NULL,NULL,0,0),('X0282','Both Side Thokai dd mena churi chowrah',17,'I',NULL,NULL,NULL,0,0),('X0287','New Model',4,'I',NULL,NULL,NULL,0,0),('X0293','PLAZA BOTH SIDE',4,'J',NULL,NULL,NULL,0,0),('X0299','D.D CHURI',4,'J',NULL,NULL,NULL,0,0),('X0311','plaza',16,'I',NULL,NULL,NULL,0,0),('X0324','CHURI',4,'I',NULL,NULL,NULL,0,0),('X0336','Thokai joypuri churi maghari',4,'I',NULL,NULL,NULL,0,0),('X0338','THOKAI PLAZA',12,'J',NULL,NULL,NULL,0,0),('X0339','Thokai joypuri churi maghari',4,'I',NULL,NULL,NULL,0,0),('X0346','both side thokai churi',4,'I',NULL,NULL,NULL,0,0),('X0368','Thokai joypuri meena churi maghari',4,'I',NULL,NULL,NULL,0,0),('X0378','Thokai joypuri  churi chowrah',4,'I',NULL,NULL,NULL,0,0),('X0380','Thokai joypuri  churi chowrah',4,'J',NULL,NULL,NULL,0,0),('X0400','New Model',0,'M',NULL,NULL,NULL,0,0),('X0433','flat panching mena churi soru',4,'O',NULL,NULL,NULL,0,0),('X0436','FLAT CHURI',4,'O',NULL,NULL,NULL,0,0),('X0712','PATLA',14,'N',NULL,NULL,NULL,0,0),('X0725','PATLA',14,'O',NULL,NULL,NULL,0,0),('X0737','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('X0740','Thokai Patla',14,'M',NULL,NULL,NULL,0,0),('X0747','Thokai joypuri mena patla maghari',14,'N',NULL,NULL,NULL,0,0),('X0762','Thokai joypuri mena patla chowrah',10,'Q',NULL,NULL,NULL,0,0),('X0774','Thokai dd BOUTY soru',13,'N',NULL,NULL,NULL,0,0),('X0793','Thokai dd  patla chowrah',14,'R',NULL,NULL,NULL,0,0),('X0861','CHURI',4,'I',NULL,NULL,NULL,0,0),('X0868','churi',4,'K',NULL,NULL,NULL,0,0),('X0870','Thokai bangal churi chowrah',4,'K',NULL,NULL,NULL,0,0),('X1000','sample',4,'I',NULL,NULL,NULL,0,0),('X1001','HOLLOW',19,'Q',NULL,NULL,NULL,0,0),('X1002','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1003','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1004','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1005','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1006','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1007','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1008','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1009','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1010','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1011','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1012','HOLO',19,'Q',NULL,NULL,NULL,0,0),('X1116','panching bowti soru',13,'O',NULL,NULL,NULL,0,0),('X1421','3pol  khal panching churi soru',4,'I',NULL,NULL,NULL,0,0),('X1427','THOKAI CHURI',12,'I',NULL,NULL,NULL,0,0),('X1430','CHURI',4,'H',NULL,NULL,NULL,0,0),('X1500','SAMPLE',16,'H',NULL,NULL,NULL,0,0),('X1502','1 tarar baki churi',4,'H',NULL,NULL,NULL,0,0),('X1504','1 tarar baki churi',4,'J',NULL,NULL,NULL,0,0),('X1507','1 tarar panching baki churi',4,'I',NULL,NULL,NULL,0,0),('X1514','1 tarar mena baki churi',4,'H',NULL,NULL,NULL,0,0),('X1516','BOTH SIDE BEKI',4,'O',NULL,NULL,NULL,0,0),('X1517','Both side Beki',4,'O',NULL,NULL,NULL,0,0),('X1532','3 tarar baki churi',4,'O',NULL,NULL,NULL,0,0),('X1549','2 tarar mena baki churi',4,'M',NULL,NULL,NULL,0,0),('X1564','3 tarar baki churi',4,'Q',NULL,NULL,NULL,0,0),('X1566','BANKI',4,'R',NULL,NULL,NULL,0,0),('X1567','BANKI',4,'R',NULL,NULL,NULL,0,0),('X1591','Bekey Churi',4,'O',NULL,NULL,NULL,0,0),('X1592','CHURI',4,'N',NULL,NULL,NULL,0,0),('X1593','BANKI',4,'P',NULL,NULL,NULL,0,0),('X1599','CHURI',4,'T',NULL,NULL,NULL,0,0),('X1679','panjabi bala taser ',4,'O',NULL,NULL,NULL,0,0),('X1683','panjabi bala mena half round ',4,'P',NULL,NULL,NULL,0,0),('X1699','Khal Bala',4,'P',NULL,NULL,NULL,0,0),('X1701','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X1735','CHURI',4,'I',NULL,NULL,NULL,0,0),('X1743','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X1750','THOKAI CHURI',4,'J',NULL,NULL,NULL,0,0),('X1752','CHURI',4,'I',NULL,NULL,NULL,0,0),('X1788','churi',4,'I',NULL,NULL,NULL,0,0),('X1810','HOLO CHOWRA',19,'V',NULL,NULL,NULL,0,0),('X1816','Holo 6MM Decaration Churi',19,'V',NULL,NULL,NULL,0,0),('X2117','Hollow',19,'U',NULL,NULL,NULL,0,0),('X2118','Hollow',19,'U',NULL,NULL,NULL,0,0),('X2254','pATLA',14,'M',NULL,NULL,NULL,0,0),('X2260','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('X2279','PATLA',14,'N',NULL,NULL,NULL,0,0),('X2301','Thokai patla soru',14,'W',NULL,NULL,NULL,0,0),('X2313','PATLA',14,'M',NULL,NULL,NULL,0,0),('X2342','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('X2344','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('X2350','Thokai Patla',14,'N',NULL,NULL,NULL,0,0),('X2354','THOKAI PATLA',14,'O',NULL,NULL,NULL,0,0),('X2356','THOLAI PATLA',14,'O',NULL,NULL,NULL,0,0),('X2364','patla',14,'O',NULL,NULL,NULL,0,0),('X2375','PATLA BOTHSIDE',14,'O',NULL,NULL,NULL,0,0),('X2429','churi',4,'J',NULL,NULL,NULL,0,0),('X2440','Thokai Churi Bangla',4,'I',NULL,NULL,NULL,0,0),('X2479','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('X2481','Thokai Churi Bangla',4,'J',NULL,NULL,NULL,0,0),('X2486','Bothside Curi',12,'I',NULL,NULL,NULL,0,0),('X2487','Thokai Churi Bangla',4,'H',NULL,NULL,NULL,0,0),('X3026','churi',4,'H',NULL,NULL,NULL,0,0),('X3053','Thokai churi',4,'J',NULL,NULL,NULL,0,0),('X3082','THOKAI CHURI',4,'J',NULL,NULL,NULL,0,0),('X3084','THOKAI PLAZA',4,'J',NULL,NULL,NULL,0,0),('X3103','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X3104','Bothside churi',4,'I',NULL,NULL,NULL,0,0),('X3111','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X3113','Thokai Churi',4,'H',NULL,NULL,NULL,0,0),('X3115','CHURI',4,'H',NULL,NULL,NULL,0,0),('X3116','CHURI',4,'I',NULL,NULL,NULL,0,0),('X4000','New Model',16,'N',NULL,NULL,NULL,0,0),('X4001','New Model',16,'N',NULL,NULL,NULL,0,0),('X4003','CHURI',4,'H',NULL,NULL,NULL,0,0),('X4006','PLAZA',4,'I',NULL,NULL,NULL,0,0),('X4913','CHURI',4,'I',NULL,NULL,NULL,0,0),('X4920','THOKAI CHURI',4,'H',NULL,NULL,NULL,0,0),('X4938','churi',4,'H',NULL,NULL,NULL,0,0),('X4947','Thokai churi',4,'H',NULL,NULL,NULL,0,0),('X4965','CHURI',4,'I',NULL,NULL,NULL,0,0),('X4987','Thokai churi',12,'L',NULL,NULL,NULL,0,0),('X6019','NOA',4,'W',NULL,NULL,NULL,0,0),('X7013','BABY BANGLE',3,'I',NULL,NULL,NULL,0,0),('X7021','baby ',4,'W',NULL,NULL,NULL,0,0),('Y0001','BALA',19,'Y',NULL,NULL,NULL,0,0);

--
-- Table structure for table `product_size`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_size` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `prd_size` varchar(10) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_size`
--

INSERT INTO `product_size` (`ID`, `prd_size`) VALUES (5,'2-0-0'),(6,'2-0-5'),(7,'2-1-0'),(8,'2-1-5'),(9,'2-2-0'),(10,'2-2-5'),(11,'2-3-0'),(12,'2-3-5'),(13,'2-4-0'),(14,'2-4-5'),(15,'2-5-0'),(16,'2-5-5'),(17,'2-6-0'),(18,'2-6-5'),(19,'2-7-0'),(20,'2-7-5'),(21,'2-8-0'),(22,'2-8-5'),(23,'2-9-0'),(24,'2-9-5'),(25,'2-10-0'),(26,'2-10-5'),(27,'2-11-0'),(28,'2-11-5'),(29,'2-12-0'),(30,'2-12-5'),(31,'1-0-5'),(32,'1-15-0'),(33,'1-12-0\r\n\r\n'),(34,'2-13-0'),(35,'2-13-5');

--
-- Table structure for table `project_data`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `project_data` (
  `field_title` varchar(60) NOT NULL DEFAULT '',
  `field_value` varchar(200) DEFAULT NULL,
  `field_status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`field_title`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_data`
--

INSERT INTO `project_data` (`field_title`, `field_value`, `field_status`) VALUES ('backup_file','goldBackup',NULL),('backup_location','D:\\',NULL),('mysqldump_location','E:\\wamp\\bin\\mysql\\mysql5.1.36\\bin\\mysqldump.exe',NULL),('rar_location','',NULL),('rar_password','',NULL);

--
-- Table structure for table `project_variables`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `project_variables` (
  `var_name` varchar(30) NOT NULL,
  `var_value` double(11,4) DEFAULT 0.0000,
  `var_text` varchar(255) DEFAULT 'NONE',
  PRIMARY KEY (`var_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_variables`
--


--
-- Table structure for table `raw_materials`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `raw_materials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raw_materials`
--


--
-- Table structure for table `readymady_reference`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `readymady_reference` (
  `reference_id` varchar(256) NOT NULL DEFAULT '',
  `product_set` int(11) DEFAULT 0,
  `qty` int(11) DEFAULT 0,
  `gold` double DEFAULT 0,
  `total_weight` double DEFAULT 0,
  `tr_date` timestamp NULL DEFAULT NULL,
  `inforce` int(11) DEFAULT 1,
  PRIMARY KEY (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `readymady_reference`
--

INSERT INTO `readymady_reference` (`reference_id`, `product_set`, `qty`, `gold`, `total_weight`, `tr_date`, `inforce`) VALUES ('1001',1000,4000,5000,250000,'2014-10-16 06:45:00',0),('1002',1000,4000,5000,250000,'2017-03-27 18:15:00',0),('1003',1000,4000,5000,250000,'2017-08-18 18:30:00',1);

--
-- Table structure for table `report_job_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `report_job_master` (
  `job_id` int(11) NOT NULL DEFAULT 0,
  `order_id` varchar(255) DEFAULT NULL,
  `order_serial` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `pieces` int(11) DEFAULT NULL,
  `product_size` varchar(255) DEFAULT NULL,
  `job_date` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `expected_gold` double DEFAULT NULL,
  `p_loss` double DEFAULT NULL,
  `tr_date` int(11) DEFAULT 0,
  `tr_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `price_method` varchar(10) DEFAULT NULL,
  `price_code` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `gold_send` double DEFAULT NULL,
  `dal_send` double DEFAULT NULL,
  `pan_send` double DEFAULT NULL,
  `bronze_send` double DEFAULT NULL,
  `copper_send` double DEFAULT NULL,
  `gold_returned` double DEFAULT NULL,
  `dal_returned` double DEFAULT NULL,
  `pan_returned` double DEFAULT NULL,
  `bronze_returned` double DEFAULT NULL,
  `nitrick_returned` double DEFAULT NULL,
  `copper_return` double DEFAULT NULL,
  `product_wt` double DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `dal_id` int(11) DEFAULT NULL,
  `pan_id` int(11) DEFAULT NULL,
  `bronze_id` int(11) DEFAULT NULL,
  `copper_id` int(11) DEFAULT NULL,
  `markup_value` double DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_job_master`
--


--
-- Table structure for table `rm_category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rm_category` (
  `rm_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_cat_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`rm_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rm_category`
--

INSERT INTO `rm_category` (`rm_cat_id`, `rm_cat_name`) VALUES (1,'Gold'),(2,'Silver'),(3,'Copper'),(4,'Zinc'),(10,'Cadium'),(11,'Dal'),(20,'Bronze');

--
-- Table structure for table `rm_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rm_master` (
  `rm_ID` int(11) NOT NULL AUTO_INCREMENT,
  `rm_cat_id` int(11) DEFAULT NULL,
  `tech_name` varchar(255) DEFAULT NULL,
  `rm_name` varchar(255) DEFAULT NULL,
  `rm_gold` double DEFAULT 0,
  `rm_silver` double DEFAULT 0,
  `rm_copper` double DEFAULT 0,
  `rm_zinc` double DEFAULT 0,
  `rm_cadeam` double DEFAULT NULL,
  `submitable` int(11) DEFAULT 0,
  `bill_percentage` double DEFAULT 0,
  PRIMARY KEY (`rm_ID`),
  UNIQUE KEY `tech_name` (`tech_name`),
  KEY `rm_cat_id` (`rm_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rm_master`
--

INSERT INTO `rm_master` (`rm_ID`, `rm_cat_id`, `tech_name`, `rm_name`, `rm_gold`, `rm_silver`, `rm_copper`, `rm_zinc`, `rm_cadeam`, `submitable`, `bill_percentage`) VALUES (31,1,'29.13:26.99:35.63:8.25:Gold-Copper-Silver-Zinc-Bangle Pan','Bangle Pan',29.13,35.63,26.99,8.25,0,1,0.4),(32,1,'21.43:29.79:38.12:10.66:Gold-Copper-Silver-Zinc-Baby Pan','Baby Pan',21.43,38.12,29.79,10.66,0,1,0.4),(33,11,'41.7:50.04:8.26:Copper-Silver-Zinc-Dal Normal','Dal Normal',0,50.04,41.7,8.26,0,1,0),(34,1,'81.82:9.09:9.09:Gold-Copper-Cadeam-Kdm Light','Kdm Light',81.82,0,9.09,0,9.09,0,0),(35,1,'90.91:9.09:Gold-Cadeam-Kdm Hard (Solid)','Kdm Hard (Solid)',90.91,0,0,0,9.09,0,0),(36,1,'100:Gold-Pure Gold','Fine Gold',100,0,0,0,0,1,0),(37,3,'100:Copper-Pure Copper','Pure Copper',0,0,100,0,0,0,0),(38,2,'100:Silver-Pure Silver','Pure Silver',0,100,0,0,0,0,0),(39,4,'100:Zinc-Pure Zinc','Pure Zinc',0,0,0,100,0,0,0),(40,10,'100:Cadium-Pure Cadium','Pure Cadium',0,0,0,0,100,0,0),(41,1,'88:12:Gold-Copper-88.00 Guine','88.00 Guine',88,0,12,0,0,1,0),(42,1,'90:10:Gold-Copper-90Gunie','90Gunie',90,0,10,0,0,1,0),(44,20,'29:65:6:Gold-Copper-Silver-Spl. Bronze Abc','Bronze',0,0,0,0,0,1,0),(45,1,'76:12:4:6:2:Gold-Copper-Silver-Zinc-Cadium-Nitrick Spl.','Nitrick Gold.',89.5,0,8,0,0,0,0),(48,1,'92:8:Gold-Copper-Gold','92 Guine',92,0,8,0,0,1,0),(49,1,'89:11:Gold-other','Rough Gold',89,0,0,0,0,0,0);

--
-- Table structure for table `rm_opstock`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rm_opstock` (
  `rmop_id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_id` int(11) DEFAULT NULL,
  `op_date` datetime DEFAULT NULL,
  `op_stock` double DEFAULT NULL,
  `pure_gold` double DEFAULT 0,
  `minimum_level` double DEFAULT NULL,
  PRIMARY KEY (`rmop_id`),
  KEY `rm_id` (`rm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rm_opstock`
--


--
-- Table structure for table `rm_transaction`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rm_transaction` (
  `rmtr_ID` int(11) NOT NULL AUTO_INCREMENT,
  `rm_id` int(11) DEFAULT NULL,
  `tr_date` int(11) DEFAULT 0,
  `tr_time` datetime DEFAULT NULL,
  `tr_track` varchar(255) DEFAULT NULL,
  `tr_qty` double DEFAULT NULL,
  `tr_type` int(11) DEFAULT NULL,
  `tr_completed` int(11) DEFAULT NULL,
  `tr_comment` varchar(255) DEFAULT NULL,
  `updated` int(11) DEFAULT NULL,
  PRIMARY KEY (`rmtr_ID`),
  KEY `fk_rm_id` (`rm_id`),
  CONSTRAINT `fk_rm_id` FOREIGN KEY (`rm_id`) REFERENCES `rm_master` (`rm_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rm_transaction`
--


--
-- Table structure for table `salary_holder_salaries`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `salary_holder_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `salary_holder_id` bigint(20) unsigned NOT NULL,
  `year_number` int(11) NOT NULL,
  `month_number` int(11) NOT NULL,
  `base_salary` int(11) NOT NULL,
  `hourly_rate` int(11) NOT NULL DEFAULT 0,
  `monthly_deduction_amount` int(11) NOT NULL DEFAULT 0,
  `hour_deduction` int(11) NOT NULL DEFAULT 0,
  `hour_deduction_amount` int(11) NOT NULL DEFAULT 0,
  `extra_pay` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sh_id_year_month` (`salary_holder_id`,`year_number`,`month_number`),
  CONSTRAINT `salary_holder_salaries_salary_holder_id_foreign` FOREIGN KEY (`salary_holder_id`) REFERENCES `salary_holders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_holder_salaries`
--

INSERT INTO `salary_holder_salaries` (`id`, `salary_holder_id`, `year_number`, `month_number`, `base_salary`, `hourly_rate`, `monthly_deduction_amount`, `hour_deduction`, `hour_deduction_amount`, `extra_pay`, `created_at`, `updated_at`) VALUES (60,15,2022,7,16500,46,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(62,12,2022,7,20500,57,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(63,8,2022,7,15500,43,0,43,1849,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(64,9,2022,7,20500,57,0,72,4104,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(66,2,2022,7,10500,29,0,12,348,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(67,17,2022,7,16500,46,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(70,3,2022,7,12500,35,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(71,13,2022,7,20500,57,0,75,4275,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(72,20,2022,7,20500,57,0,11,627,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(75,4,2022,7,14500,40,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(76,16,2022,7,16500,46,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(78,19,2022,7,18500,51,0,24,1224,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(79,18,2022,7,17500,49,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(80,7,2022,7,14500,40,0,41,1640,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(82,5,2022,7,14500,40,0,24,960,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(83,11,2022,7,15500,43,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(84,6,2022,7,14500,40,0,0,0,0,'2022-08-08 08:04:15','2022-08-08 08:04:15'),(86,10,2022,7,16500,46,0,13,598,0,'2022-08-08 08:04:15','2022-08-08 08:04:15');

--
-- Table structure for table `salary_holder_salary_months`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `salary_holder_salary_months` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `year_number` int(11) NOT NULL,
  `month_number` int(11) NOT NULL,
  `is_done` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `year_month_unique` (`year_number`,`month_number`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_holder_salary_months`
--

INSERT INTO `salary_holder_salary_months` (`id`, `year_number`, `month_number`, `is_done`, `created_at`, `updated_at`) VALUES (1,2022,1,1,'2022-07-22 07:56:54','2022-07-22 07:56:54'),(2,2022,2,1,'2022-07-22 07:56:54','2022-07-22 07:56:54'),(3,2022,3,1,'2022-07-22 07:56:54','2022-07-22 07:56:54'),(4,2022,4,1,'2022-07-22 07:56:54','2022-07-22 07:56:54'),(5,2022,5,1,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(6,2022,6,1,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(7,2022,7,1,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(8,2022,8,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(9,2022,9,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(10,2022,10,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(11,2022,11,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(12,2022,12,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(13,2023,1,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(14,2023,2,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(15,2023,3,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(16,2023,4,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(17,2023,5,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(18,2023,6,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(19,2023,7,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(20,2023,8,0,'2022-07-22 07:56:55','2022-07-22 07:56:55'),(21,2023,9,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(22,2023,10,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(23,2023,11,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(24,2023,12,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(25,2024,1,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(26,2024,2,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(27,2024,3,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(28,2024,4,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(29,2024,5,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(30,2024,6,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(31,2024,7,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(32,2024,8,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(33,2024,9,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(34,2024,10,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(35,2024,11,0,'2022-07-22 07:56:56','2022-07-22 07:56:56'),(36,2024,12,0,'2022-07-22 07:56:56','2022-07-22 07:56:56');

--
-- Table structure for table `salary_holder_salary_payments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `salary_holder_salary_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `salary_holder_id` bigint(20) unsigned NOT NULL,
  `year_number` int(11) NOT NULL,
  `month_number` int(11) NOT NULL,
  `salary_paid` int(11) NOT NULL DEFAULT 0,
  `advance_adjusted` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_holder_salary_payments_salary_holder_id_foreign` (`salary_holder_id`),
  CONSTRAINT `salary_holder_salary_payments_salary_holder_id_foreign` FOREIGN KEY (`salary_holder_id`) REFERENCES `salary_holders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_holder_salary_payments`
--

INSERT INTO `salary_holder_salary_payments` (`id`, `salary_holder_id`, `year_number`, `month_number`, `salary_paid`, `advance_adjusted`, `created_at`, `updated_at`) VALUES (5,15,2022,7,16500,0,'2022-08-08 08:06:09','2022-08-08 08:06:09'),(7,12,2022,7,20500,0,'2022-08-08 08:06:37','2022-08-08 08:06:37'),(8,8,2022,7,13651,0,'2022-08-08 08:06:52','2022-08-08 08:06:52'),(9,9,2022,7,16396,0,'2022-08-08 08:07:04','2022-08-08 08:07:04'),(11,2,2022,7,10152,0,'2022-08-08 08:07:23','2022-08-08 08:07:23'),(12,17,2022,7,16500,0,'2022-08-08 08:07:32','2022-08-08 08:07:32'),(15,3,2022,7,12500,0,'2022-08-08 08:07:52','2022-08-08 08:07:52'),(16,13,2022,7,16225,0,'2022-08-08 08:07:59','2022-08-08 08:07:59'),(17,20,2022,7,19873,0,'2022-08-08 08:08:07','2022-08-08 08:08:07'),(20,4,2022,7,14500,0,'2022-08-08 08:08:28','2022-08-08 08:08:28'),(21,16,2022,7,16500,0,'2022-08-08 08:08:35','2022-08-08 08:08:35'),(23,19,2022,7,17276,0,'2022-08-08 08:08:50','2022-08-08 08:08:50'),(24,18,2022,7,17500,0,'2022-08-08 08:08:56','2022-08-08 08:08:56'),(25,7,2022,7,12860,0,'2022-08-08 08:09:03','2022-08-08 08:09:03'),(27,5,2022,7,13540,0,'2022-08-08 08:09:17','2022-08-08 08:09:17'),(28,11,2022,7,15500,0,'2022-08-08 08:09:26','2022-08-08 08:09:26'),(29,6,2022,7,14500,0,'2022-08-08 08:09:41','2022-08-08 08:09:41'),(31,10,2022,7,15902,0,'2022-08-08 08:09:58','2022-08-08 08:09:58');

--
-- Table structure for table `salary_holders`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `salary_holders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `salary_holder_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_holder_mailing_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary` int(11) NOT NULL DEFAULT 0,
  `advance` int(11) DEFAULT 0,
  `inforced` tinyint(4) NOT NULL DEFAULT 1,
  `show_in_salary_list` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salary_holders_salary_holder_name_unique` (`salary_holder_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_holders`
--

INSERT INTO `salary_holders` (`id`, `salary_holder_name`, `salary_holder_mailing_name`, `salary`, `advance`, `inforced`, `show_in_salary_list`, `created_at`, `updated_at`) VALUES (2,'Kaustav Das','Kaustav Das',10000,0,1,1,NULL,NULL),(3,'Pritam Sadhukhan','Pritam Sadhukhan',12000,0,1,1,NULL,NULL),(4,'Sana Das','Sana Das',12000,0,1,1,NULL,NULL),(5,'Suman Dutta','Suman Dutta',12000,0,1,1,NULL,NULL),(6,'Sushanta Chakrabroty','Sushanta Chakrabroty',13000,0,1,1,NULL,NULL),(7,'Sujit Das','Sujit Das',13000,44500,1,1,NULL,NULL),(8,'Biswajit Mondal','Biswajit Mondal',14000,0,1,1,NULL,NULL),(9,'Indrajit Sinha','Indrajit Sinha',16000,0,1,1,NULL,NULL),(10,'Tinku Paul','Tinku Paul',15000,0,1,1,NULL,NULL),(11,'Suranjan Dhar','Suranjan Dhar',13000,10000,1,1,NULL,NULL),(12,'Avik Guha','Avik Guha',17000,0,1,1,NULL,NULL),(13,'Rana Mondal','Rana Mondal',16000,0,1,1,NULL,NULL),(15,'Ananda Paul','Ananda Paul',15000,0,1,1,NULL,NULL),(16,'Sattya Manna','Sattya Manna',15000,0,1,1,NULL,NULL),(17,'Parimal Paul','Parimal Paul',15000,0,1,1,NULL,NULL),(18,'Sudarshan Mallick','Sudarshan Mallick',15000,0,1,1,NULL,NULL),(19,'Subhas Singha Roy','Subhas Singha Roy',16000,36000,1,1,NULL,NULL),(20,'Sabir Ali Mondal','Sabir Ali Mondal',18000,28000,1,1,NULL,NULL);

--
-- Table structure for table `sale_returns`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `sale_returns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gini_gold` double NOT NULL,
  `fine_gold` double NOT NULL,
  `gross_weight` double NOT NULL DEFAULT 0,
  `qty` int(11) NOT NULL,
  `lc` int(11) NOT NULL,
  `year_number` int(11) NOT NULL,
  `month_number` int(11) NOT NULL,
  `agent_id` varchar(50) CHARACTER SET utf8 NOT NULL,
  `customer_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_returns_agent_id_foreign` (`agent_id`),
  KEY `sale_returns_customer_id_foreign` (`customer_id`),
  CONSTRAINT `sale_returns_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`),
  CONSTRAINT `sale_returns_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customer_master` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_returns`
--


--
-- Table structure for table `simple_cust_balance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `simple_cust_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `balance_date` int(10) unsigned DEFAULT NULL,
  `gold_balance` double DEFAULT NULL,
  `lc_balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Uni_key_balance_date` (`balance_date`)
) ENGINE=MyISAM AUTO_INCREMENT=208 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `simple_cust_balance`
--


--
-- Table structure for table `stocktoemployees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `stocktoemployees` (
  `ste_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) DEFAULT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT 0,
  `tr_date` int(11) DEFAULT 0,
  `tr_time` datetime DEFAULT NULL,
  `tr_value` double DEFAULT NULL,
  `tr_type` int(11) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `inforce` int(11) DEFAULT NULL,
  PRIMARY KEY (`ste_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33552 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocktoemployees`
--


--
-- Table structure for table `subjects`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(20) DEFAULT NULL,
  `visible` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`, `visible`, `order`) VALUES (5,'Masters',1,10),(6,'Report',1,20),(7,'Transaction',1,30),(8,'Admin',1,40),(9,'Super',1,50),(10,'SERVER',1,50);

--
-- Table structure for table `system_variables`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `system_variables` (
  `variable_key` varchar(20) NOT NULL DEFAULT '',
  `variable_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`variable_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_variables`
--

INSERT INTO `system_variables` (`variable_key`, `variable_value`) VALUES ('bill_instruction_1','     ');

--
-- Table structure for table `table_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `table_status` (
  `status_ID` int(11) NOT NULL,
  `status_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`status_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_status`
--

INSERT INTO `table_status` (`status_ID`, `status_name`) VALUES (0,'Fresh'),(1,'Completed'),(2,'Deleted'),(3,'Updated'),(4,'Canceled'),(5,'Jobed'),(6,'WIP_phraseI'),(7,'WIP_phraseII'),(8,'Job Finished'),(9,'Billed'),(51,'PAN');

--
-- Table structure for table `tag_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tag_record` (
  `cust_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `bangle_wt` double DEFAULT NULL,
  `gold` double DEFAULT NULL,
  `lc` int(11) DEFAULT NULL,
  `ploss` double DEFAULT NULL,
  `batch_no` varchar(255) NOT NULL DEFAULT '',
  `price_code` varchar(255) DEFAULT NULL,
  `boxno` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`batch_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_record`
--


--
-- Table structure for table `tagprint`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `tagprint` (
  `Tag_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Tag_no` int(11) DEFAULT NULL,
  `price_code` varchar(255) DEFAULT NULL,
  `labour_charge` double DEFAULT NULL,
  `p_loss` double DEFAULT NULL,
  PRIMARY KEY (`Tag_ID`),
  KEY `price_code` (`price_code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tagprint`
--

INSERT INTO `tagprint` (`Tag_ID`, `Tag_no`, `price_code`, `labour_charge`, `p_loss`) VALUES (1,1001,'A',115,0.05),(2,1002,'B',120,0.06),(3,1003,'C',125,0.07),(4,1004,'D',130,0.08),(5,1005,'E',135,0.09),(6,1006,'F',140,0.1),(7,1007,'G',145,0.12),(8,1008,'H',150,0.14),(9,1009,'I',155,0.16),(10,10010,'J',160,0.18),(11,10011,'K',165,0.2),(12,10012,'L',170,0.22),(13,10013,'M',175,0.24),(14,10014,'N',180,0.26),(15,10015,'O',185,0.28),(16,10016,'P',290,0.3),(17,10017,'Q',295,0.3),(18,10018,'R',200,0.3),(19,10019,'S',205,0.3),(20,10020,'T',210,0.3),(21,10021,'U',215,0.4),(22,10022,'V',220,0.4),(23,10023,'W',225,0.4),(24,10024,'X',230,0.4),(25,10025,'Y',235,0.4),(26,10026,'Z',240,0.4);

--
-- Table structure for table `temp_customer_balance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_customer_balance` (
  `cust_id` varchar(50) CHARACTER SET utf8 NOT NULL,
  `gold_due` double DEFAULT NULL,
  `lc_due` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_customer_balance`
--

INSERT INTO `temp_customer_balance` (`cust_id`, `gold_due`, `lc_due`) VALUES ('S1',9.490999999999843,12520),('S10',27.55599999999997,9370),('S100',9.661000000000115,19930),('S101',7.169999999999973,4807),('S102',0.25700000000000145,1590),('S103',60.01000000000022,106970),('S104',15.798,4060),('S105',10.752999999999982,20),('S106',24.524000000000342,46520),('S107',30.365000000000236,129720),('S108',5.299000000000003,0),('S109',0,0),('S11',8.985000000000056,3590),('S110',3.3630000000000067,3120),('S111',0.000000000000014210854715202004,560),('S112',-0.000000000000007105427357601002,0),('S113',54.429999999999836,80129),('S114',1.0300000000000007,760),('S115',36.67900000000003,11290),('S116',14.03200000000001,13020),('S117',0.05299999999999727,7430),('S118',4.306000000000026,2460),('S119',13.137999999999991,1680),('S12',0,0),('S120',7.852,3550),('S121',4.6910000000000025,800),('S1217',-0.000000000000503597163969971,0),('S122',4.416999999999938,13840),('S123',2.1719999999999944,0),('S124',0.48799999999998533,400),('S125',6.820999999999994,10240),('S126',0,0),('S127',0.2520000000002369,23472),('S128',28.038999999999675,11860),('S129',0.07799999999998875,3500),('S13',13.574999999999676,13175),('S130',6.529999999999987,0),('S131',4.353,0),('S132',22.979999999999876,42260),('S133',5.593000000000001,0),('S134',0.000000000000021316282072803006,634),('S135',5.417999999999992,3722),('S136',0.000000000000014210854715202004,5500),('S137',32.94899999999973,18970),('S138',1.6960000000000548,6080),('S139',33.040000000000006,12340),('S14',5.033000000000001,2530),('S140',13.689999999999998,15040),('S141',8.824999999999939,9628),('S142',0.5300000000000011,160),('S143',18.215000000000146,24170),('S144',15.655999999999906,20180),('S145',4.949999999999996,0),('S146',0.00000000000002842170943040401,3600),('S147',60.95000000000073,172284),('S148',12.47599999999997,4932),('S149',46.369999999999976,8240),('S15',21.08099999999999,18410),('S150',5.54200000000003,1400),('S151',10.728000000000037,27160),('S152',6.4780000000000015,1860),('S153',1.2290000000000028,5990),('S154',3.879,0),('S155',4.525000000000002,1980),('S156',14.71400000000001,440),('S157',61.85599999999988,650),('S158',1.314,2850),('S159',8.162000000000063,11760),('S16',0.06399999999999295,7360),('S160',0.13299999999999557,7510),('S161',0.688000000000045,3990),('S162',3.9149999999999814,1820),('S163',42.16600000000028,50540),('S164',4.500000000000014,7720),('S165',4.598,3610),('S166',-0.000000000000014210854715202004,20870),('S167',7.289999999999999,1720),('S168',3.375,0),('S169',9.687999999999946,480),('S17',22.835000000000065,0),('S170',3.8160000000000007,1360),('S171',2.9849999999999994,910),('S172',15.15400000000006,2980),('S173',4.621000000000002,1450),('S174',0.00000000000003730349362740526,140),('S175',-0.28299999999998704,2420),('S176',8.491000000000007,1177),('S177',7.504999999999981,16680),('S178',1.4090000000000003,860),('S179',0.27000000000000135,1120),('S18',5.128999999999934,11420),('S180',7.531000000000176,8883),('S181',3.7460000000000235,2300),('S182',12.559999999999988,2020),('S183',0.015000000000002345,60),('S184',0.08999999999999986,1400),('S185',6.956999999999999,3384),('S186',-0.000000000000003552713678800501,690),('S187',0,0),('S188',0,0),('S189',6.170000000000016,11730),('S19',8.680000000000092,21817),('S190',-3.3306690738754696e-16,0),('S191',0.0049999999999705835,4890),('S192',9.990000000000052,16820),('S193',-0.0000000000000013322676295501878,0),('S194',0.0000000000000017763568394002505,171),('S195',12.422000000000594,90300),('S196',0,0),('S197',3.8799999999999955,4390),('S198',0,0),('S199',4.106999999999997,0),('S2',0.9879999999982658,1700),('S20',10.66100000000003,11592),('S200',2.385,0),('S201',1.4110000000000014,1960),('S202',0.6950000000000003,0),('S203',4.266000000000001,0),('S204',0.000000000000007105427357601002,760),('S205',14.046999999999997,14140),('S206',0,0),('S207',0,0),('S208',0.08999999999999986,0),('S209',14.645999999999901,24015),('S21',13.075999999999965,22840),('S210',0.6220000000000425,9110),('S211',5.44,0),('S212',0.000000000000003552713678800501,320),('S213',0.02999999999999936,0),('S214',5.745999999999988,10340),('S215',1.814,330),('S216',0.014000000000001123,520),('S217',0,0),('S218',0,0),('S219',0,0),('S22',68.8820000000001,400),('S220',0,0),('S221',5.424999999999969,1960),('S222',4.718999999999973,7171),('S223',1.793,90),('S224',4.440892098500626e-16,0),('S225',6.893000000000001,840),('S226',0.000000000000012434497875801753,5280),('S227',0.657999999999987,5060),('S228',5.157,2200),('S229',0.7819999999999823,17530),('S23',5.730999999999938,11310),('S230',9.047999999999973,14540),('S231',0,0),('S232',0,0),('S233',0.73,240),('S234',3.8050000000000015,0),('S235',40.918000000000006,2560),('S236',0,70),('S237',1.4810000000000247,760),('S238',10.511999999999986,9050),('S239',2.876000000000019,0),('S24',8.908999999999992,37595),('S240',4.692,4300),('S241',2.6300000000000026,240),('S242',1.7039999999999935,10628),('S243',1.6240000000000006,320),('S244',1.245,120),('S245',2.3130000000000024,11593),('S246',-0.000000000000003552713678800501,5480),('S247',1.916,0),('S248',3.282,0),('S249',13.89599999999993,26118),('S25',0.47699999999999676,0),('S250',8.582999999999913,18040),('S251',1.6180000000000003,0),('S252',3.019,960),('S253',11.295000000000357,25550),('S254',0.03799999999999848,2770),('S255',6.180999999999997,3100),('S256',2.369000000000085,6960),('S257',0.00000000000002842170943040401,4560),('S258',25.79099999999994,9810),('S259',31.31600000000094,151502),('S26',39.22399999999996,400),('s260',0.7540000000000049,2380),('S261',0.10800000000000276,60),('S262',9.781000000000006,15408),('S263',6.789999999999992,8900),('S264',6.177000000000003,1680),('S265',8.66,2230),('S266',2.7490000000000236,10540),('S267',-0.005999999999993122,1510),('S268',-0.0000000000005684341886080801,0),('S269',6.044999999999902,22476),('S27',32.19599999999929,7490),('S270',13.862999999999985,13760),('S271',1.8599999999999994,640),('S272',1.0000000000000242,540),('S273',0.18599999999999994,2450),('S274',0.037000000000002586,136),('S275',11.161000000000001,7140),('S276',9.965000000000003,920),('S277',0.019000000000001904,710),('S278',1.5090000000000714,43020),('S279',0,8105),('S28',8.34800000000001,3810),('S280',86.33600000000001,127889),('S281',14.924999999999983,20560),('S282',1.6009999999999218,21710),('S283',3.3259999999999983,2040),('S284',12.856999999999992,11280),('S285',12.542999999999992,11020),('S286',10.52600000000001,2140),('S287',2.265000000006694,900),('S288',17.962000000000046,28695),('S289',13.269000000000005,8572),('S29',8.935999999999893,11180),('S291',-0.000000000000007105427357601002,2442),('S292',15.046999999999983,14540),('S293',5.386999999999972,7650),('S294',-0.0000000000000017763568394002505,820),('S295',14.719000000000335,7600),('S296',0,0),('S297',0.6309999999999931,6620),('S298',0,0),('S299',15.82399999999997,23980),('S3',50.12299999999948,144990),('S30',0.00000000000004973799150320701,3042),('S300',0,0),('S301',0,0),('S302',11.14100000000019,86741),('S303',3.679000000000002,18703),('S304',1.1179999999999808,12493),('S305',2.6679999999999993,910),('S306',0.1410000000000018,4080),('S307',6.210000000000036,17360),('S308',0.0829999999999842,16140),('S309',0.010000000000001563,3280),('S31',0.000000000000014210854715202004,0),('S310',0.02400000000000091,2820),('S311',-0.000000000000014210854715202004,6169),('S312',3.939000000000007,23760),('S313',0.028999999999999915,2360),('S314',0,0),('S315',0,120),('S316',0.882000000000005,220),('S317',18.764999999999997,110),('S318',4.068999999999999,1360),('S319',-0.000000000000003552713678800501,0),('S32',1.1080000000000325,420),('S320',4.138000000000002,1000),('S321',0.03700000000002035,3170),('S322',3.009999999999998,4520),('S323',-3.295,1240),('S33',1.2560000000000002,0),('S34',23.28200000000001,38140),('S35',14.511999999999773,30341),('S36',16.935999999999964,2820),('S37',-0.00000000000001865174681370263,0),('S38',22.81299999999999,0),('S39',-0.020000000000010232,0),('S4',0.0000000000007318590178329032,0),('S40',-0.00000000000008526512829121202,2353),('S41',4.548000000000002,1440),('S42',0.00000000000005684341886080802,3420),('S43',-0.0000000000000017763568394002505,580),('S44',8.884999999999849,0),('S45',26.35199999999986,15260),('S46',-0.000000000000021316282072803006,120),('S47',-0.000000000000007105427357601002,10),('S48',2.3670000000000044,4540),('S49',-0.0000000000003979039320256561,0),('S5',39.717000000000056,9950),('S50',0.01900000000028257,6020),('S51',0.000000000000007105427357601002,0),('S52',11.033999999999981,1180),('S53',0.5980000000000985,5755),('S54',7.035000000000252,13790),('S55',-0.14499999999999602,7500),('S56',5.013999999999996,11020),('S57',3.808999999999969,37458),('S58',0.0010000000000189857,0),('S59',2.878999999999998,8650),('S6',16.916999999999916,12690),('S60',0.7040000000000006,1240),('S61',29.88000000000011,41450),('S62',-0.0000000000000017763568394002505,0),('S63',1.641999999999996,6360),('S64',-0.000000000000007105427357601002,310),('S65',26.24899999999998,22760),('S66',1.4309999999999974,6180),('S67',2.8529999999999642,0),('S68',33.82099999999957,39660),('S69',59.929000000000045,2900),('S7',7.509000000000128,107339),('S70',16.62199999999988,6425),('S71',27.98200000000014,45870),('S72',11.746000000000002,5990),('S73',4.750999999999991,9070),('S74',0.7700000000000014,0),('S75',13.438,620),('S76',18.22700000000001,6340),('S77',19.960000000000036,14310),('S78',26.381999999999493,66000),('S79',11.701000000000136,64450),('S8',33.22599999999998,8730),('S80',0.5930000000000746,0),('S81',10.177,3520),('S82',4.6080000000000005,2360),('S83',8.847000000000016,11010),('S84',14.040000000000028,2500),('S85',5.568,1240),('S86',9.829000000000004,8120),('S87',0,0),('S88',1.6859999999999786,14680),('S89',14.765,4880),('S9',14.639000000000735,34922),('S90',5.112000000000137,18920),('S91',52.89399999999994,17255),('S92',15.893000000000011,7140),('S93',0,0),('S94',-0.000000000000014210854715202004,560),('S95',4.600999999999999,11060),('S96',14.501999999999999,4440),('S97',-0.0000000000000017763568394002505,0),('S98',0.00000000000017053025658242404,23120),('S99',18.76499999999997,11300);

--
-- Table structure for table `temp_deleteable_jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_deleteable_jobs` (
  `job_id` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_deleteable_jobs`
--


--
-- Table structure for table `temp_item_transfer_ready_made`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_item_transfer_ready_made` (
  `tag` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `userkey` varchar(40) DEFAULT NULL,
  `model_no` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  `model_size` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `gold` double DEFAULT NULL,
  `lc` int(11) DEFAULT NULL,
  `gross_weight` double DEFAULT NULL,
  `package_weight` double DEFAULT NULL,
  `agent_id` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `tr_date` timestamp NOT NULL DEFAULT current_timestamp(),
  UNIQUE KEY `Uni_key_temp_trnasfer_entry` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_item_transfer_ready_made`
--


--
-- Table structure for table `temp_order`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_order` (
  `temp_order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(50) CHARACTER SET utf8 NOT NULL,
  `agent_id` varchar(50) CHARACTER SET utf8 NOT NULL,
  `product_code` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_key` varchar(255) CHARACTER SET utf8 NOT NULL,
  `qty` int(10) unsigned NOT NULL,
  `product_size` varchar(10) CHARACTER SET utf8 NOT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `price_code` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `gold_weight` double unsigned DEFAULT 0,
  `price` int(11) NOT NULL,
  `p_loss` double DEFAULT 0,
  `product_description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`temp_order_id`),
  UNIQUE KEY `Uni_key_duplicate_row` (`product_code`,`user_key`,`qty`,`product_size`,`gold_weight`,`rm_id`),
  KEY `cust_id` (`cust_id`,`agent_id`,`product_code`),
  KEY `agent_id` (`agent_id`),
  KEY `agent_id_2` (`agent_id`),
  KEY `product_code` (`product_code`),
  KEY `rm_id` (`rm_id`),
  CONSTRAINT `temp_order_ibfk_3` FOREIGN KEY (`cust_id`) REFERENCES `customer_master` (`cust_id`) ON UPDATE CASCADE,
  CONSTRAINT `temp_order_ibfk_4` FOREIGN KEY (`agent_id`) REFERENCES `agent_master` (`agent_id`) ON UPDATE CASCADE,
  CONSTRAINT `temp_order_ibfk_5` FOREIGN KEY (`product_code`) REFERENCES `product_master` (`product_code`) ON UPDATE CASCADE,
  CONSTRAINT `temp_order_ibfk_6` FOREIGN KEY (`rm_id`) REFERENCES `rm_master` (`rm_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5024 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_order`
--


--
-- Table structure for table `temp_price_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_price_master` (
  `price_code` varchar(55) CHARACTER SET utf8 DEFAULT NULL,
  `price_cat` int(11) NOT NULL DEFAULT 0,
  `price` bigint(20) DEFAULT NULL,
  `p_loss` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_price_master`
--

INSERT INTO `temp_price_master` (`price_code`, `price_cat`, `price`, `p_loss`) VALUES ('A',16,70,0.049),('B',16,80,0.059),('C',16,90,0.069),('D',16,100,0.079),('E',16,110,0.089),('F',16,120,0.099),('G',16,130,0.109),('H',16,140,0.119),('I',16,150,0.129),('J',16,160,0.139),('K',16,170,0.14900000000000002),('L',16,180,0.15899999999999997),('M',16,190,0.16899999999999998),('N',16,200,0.179),('O',16,210,0.189),('P',16,220,0.199),('Q',16,230,0.20900000000000002),('R',16,240,0.21899999999999997),('S',16,250,0.22899999999999998),('T',16,260,0.239),('U',16,270,0.249),('V',16,280,0.259),('W',16,290,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,45,0.049),('B',16,55,0.059),('C',16,65,0.069),('D',16,75,0.079),('E',16,85,0.089),('F',16,95,0.099),('G',16,105,0.109),('H',16,115,0.119),('I',16,125,0.129),('J',16,135,0.139),('K',16,145,0.14900000000000002),('L',16,155,0.15899999999999997),('M',16,165,0.16899999999999998),('N',16,175,0.179),('O',16,185,0.189),('P',16,195,0.199),('Q',16,205,0.20900000000000002),('R',16,215,0.21899999999999997),('S',16,225,0.22899999999999998),('T',16,235,0.239),('U',16,245,0.249),('V',16,255,0.259),('W',16,265,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,60,0.049),('B',16,70,0.059),('C',16,80,0.069),('D',16,90,0.079),('E',16,100,0.089),('F',16,110,0.099),('G',16,120,0.109),('H',16,130,0.119),('I',16,140,0.129),('J',16,150,0.139),('K',16,160,0.14900000000000002),('L',16,170,0.15899999999999997),('M',16,180,0.16899999999999998),('N',16,190,0.179),('O',16,200,0.189),('P',16,210,0.199),('Q',16,220,0.20900000000000002),('R',16,230,0.21899999999999997),('S',16,240,0.22899999999999998),('T',16,250,0.239),('U',16,260,0.249),('V',16,270,0.259),('W',16,280,0.269),('X',16,290,0.599),('Y',16,300,0.649),('Z',16,310,0.6990000000000001),('A',16,55,0.049),('B',16,65,0.059),('C',16,75,0.069),('D',16,85,0.079),('E',16,95,0.089),('F',16,105,0.099),('G',16,115,0.109),('H',16,125,0.119),('I',16,135,0.129),('J',16,145,0.139),('K',16,155,0.14900000000000002),('L',16,165,0.15899999999999997),('M',16,175,0.16899999999999998),('N',16,185,0.179),('O',16,195,0.189),('P',16,205,0.199),('Q',16,215,0.20900000000000002),('R',16,225,0.21899999999999997),('S',16,235,0.22899999999999998),('T',16,245,0.239),('U',16,255,0.249),('V',16,265,0.259),('W',16,275,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,0,0.049),('B',16,5,0.059),('C',16,15,0.069),('D',16,25,0.079),('E',16,35,0.089),('F',16,45,0.099),('G',16,55,0.109),('H',16,65,0.119),('I',16,75,0.129),('J',16,85,0.139),('K',16,95,0.14900000000000002),('L',16,105,0.15899999999999997),('M',16,115,0.16899999999999998),('N',16,125,0.179),('O',16,135,0.189),('P',16,145,0.199),('Q',16,155,0.20900000000000002),('R',16,165,0.21899999999999997),('S',16,175,0.22899999999999998),('T',16,185,0.239),('U',16,195,0.249),('V',16,205,0.259),('W',16,215,0.269),('X',16,175,0.599),('Y',16,200,0.649),('Z',16,225,0.6990000000000001),('A',16,-30,0.049),('B',16,-20,0.059),('C',16,-10,0.069),('D',16,0,0.079),('E',16,10,0.089),('F',16,20,0.099),('G',16,30,0.109),('H',16,40,0.119),('I',16,50,0.129),('J',16,60,0.139),('K',16,70,0.14900000000000002),('L',16,80,0.15899999999999997),('M',16,90,0.16899999999999998),('N',16,100,0.179),('O',16,110,0.189),('P',16,120,0.199),('Q',16,130,0.20900000000000002),('R',16,140,0.21899999999999997),('S',16,150,0.22899999999999998),('T',16,160,0.239),('U',16,170,0.249),('V',16,180,0.259),('W',16,190,0.269),('X',16,150,0.599),('Y',16,175,0.649),('Z',16,200,0.6990000000000001),('A',16,-15,0.049),('B',16,-5,0.059),('C',16,5,0.069),('D',16,15,0.079),('E',16,25,0.089),('F',16,35,0.099),('G',16,45,0.109),('H',16,55,0.119),('I',16,65,0.129),('J',16,75,0.139),('K',16,85,0.14900000000000002),('L',16,95,0.15899999999999997),('M',16,105,0.16899999999999998),('N',16,115,0.179),('O',16,125,0.189),('P',16,135,0.199),('Q',16,145,0.20900000000000002),('R',16,155,0.21899999999999997),('S',16,165,0.22899999999999998),('T',16,175,0.239),('U',16,185,0.249),('V',16,195,0.259),('W',16,205,0.269),('X',16,165,0.599),('Y',16,190,0.649),('Z',16,215,0.6990000000000001),('A',16,-20,0.049),('B',16,-10,0.059),('C',16,0,0.069),('D',16,10,0.079),('E',16,20,0.089),('F',16,30,0.099),('G',16,40,0.109),('H',16,50,0.119),('I',16,60,0.129),('J',16,70,0.139),('K',16,80,0.14900000000000002),('L',16,90,0.15899999999999997),('M',16,100,0.16899999999999998),('N',16,110,0.179),('O',16,120,0.189),('P',16,130,0.199),('Q',16,140,0.20900000000000002),('R',16,150,0.21899999999999997),('S',16,160,0.22899999999999998),('T',16,170,0.239),('U',16,270,0.249),('V',16,280,0.259),('W',16,200,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('AA',16,75,0.239),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375),('A',16,70,0.049),('B',16,80,0.059),('C',16,90,0.069),('D',16,100,0.079),('E',16,110,0.089),('F',16,120,0.099),('G',16,130,0.109),('H',16,140,0.119),('I',16,150,0.129),('J',16,160,0.139),('K',16,170,0.14900000000000002),('L',16,180,0.15899999999999997),('M',16,190,0.16899999999999998),('N',16,200,0.179),('O',16,210,0.189),('P',16,220,0.199),('Q',16,230,0.20900000000000002),('R',16,240,0.21899999999999997),('S',16,250,0.22899999999999998),('T',16,260,0.239),('U',16,270,0.249),('V',16,280,0.259),('W',16,290,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,45,0.049),('B',16,55,0.059),('C',16,65,0.069),('D',16,75,0.079),('E',16,85,0.089),('F',16,95,0.099),('G',16,105,0.109),('H',16,115,0.119),('I',16,125,0.129),('J',16,135,0.139),('K',16,145,0.14900000000000002),('L',16,155,0.15899999999999997),('M',16,165,0.16899999999999998),('N',16,175,0.179),('O',16,185,0.189),('P',16,195,0.199),('Q',16,205,0.20900000000000002),('R',16,215,0.21899999999999997),('S',16,225,0.22899999999999998),('T',16,235,0.239),('U',16,245,0.249),('V',16,255,0.259),('W',16,265,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,60,0.049),('B',16,70,0.059),('C',16,80,0.069),('D',16,90,0.079),('E',16,100,0.089),('F',16,110,0.099),('G',16,120,0.109),('H',16,130,0.119),('I',16,140,0.129),('J',16,150,0.139),('K',16,160,0.14900000000000002),('L',16,170,0.15899999999999997),('M',16,180,0.16899999999999998),('N',16,190,0.179),('O',16,200,0.189),('P',16,210,0.199),('Q',16,220,0.20900000000000002),('R',16,230,0.21899999999999997),('S',16,240,0.22899999999999998),('T',16,250,0.239),('U',16,260,0.249),('V',16,270,0.259),('W',16,280,0.269),('X',16,290,0.599),('Y',16,300,0.649),('Z',16,310,0.6990000000000001),('A',16,55,0.049),('B',16,65,0.059),('C',16,75,0.069),('D',16,85,0.079),('E',16,95,0.089),('F',16,105,0.099),('G',16,115,0.109),('H',16,125,0.119),('I',16,135,0.129),('J',16,145,0.139),('K',16,155,0.14900000000000002),('L',16,165,0.15899999999999997),('M',16,175,0.16899999999999998),('N',16,185,0.179),('O',16,195,0.189),('P',16,205,0.199),('Q',16,215,0.20900000000000002),('R',16,225,0.21899999999999997),('S',16,235,0.22899999999999998),('T',16,245,0.239),('U',16,255,0.249),('V',16,265,0.259),('W',16,275,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('A',16,0,0.049),('B',16,5,0.059),('C',16,15,0.069),('D',16,25,0.079),('E',16,35,0.089),('F',16,45,0.099),('G',16,55,0.109),('H',16,65,0.119),('I',16,75,0.129),('J',16,85,0.139),('K',16,95,0.14900000000000002),('L',16,105,0.15899999999999997),('M',16,115,0.16899999999999998),('N',16,125,0.179),('O',16,135,0.189),('P',16,145,0.199),('Q',16,155,0.20900000000000002),('R',16,165,0.21899999999999997),('S',16,175,0.22899999999999998),('T',16,185,0.239),('U',16,195,0.249),('V',16,205,0.259),('W',16,215,0.269),('X',16,175,0.599),('Y',16,200,0.649),('Z',16,225,0.6990000000000001),('A',16,-30,0.049),('B',16,-20,0.059),('C',16,-10,0.069),('D',16,0,0.079),('E',16,10,0.089),('F',16,20,0.099),('G',16,30,0.109),('H',16,40,0.119),('I',16,50,0.129),('J',16,60,0.139),('K',16,70,0.14900000000000002),('L',16,80,0.15899999999999997),('M',16,90,0.16899999999999998),('N',16,100,0.179),('O',16,110,0.189),('P',16,120,0.199),('Q',16,130,0.20900000000000002),('R',16,140,0.21899999999999997),('S',16,150,0.22899999999999998),('T',16,160,0.239),('U',16,170,0.249),('V',16,180,0.259),('W',16,190,0.269),('X',16,150,0.599),('Y',16,175,0.649),('Z',16,200,0.6990000000000001),('A',16,-15,0.049),('B',16,-5,0.059),('C',16,5,0.069),('D',16,15,0.079),('E',16,25,0.089),('F',16,35,0.099),('G',16,45,0.109),('H',16,55,0.119),('I',16,65,0.129),('J',16,75,0.139),('K',16,85,0.14900000000000002),('L',16,95,0.15899999999999997),('M',16,105,0.16899999999999998),('N',16,115,0.179),('O',16,125,0.189),('P',16,135,0.199),('Q',16,145,0.20900000000000002),('R',16,155,0.21899999999999997),('S',16,165,0.22899999999999998),('T',16,175,0.239),('U',16,185,0.249),('V',16,195,0.259),('W',16,205,0.269),('X',16,165,0.599),('Y',16,190,0.649),('Z',16,215,0.6990000000000001),('A',16,-20,0.049),('B',16,-10,0.059),('C',16,0,0.069),('D',16,10,0.079),('E',16,20,0.089),('F',16,30,0.099),('G',16,40,0.109),('H',16,50,0.119),('I',16,60,0.129),('J',16,70,0.139),('K',16,80,0.14900000000000002),('L',16,90,0.15899999999999997),('M',16,100,0.16899999999999998),('N',16,110,0.179),('O',16,120,0.189),('P',16,130,0.199),('Q',16,140,0.20900000000000002),('R',16,150,0.21899999999999997),('S',16,160,0.22899999999999998),('T',16,170,0.239),('U',16,270,0.249),('V',16,280,0.259),('W',16,200,0.269),('X',16,300,0.599),('Y',16,310,0.649),('Z',16,320,0.6990000000000001),('AA',16,75,0.239),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FI',16,150,0.255),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FJ',16,160,0.275),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FK',16,170,0.29500000000000004),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FL',16,180,0.315),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FM',16,190,0.335),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FN',16,200,0.35500000000000004),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375),('FO',16,210,0.375);

--
-- Table structure for table `temp_sale_ready_made`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_sale_ready_made` (
  `tag` varchar(40) CHARACTER SET utf8 NOT NULL,
  `userkey` varchar(40) DEFAULT NULL,
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_sale_ready_made`
--


--
-- Table structure for table `temp_tag_table`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_tag_table` (
  `tag` varchar(20) CHARACTER SET utf8 NOT NULL,
  `price-lc` decimal(15,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_tag_table`
--

INSERT INTO `temp_tag_table` (`tag`, `price-lc`) VALUES ('B1213',20.0000),('B1214',20.0000),('B1215',20.0000),('B1216',20.0000),('B1217',20.0000),('B1218',20.0000),('B1223',20.0000),('B1224',20.0000),('B1225',20.0000),('B1226',20.0000),('B1233',20.0000),('B1234',20.0000),('B1235',20.0000),('B1236',20.0000),('B1237',20.0000),('B1238',20.0000),('B1239',20.0000),('B1240',20.0000),('B1243',20.0000),('B1244',20.0000),('B1245',20.0000),('B1246',20.0000),('B1247',20.0000),('B1248',20.0000),('B1249',20.0000),('B1250',20.0000),('B1251',20.0000),('B1255',20.0000),('B1334',20.0000),('B1335',20.0000),('B1336',20.0000),('B1337',20.0000),('B1338',20.0000),('B1339',20.0000),('B1340',20.0000),('B1341',20.0000),('B1343',20.0000),('B1344',20.0000),('B1345',20.0000),('B1348',20.0000),('B1349',20.0000),('B1350',20.0000),('b4760',20.0000),('B5405',20.0000),('B5529',20.0000),('B5532',20.0000),('B5538',20.0000),('B5545',20.0000),('B5569',20.0000),('B5584',20.0000),('B5587',20.0000),('b5608',20.0000),('b5609',20.0000),('b5611',20.0000),('b5612',20.0000),('b5618',20.0000),('B5622',20.0000),('B5637',20.0000),('B5642',20.0000),('B5650',20.0000),('B5652',20.0000),('B5747',20.0000),('B5760',20.0000),('B5796',20.0000),('B5802',20.0000),('B5803',20.0000),('B5835',20.0000),('B5838',20.0000),('B5867',20.0000),('B5887',20.0000),('b5895',20.0000),('B5999',20.0000),('B6024',20.0000),('B6091',20.0000),('B6112',20.0000),('B6115',20.0000),('B6116',20.0000),('B6133',20.0000),('B6168',20.0000),('B6169',20.0000),('B6176',20.0000),('B6178',20.0000),('B6181',20.0000),('B6191',20.0000),('B6195',20.0000),('B6196',20.0000),('B6219',20.0000),('B6221',20.0000),('B6224',20.0000),('B6242',20.0000),('B6244',20.0000),('B6253',20.0000),('B6261',20.0000),('B6262',20.0000),('B6268',20.0000),('B6270',20.0000),('B6279',20.0000),('B6280',20.0000),('B6284',20.0000),('B6290',20.0000),('B6296',20.0000),('B6320',20.0000),('B6326',20.0000),('B6349',20.0000),('B6350',20.0000),('B6353',20.0000),('B6354',20.0000),('B6358',20.0000),('B6360',20.0000),('B6364',20.0000),('B6403',20.0000),('B6404',20.0000),('B6409',20.0000),('B6410',20.0000),('B6411',20.0000),('B6432',20.0000),('B6436',20.0000),('B6437',20.0000),('B6439',20.0000),('B6441',20.0000),('B6445',20.0000),('B6457',20.0000),('b6464',20.0000),('b6469',20.0000),('B7000',20.0000),('B7007',20.0000),('B7010',20.0000),('B7017',20.0000),('B7019',20.0000),('B7020',20.0000),('B7044',20.0000),('B7047',20.0000),('B7056',20.0000),('B7060',20.0000),('B7067',20.0000),('B7071',20.0000),('B7075',20.0000),('B7087',20.0000),('B7090',20.0000),('B7096',20.0000),('B7097',20.0000),('B7103',20.0000),('B1213',20.0000),('B1214',20.0000),('B1215',20.0000),('B1216',20.0000),('B1217',20.0000),('B1218',20.0000),('B1223',20.0000),('B1224',20.0000),('B1225',20.0000),('B1226',20.0000),('B1233',20.0000),('B1234',20.0000),('B1235',20.0000),('B1236',20.0000),('B1237',20.0000),('B1238',20.0000),('B1239',20.0000),('B1240',20.0000),('B1243',20.0000),('B1244',20.0000),('B1245',20.0000),('B1246',20.0000),('B1247',20.0000),('B1248',20.0000),('B1249',20.0000),('B1250',20.0000),('B1251',20.0000),('B1255',20.0000),('B1334',20.0000),('B1335',20.0000),('B1336',20.0000),('B1337',20.0000),('B1338',20.0000),('B1339',20.0000),('B1340',20.0000),('B1341',20.0000),('B1343',20.0000),('B1344',20.0000),('B1345',20.0000),('B1348',20.0000),('B1349',20.0000),('B1350',20.0000),('b4760',20.0000),('B5405',20.0000),('B5529',20.0000),('B5532',20.0000),('B5538',20.0000),('B5545',20.0000),('B5569',20.0000),('B5584',20.0000),('B5587',20.0000),('b5608',20.0000),('b5609',20.0000),('b5611',20.0000),('b5612',20.0000),('b5618',20.0000),('B5622',20.0000),('B5637',20.0000),('B5642',20.0000),('B5650',20.0000),('B5652',20.0000),('B5747',20.0000),('B5760',20.0000),('B5796',20.0000),('B5802',20.0000),('B5803',20.0000),('B5835',20.0000),('B5838',20.0000),('B5867',20.0000),('B5887',20.0000),('b5895',20.0000),('B5999',20.0000),('B6024',20.0000),('B6091',20.0000),('B6112',20.0000),('B6115',20.0000),('B6116',20.0000),('B6133',20.0000),('B6168',20.0000),('B6169',20.0000),('B6176',20.0000),('B6178',20.0000),('B6181',20.0000),('B6191',20.0000),('B6195',20.0000),('B6196',20.0000),('B6219',20.0000),('B6221',20.0000),('B6224',20.0000),('B6242',20.0000),('B6244',20.0000),('B6253',20.0000),('B6261',20.0000),('B6262',20.0000),('B6268',20.0000),('B6270',20.0000),('B6279',20.0000),('B6280',20.0000),('B6284',20.0000),('B6290',20.0000),('B6296',20.0000),('B6320',20.0000),('B6326',20.0000),('B6349',20.0000),('B6350',20.0000),('B6353',20.0000),('B6354',20.0000),('B6358',20.0000),('B6360',20.0000),('B6364',20.0000),('B6403',20.0000),('B6404',20.0000),('B6409',20.0000),('B6410',20.0000),('B6411',20.0000),('B6432',20.0000),('B6436',20.0000),('B6437',20.0000),('B6439',20.0000),('B6441',20.0000),('B6445',20.0000),('B6457',20.0000),('b6464',20.0000),('b6469',20.0000),('B7000',20.0000),('B7007',20.0000),('B7010',20.0000),('B7017',20.0000),('B7019',20.0000),('B7020',20.0000),('B7044',20.0000),('B7047',20.0000),('B7056',20.0000),('B7060',20.0000),('B7067',20.0000),('B7071',20.0000),('B7075',20.0000),('B7087',20.0000),('B7090',20.0000),('B7096',20.0000),('B7097',20.0000),('B7103',20.0000);

--
-- Table structure for table `temp_tags`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `temp_tags` (
  `tag` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_tags`
--


--
-- Table structure for table `transaction_table`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `transaction_table` (
  `tr_id` int(11) NOT NULL,
  `rm_id` int(11) DEFAULT NULL,
  `rm_value` double DEFAULT 0,
  `job_id` int(11) DEFAULT NULL,
  `tr_date` int(11) DEFAULT NULL,
  `tr_type` varchar(20) DEFAULT NULL,
  `inforce` int(11) DEFAULT 0,
  PRIMARY KEY (`tr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_table`
--


--
-- Table structure for table `transaction_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `transaction_types` (
  `transaction_type_id` int(11) NOT NULL DEFAULT 0,
  `transaction_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`transaction_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_types`
--

INSERT INTO `transaction_types` (`transaction_type_id`, `transaction_name`) VALUES (1,'Received from owner'),(2,'Transfer between employees');

--
-- Table structure for table `transactions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `transaction_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` bigint(20) unsigned NOT NULL,
  `asset_id` bigint(20) unsigned NOT NULL,
  `voucher_id` bigint(20) unsigned NOT NULL,
  `voucher_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_ledger_id_foreign` (`ledger_id`),
  KEY `transactions_asset_id_foreign` (`asset_id`),
  KEY `transactions_voucher_id_foreign` (`voucher_id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_ledger_id_foreign` FOREIGN KEY (`ledger_id`) REFERENCES `ledgers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--


--
-- Table structure for table `user_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `user_master` (
  `user_id` varchar(255) NOT NULL,
  `user_password_cancel` varchar(255) DEFAULT NULL,
  `md5_password` varchar(255) DEFAULT 'xxxxxx',
  `user_name` varchar(255) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_phone` varchar(12) DEFAULT NULL,
  `user_status` varchar(255) DEFAULT NULL,
  `user_rank` int(11) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `authorised_by` varchar(255) DEFAULT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `priv_value` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`user_id`, `user_password_cancel`, `md5_password`, `user_name`, `user_address`, `user_phone`, `user_status`, `user_rank`, `time_stamp`, `authorised_by`, `emp_id`, `priv_value`) VALUES ('ajay','ajay','5eac43aceba42c8757b54003a58277b5','ajay','bkp','000000','worker',2,'2019-09-21 00:00:00',NULL,85,15),('ananda',NULL,'5eac43aceba42c8757b54003a58277b5','ananda','bkp','000000','worker',2,NULL,NULL,67,15),('babai','babai','9065583973d18c64f3c30142a5fc7f8a','Babai Mali','bkp','8240844461','Worker',2,'2019-02-27 00:00:00','28',81,15),('biju','biju','1d683d2f77ebd646f11b4afe50d6f9ca','biju','ncp','9','Admin',1,NULL,NULL,58,15),('bile',NULL,'d93591bdf7860e1e4ee2fca799911215','Bile ghosh','bkp','9088666888','Admin',1,NULL,NULL,70,14),('biswajit','chandan','5eac43aceba42c8757b54003a58277b5','bubu','bkp','0000','worker',2,NULL,NULL,41,15),('bubu','bubu','5eac43aceba42c8757b54003a58277b5','bubu','bkp','00000','worker',2,NULL,'28',69,15),('chandan','951','5eac43aceba42c8757b54003a58277b5','pinki','bkp','00000000','worker',2,'2017-09-01 00:00:00',NULL,73,15),('deb','deb','5eac43aceba42c8757b54003a58277b5','deb','bkp','00000000','worker',2,NULL,NULL,90,15),('joy',NULL,'c2c8e798aecbc26d86e4805114b03c51','joy','bkp','00000','worker',2,NULL,NULL,84,15),('khokon','951','5eac43aceba42c8757b54003a58277b5','sukanta','bkp','0000','worker',2,'2017-09-01 00:00:00',NULL,74,15),('madhab',NULL,'d556cf67b37ddf89933278f72f18525a','madhab','bkp',NULL,'worker',2,NULL,NULL,82,15),('manager',NULL,'5d79099fcdf499f12b79770834c0164a','manoka','bkp',NULL,'worker',1,NULL,NULL,72,15),('manokauser','','81dc9bdb52d04dc20036dbd8313ed055','sukanta paul','Barrackpur','9051906728','Super Visor',2,NULL,NULL,33,14),('nayan','nayan','5eac43aceba42c8757b54003a58277b5','nayan','bkp','00000000','worker',2,NULL,NULL,89,15),('papai','india2day','12853c0a29c2fc1ccc76a052ceec426c','Arindam Ghosh','bkp','444444','Admin',1,NULL,NULL,46,15),('parimal',NULL,'5eac43aceba42c8757b54003a58277b5','parimal','Mohanpur',NULL,'worker',2,'2019-07-01 00:00:00',NULL,83,15),('pitam','pitam','81dc9bdb52d04dc20036dbd8313ed055','pitam','bkp','00000','admin',1,NULL,NULL,92,15),('poltu','poltu','5eac43aceba42c8757b54003a58277b5','paltu','bkp','00000000','worker',2,NULL,NULL,88,15),('rana','xxxx','5eac43aceba42c8757b54003a58277b5','Rana Mondal','bkp','9999','worker',2,NULL,NULL,50,15),('sabir',NULL,'5eac43aceba42c8757b54003a58277b5',NULL,NULL,NULL,NULL,2,'2018-05-19 00:00:00',NULL,76,15),('sagar','sagar','5eac43aceba42c8757b54003a58277b5','sagar','bkp','00000000','worker',2,NULL,NULL,87,15),('saheb','saheb','39cec6d4d21b5dade7544dab6881423e','Saheb Ghosh','bkp','0000','Admin',1,NULL,NULL,86,15),('sanjoy','sanjoy','912e79cd13c64069d91da65d62fbb78c','sanjoy','bkp','9748248814','worker',2,NULL,NULL,35,15),('sital',NULL,'5eac43aceba42c8757b54003a58277b5','ro','bkp','0000','worker',2,NULL,NULL,71,15),('sm','sales manager','12853c0a29c2fc1ccc76a052ceec426c','papai','bkp',NULL,'sm	',9,'2016-05-27 00:00:00',NULL,46,15),('sona',NULL,'5eac43aceba42c8757b54003a58277b5','aloke','bkp','0','worker',2,'2018-07-18 00:00:00',NULL,78,15),('sourav',NULL,'5eac43aceba42c8757b54003a58277b5','sourav','bkp',NULL,'worker',2,NULL,NULL,60,15),('subhash','subhash','5eac43aceba42c8757b54003a58277b5','subhash','bkp','0000','worker',2,NULL,NULL,42,15),('sujit',NULL,'81dc9bdb52d04dc20036dbd8313ed055','sujit','bkp','0000','worker',2,'2018-01-10 00:00:00',NULL,75,15),('surajit',NULL,'f83e1b7b65f57e17c414fb2853d028c7','Surajit Dhara','bkp','0000','worker',2,NULL,NULL,91,15),('tinku','xxx','5eac43aceba42c8757b54003a58277b5','RM','bkp','345345','worker',2,NULL,NULL,34,15),('vivek','vivek123','59402f50a4058ad1ed336e8dd1b11720','vivek','Mohanpoer','9836444999','Owner',1,NULL,NULL,28,131071);

--
-- Table structure for table `user_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `user_type` (
  `user_type_id` int(11) NOT NULL DEFAULT 0,
  `user_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`user_type_id`, `user_type`) VALUES (1,'Developer'),(2,'Admin'),(3,'Owner'),(5,'Employee'),(6,'Manager'),(7,'Special Manager');

--
-- Table structure for table `user_types`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `user_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`id`, `user_type_name`, `inforce`, `created_at`, `updated_at`) VALUES (1,'Owner',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(2,'Manager',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(3,'Manager Sales',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(4,'Manager Accounts',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(5,'Office Staff',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(6,'Worker',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(7,'Developer',1,'2021-08-30 08:07:49','2021-08-30 08:07:49'),(8,'Customer',1,'2021-08-30 08:07:50','2021-08-30 08:07:50'),(9,'Refinish',1,'2021-11-03 07:30:57','2021-11-03 07:30:57'),(10,'Petty Cash',1,'2021-11-03 07:30:57','2021-11-03 07:30:57');

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile1` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile2` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_type_id` bigint(20) unsigned NOT NULL DEFAULT 2,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_user_type_id_foreign` (`user_type_id`),
  CONSTRAINT `users_user_type_id_foreign` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `email`, `emp_id`, `password`, `remember_token`, `mobile1`, `mobile2`, `user_type_id`, `inforce`, `created_at`, `updated_at`) VALUES (1,'Vivekananda Ghosh','vivek',NULL,'$2y$10$/2bP5ULSeYNEGK0OPhAA2e24XDYEeyeIarDzFD3QtrlgELXn2dDWu',NULL,'9836444999','100',1,1,'2021-08-30 08:07:50','2022-10-19 08:35:09'),(2,'Arindam Ghosh','papaix',NULL,'$2y$10$UYxpN9tfCckpszztUwrBL.NWQcuMMCdJ9iV5YZxU.S0629ekm5ZnW',NULL,'9836444999','100',3,1,'2021-08-30 08:07:50','2021-08-30 08:07:50'),(3,'Vivekananda User','bile',NULL,'$2y$10$oFmVz8VasfFR3O0iapZg1OR59UcXZnShy9wsVPRJrM1LW/ueO91o.',NULL,'9836444999','100',3,1,'2021-08-30 08:07:50','2021-08-30 08:07:50'),(4,'Avik Guha','refinish',NULL,'$2y$10$NNKv7wz03NAHt4LRK4ZuYug5xd23L.xuy2mshEGVBUEZ/HJK4NEHe',NULL,'9836444999','100',9,1,'2021-11-03 07:30:57','2021-11-03 07:30:57'),(5,'Avik Guha','cash',NULL,'$2y$10$l.2d5BlbI/Lr0gmpawT/Vu4dZJ/NLJLWKMyr5bdQ7fKwTUxTGlggS',NULL,'9836444999','100',10,1,'2021-11-03 07:30:58','2021-11-03 07:30:58'),(6,'Manager','manager',NULL,'$2y$10$nC9w9NQeG/BSen2YTPjCBuxAbX0JvyTvQ.xCfywqTja.WNpHftJn6',NULL,'00000000','100',2,1,'2022-07-07 18:30:00','2022-10-19 08:31:13'),(7,'Sukanta Hui','developer',NULL,'$2y$10$A/TNo1juwiuyu8XmUoFN.OPqtySdovU23WGAl93Id.V5faJNxi41a',NULL,'7003756860','9830371685',7,1,'2022-11-29 07:52:27','2022-11-29 07:52:27');

--
-- Table structure for table `vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `voucher_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inforce` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

INSERT INTO `vouchers` (`id`, `voucher_name`, `inforce`, `created_at`, `updated_at`) VALUES (1,'Receipt',1,'2021-11-03 07:30:59','2021-11-03 07:30:59'),(2,'Payment',1,'2021-11-03 07:31:00','2021-11-03 07:31:00');

--
-- Table structure for table `wastage_master`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `wastage_master` (
  `price_id` int(11) NOT NULL AUTO_INCREMENT,
  `price_code` varchar(255) DEFAULT NULL,
  `price_cat` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `p_loss` double DEFAULT NULL,
  `time_stam` datetime DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `price_id` (`price_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wastage_master`
--

INSERT INTO `wastage_master` (`price_id`, `price_code`, `price_cat`, `price`, `p_loss`, `time_stam`, `user_id`) VALUES (1,'A',0,0,0.001,NULL,NULL),(2,'B',0,11,2,NULL,NULL),(3,'C',0,12,44,NULL,NULL),(4,'D',0,10.5,0,NULL,NULL),(5,'E',0,32,0,NULL,NULL);

--
-- Temporary view structure for view `xyz_temp_view`
--

SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `xyz_temp_view` AS SELECT 
 1 AS `cust_id`,
 1 AS `bill_month`,
 1 AS `lc`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'ses_gold'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `acronym`(str text) RETURNS text CHARSET utf8
    DETERMINISTIC
begin
    declare result text default '';
    set result = initials( str, '[[:alnum:]]' );
    return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `dstodate`(n1 INT) RETURNS date
    DETERMINISTIC
BEGIN 
RETURN date_add(STR_TO_DATE('01,01,1900','%d,%m,%Y'),interval n1-2 day);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_commission_year_and_month`(in_agent_id varchar(255),in_year int,in_month int) RETURNS double
    DETERMINISTIC
BEGIN
  DECLARE temp_salary double;
  DECLARE temp_commission double;
	DECLARE temp_total_salary double;
  DECLARE temp_agent_category_id int;
  declare temp_qty int;
  declare return_qty int;
  declare temp_ta int;
  set temp_qty=0;
  set return_qty=0;
  set temp_salary=0;
  set temp_commission=0;
  set temp_total_salary=0;
  set temp_qty=0;
  select agent_category_id into temp_agent_category_id  from agent_master where agent_id=in_agent_id;
  IF isnull(temp_agent_category_id) then
    set temp_total_salary=-1;
  END IF;
  
  select ifnull(sum(bill_details.qty),0) into temp_qty  from bill_master
      inner join bill_details on bill_details.bill_no = bill_master.bill_no
      inner join agent_to_customer on bill_master.cust_id = agent_to_customer.cust_id
      where 
      date(bill_master.tr_time)>=DATE(CONCAT_WS('-', in_year, in_month, 1)) 
      and 
      date(bill_master.tr_time)<=COALESCE(DATE(CONCAT_WS('-', in_year, in_month, 31)),DATE(CONCAT_WS('-', in_year, in_month, 30)), DATE(CONCAT_WS('-', in_year, in_month, 29)), DATE(CONCAT_WS('-', in_year, in_month, 28)))
      and agent_to_customer.agent_id=in_agent_id;
      
  set return_qty=get_agent_sale_return_qty_year_and_month(in_agent_id,in_year, in_month);
  set temp_qty=temp_qty-return_qty;
  -- when first category
  if temp_agent_category_id =2 then
    
     
--     if temp_qty>=0 and temp_qty <=30 then
--       set temp_salary=7000;
--     end if;
--     if temp_qty>=31 and temp_qty <=35 then
--       set temp_salary=8000;
--     end if;
--     if temp_qty>=36 and temp_qty <=40 then
--       set temp_salary=9000;
--     end if;
--     if temp_qty>=41 and temp_qty <=45 then
--       set temp_salary=10000;
--     end if;
    if temp_qty>=0 and temp_qty <=50 then
      set temp_commission=temp_qty*270;
    end if;
    
    if temp_qty>=51 and temp_qty <=60 then
      set temp_commission=13500+((temp_qty-50)*255);
    end if;
    
    if temp_qty>=61 and temp_qty <=70 then
      set temp_commission=16050+((temp_qty-60)*240);
    end if;
    
    if temp_qty>=71 and temp_qty <=80 then
      set temp_commission=18450+((temp_qty-70)*225);
    end if;
    
    if temp_qty>=81 and temp_qty <=90 then
      set temp_commission=20700+((temp_qty-80)*210);
    end if;
    
    if temp_qty>=91 and temp_qty <=100 then
      set temp_commission=22800+((temp_qty-90)*195);
    end if;
    
    if temp_qty>=101 and temp_qty <=110 then
      set temp_commission=24750+((temp_qty-100)*180);
    end if;
    
    if temp_qty>=111 and temp_qty <=120 then
      set temp_commission=26550+((temp_qty-110)*165);
    end if;
    
    if temp_qty>=121 and temp_qty <=130 then
      set temp_commission=28200+((temp_qty-120)*150);
    end if;
    
    if temp_qty>=131 and temp_qty <=140 then
      set temp_commission=29700+((temp_qty-130)*135);
    end if;
    
    if temp_qty>=141 and temp_qty <=150 then
      set temp_commission=31050+((temp_qty-140)*120);
    end if;
    
    if temp_qty>=151 and temp_qty <=160 then
      set temp_commission=32250+((temp_qty-150)*105);
    end if;
    
    if temp_qty>=161 and temp_qty <=170 then
      set temp_commission=33300+((temp_qty-160)*90);
    end if;
    
    if temp_qty>=171 and temp_qty <=180 then
      set temp_commission=34200+((temp_qty-170)*75);
    end if;
    
    if temp_qty>=181 and temp_qty <=190 then
      set temp_commission=34950+((temp_qty-180)*60);
    end if;
    
    if temp_qty>=191 and temp_qty <=200 then
      set temp_commission=35550+((temp_qty-190)*45);
    end if;
    
    if temp_qty>=201 and temp_qty <=210 then
      set temp_commission=36000+((temp_qty-200)*255);
    end if;
    
    if temp_qty>=211 and temp_qty <=220 then
      set temp_commission=38550+((temp_qty-211)*240);
    end if;
    
    if temp_qty>=221 and temp_qty <=230 then
      set temp_commission=40950+((temp_qty-220)*225);
    end if;
    
    if temp_qty>=231 and temp_qty <=240 then
      set temp_commission=43200+((temp_qty-230)*210);
    end if;
    
    if temp_qty>=241 and temp_qty <=250 then
      set temp_commission=45300+((temp_qty-240)*195);
    end if;
    
    if temp_qty>=251 and temp_qty <=260 then
      set temp_commission=47250+((temp_qty-250)*180);
    end if;
    
    if temp_qty>=261 and temp_qty <=270 then
      set temp_commission=49050+((temp_qty-260)*165);
    end if;
    
    if temp_qty>=271 and temp_qty <=280 then
      set temp_commission=50700+((temp_qty-270)*150);
    end if;
    
    if temp_qty>=281 and temp_qty <=290 then
      set temp_commission=52200+((temp_qty-280)*135);
    end if;
    
    if temp_qty>=291 and temp_qty <=300 then
      set temp_commission=53550+((temp_qty-290)*120);
    end if;
    
    if temp_qty>=301 and temp_qty <=310 then
      set temp_commission=54750+((temp_qty-300)*105);
    end if;
    
    if temp_qty>=311 and temp_qty <=320 then
      set temp_commission=55800+((temp_qty-310)*90);
    end if;
    
    if temp_qty>=321 and temp_qty <=330 then
      set temp_commission=56700+((temp_qty-320)*75);
    end if;
    
    if temp_qty>=331 and temp_qty <=340 then
      set temp_commission=57450+((temp_qty-330)*60);
    end if;
    
    if temp_qty>=341 and temp_qty <=350 then
      set temp_commission=58050+((temp_qty-340)*45);
    end if;
    
    if temp_qty>=351 and temp_qty <=360 then
      set temp_commission=58500+((temp_qty-350)*255);
    end if;
    
    if temp_qty>=361 and temp_qty <=370 then
      set temp_commission=61050+((temp_qty-350)*240);
    end if;
    
    if temp_qty>=371 and temp_qty <=380 then
      set temp_commission=63450+((temp_qty-370)*225);
    end if;
    
    if temp_qty>=381 and temp_qty <=390 then
      set temp_commission=65700+((temp_qty-380)*210);
    end if;
    
    if temp_qty>=391 and temp_qty <=400 then
      set temp_commission=67800+((temp_qty-390)*195);
    end if;
    
    if temp_qty>=401 and temp_qty <=410 then
      set temp_commission=69750+((temp_qty-400)*180);
    end if;
    
    
  end if;
  
  
  
  
  -- when special category
  if temp_agent_category_id =6 then
    
    if temp_qty>=46 and temp_qty <=50 then
      set temp_commission=temp_qty*285;
    end if;
    
    if temp_qty>=51 and temp_qty <=60 then
      set temp_commission=14250+((temp_qty-50)*270);
    end if;
    
    if temp_qty>=61 and temp_qty <=70 then
      set temp_commission=16950+((temp_qty-60)*255);
    end if;
    
    if temp_qty>=71 and temp_qty <=80 then
      set temp_commission=19500+((temp_qty-70)*240);
    end if;
    
    if temp_qty>=81 and temp_qty <=90 then
      set temp_commission=21900+((temp_qty-80)*225);
    end if;
    
    if temp_qty>=91 and temp_qty <=100 then
      set temp_commission=24150+((temp_qty-90)*210);
    end if;
    
    if temp_qty>=101 and temp_qty <=110 then
      set temp_commission=26250+((temp_qty-100)*195);
    end if;
    
    if temp_qty>=111 and temp_qty <=120 then
      set temp_commission=28200+((temp_qty-110)*180);
    end if;
    
    if temp_qty>=121 and temp_qty <=130 then
      set temp_commission=30000+((temp_qty-120)*165);
    end if;
    
    if temp_qty>=131 and temp_qty <=140 then
      set temp_commission=31650+((temp_qty-130)*150);
    end if;
    
    if temp_qty>=141 and temp_qty <=150 then
      set temp_commission=33150+((temp_qty-140)*135);
    end if;
    
    if temp_qty>=151 and temp_qty <=160 then
      set temp_commission=34500+((temp_qty-150)*120);
    end if;
    
    if temp_qty>=161 and temp_qty <=170 then
      set temp_commission=35700+((temp_qty-160)*105);
    end if;
    
    if temp_qty>=171 and temp_qty <=180 then
      set temp_commission=36750+((temp_qty-170)*90);
    end if;
    
    if temp_qty>=181 and temp_qty <=190 then
      set temp_commission=37650+((temp_qty-180)*75);
    end if;
    
    if temp_qty>=191 and temp_qty <=200 then
      set temp_commission=38400+((temp_qty-190)*60);
    end if;
    
    if temp_qty>=201 and temp_qty <=210 then
      set temp_commission=39000+((temp_qty-200)*285);
    end if;
    
    if temp_qty>=211 and temp_qty <=220 then
      set temp_commission=41850+((temp_qty-210)*270);
    end if;
    
    if temp_qty>=221 and temp_qty <=230 then
      set temp_commission=44550+((temp_qty-220)*255);
    end if;
    
    if temp_qty>=231 and temp_qty <=240 then
      set temp_commission=47100+((temp_qty-230)*240);
    end if;
    
    if temp_qty>=241 and temp_qty <=250 then
      set temp_commission=49500+((temp_qty-240)*225);
    end if;
    
    if temp_qty>=251 and temp_qty <=260 then
      set temp_commission=51750+((temp_qty-250)*210);
    end if;
    
    if temp_qty>=261 and temp_qty <=270 then
      set temp_commission=53850+((temp_qty-260)*195);
    end if;
    
    if temp_qty>=271 and temp_qty <=280 then
      set temp_commission=55800+((temp_qty-270)*180);
    end if;
    
    if temp_qty>=281 and temp_qty <=290 then
      set temp_commission=57600+((temp_qty-280)*165);
    end if;
    
    if temp_qty>=291 and temp_qty <=300 then
      set temp_commission=59250+((temp_qty-290)*150);
    end if;
    
    if temp_qty>=301 and temp_qty <=310 then
      set temp_commission=60750+((temp_qty-300)*135);
    end if;
    
    if temp_qty>=311 and temp_qty <=320 then
      set temp_commission=62100+((temp_qty-310)*120);
    end if;
    
    if temp_qty>=321 and temp_qty <=330 then
      set temp_commission=63300+((temp_qty-320)*105);
    end if;
    
    if temp_qty>=331 and temp_qty <=340 then
      set temp_commission=64350+((temp_qty-330)*90);
    end if;
    
    if temp_qty>=341 and temp_qty <=350 then
      set temp_commission=65250+((temp_qty-340)*75);
    end if;
    
    if temp_qty>=351 and temp_qty <=360 then
      set temp_commission=66000+((temp_qty-350)*255);
    end if;
    
    if temp_qty>=361 and temp_qty <=370 then
      set temp_commission=68550+((temp_qty-350)*240);
    end if;
    
    if temp_qty>=371 and temp_qty <=380 then
      set temp_commission=70950+((temp_qty-370)*225);
    end if;
    
    if temp_qty>=381 and temp_qty <=390 then
      set temp_commission=73200+((temp_qty-380)*210);
    end if;
    
    if temp_qty>=391 and temp_qty <=400 then
      set temp_commission=75300+((temp_qty-390)*195);
    end if;
    
    if temp_qty>=401 and temp_qty <=410 then
      set temp_commission=77250+((temp_qty-400)*180);
    end if;
    
  end if;

	RETURN temp_commission;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_agent_gold_due`(input_agent_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
                DECLARE total_gold_due double;

              select round(sum(get_customer_gold_due(agent_to_customer.cust_id)),3) into total_gold_due from agent_to_customer inner join agent_master ON agent_master.agent_id = agent_to_customer.agent_id where agent_master.agent_id=input_agent_id;
              IF isnull(total_gold_due) then
                set total_gold_due=0;
              END IF;
                RETURN total_gold_due;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_agent_lc_due`(input_agent_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
                DECLARE total_lc_due double;

                select sum(get_customer_lc_due(agent_to_customer.cust_id)) into total_lc_due from agent_to_customer inner join agent_master ON agent_master.agent_id = agent_to_customer.agent_id where agent_master.agent_id=input_agent_id;
                IF isnull(total_lc_due) then
                   set total_lc_due=0;
                END IF;
                RETURN total_lc_due;
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_salary_by_date`(in_agent_id varchar(255),in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
  DECLARE temp_salary double;
  DECLARE temp_commission double;
	DECLARE temp_total_salary double;
  DECLARE temp_agent_category_id int;
  declare temp_qty int;
  set temp_qty=0;
  set temp_salary=0;
  set temp_commission=0;
  set temp_total_salary=0;
  select agent_category_id into temp_agent_category_id  from agent_master where agent_id=in_agent_id;
  IF isnull(temp_agent_category_id) then
    set temp_total_salary=-1;
  END IF;
  -- when first category
  if temp_agent_category_id =2 then
    select ifnull(sum(bill_details.qty),0) into temp_qty  from bill_master
      inner join bill_details on bill_details.bill_no = bill_master.bill_no
      inner join agent_to_customer on bill_master.cust_id = agent_to_customer.cust_id
      where date(bill_master.tr_time)>=in_start_date and date(bill_master.tr_time)<=in_end_date and agent_to_customer.agent_id=in_agent_id;
     
    if temp_qty>=0 and temp_qty <=30 then
      set temp_salary=7000;
    end if;
    if temp_qty>=31 and temp_qty <=35 then
      set temp_salary=8000;
    end if;
    if temp_qty>=36 and temp_qty <=40 then
      set temp_salary=9000;
    end if;
    if temp_qty>=41 and temp_qty <=45 then
      set temp_salary=10000;
    end if;
    if temp_qty>=46 and temp_qty <=50 then
      set temp_commission=temp_qty*270;
    end if;
    
    if temp_qty>=51 and temp_qty <=60 then
      set temp_commission=13500+((temp_qty-50)*255);
    end if;
    
    if temp_qty>=61 and temp_qty <=70 then
      set temp_commission=16050+((temp_qty-60)*240);
    end if;
    
    if temp_qty>=71 and temp_qty <=80 then
      set temp_commission=18450+((temp_qty-70)*225);
    end if;
    
    if temp_qty>=81 and temp_qty <=90 then
      set temp_commission=20700+((temp_qty-80)*210);
    end if;
    
    if temp_qty>=91 and temp_qty <=100 then
      set temp_commission=22800+((temp_qty-90)*195);
    end if;
    
    if temp_qty>=101 and temp_qty <=110 then
      set temp_commission=24750+((temp_qty-100)*180);
    end if;
    
    if temp_qty>=111 and temp_qty <=120 then
      set temp_commission=26550+((temp_qty-110)*165);
    end if;
    
    if temp_qty>=121 and temp_qty <=130 then
      set temp_commission=28200+((temp_qty-120)*150);
    end if;
    
    if temp_qty>=131 and temp_qty <=140 then
      set temp_commission=29700+((temp_qty-130)*135);
    end if;
    
    if temp_qty>=141 and temp_qty <=150 then
      set temp_commission=31050+((temp_qty-140)*120);
    end if;
    
    if temp_qty>=151 and temp_qty <=160 then
      set temp_commission=32250+((temp_qty-150)*105);
    end if;
    
    if temp_qty>=161 and temp_qty <=170 then
      set temp_commission=33300+((temp_qty-160)*90);
    end if;
    
    if temp_qty>=171 and temp_qty <=180 then
      set temp_commission=34200+((temp_qty-170)*75);
    end if;
    
    if temp_qty>=181 and temp_qty <=190 then
      set temp_commission=34950+((temp_qty-180)*60);
    end if;
    
    if temp_qty>=191 and temp_qty <=200 then
      set temp_commission=35550+((temp_qty-190)*45);
    end if;
    
    if temp_qty>=201 and temp_qty <=210 then
      set temp_commission=36000+((temp_qty-200)*255);
    end if;
    
    if temp_qty>=211 and temp_qty <=220 then
      set temp_commission=38550+((temp_qty-211)*240);
    end if;
    
      -- calculating salary
      
  end if;
  set temp_total_salary=temp_salary+temp_commission;
	RETURN temp_total_salary;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_salary_year_and_month`(in_agent_id varchar(255),in_year int,in_month int) RETURNS double
    DETERMINISTIC
BEGIN
  DECLARE temp_salary double;
  DECLARE temp_commission double;
	DECLARE temp_total_salary double;
  DECLARE temp_agent_category_id int;
  declare temp_qty int;
  set temp_qty=0;
  set temp_salary=0;
  set temp_commission=0;
  set temp_total_salary=0;
  select agent_category_id into temp_agent_category_id  from agent_master where agent_id=in_agent_id;
  IF isnull(temp_agent_category_id) then
    set temp_total_salary=-1;
    return temp_total_salary;
  END IF;
  
  select ifnull(sum(bill_details.qty),0) into temp_qty  from bill_master
      inner join bill_details on bill_details.bill_no = bill_master.bill_no
      inner join agent_to_customer on bill_master.cust_id = agent_to_customer.cust_id
      where 
      date(bill_master.tr_time)>=DATE(CONCAT_WS('-', in_year, in_month, 1)) 
      and 
      date(bill_master.tr_time)<=COALESCE(DATE(CONCAT_WS('-', in_year, in_month, 31)),DATE(CONCAT_WS('-', in_year, in_month, 30)), DATE(CONCAT_WS('-', in_year, in_month, 29)), DATE(CONCAT_WS('-', in_year, in_month, 28)))
      and agent_to_customer.agent_id=in_agent_id;
  
  
  -- when first category
  if temp_agent_category_id =2 then 
    if temp_qty>=0 and temp_qty <=30 then
      set temp_salary=7000;
    end if;
    if temp_qty>=31 and temp_qty <=35 then
      set temp_salary=8000;
    end if;
    if temp_qty>=36 and temp_qty <=40 then
      set temp_salary=9000;
    end if;
    if temp_qty>=41 and temp_qty <=45 then
      set temp_salary=10000;
    end if;
  end if;
  
  -- Special category
  if temp_agent_category_id =6 then 
    if temp_qty>=0 and temp_qty <=30 then
      set temp_salary=7000;
    end if;
    if temp_qty>=31 and temp_qty <=35 then
      set temp_salary=8000;
    end if;
    if temp_qty>=36 and temp_qty <=40 then
      set temp_salary=9000;
    end if;
    if temp_qty>=41 and temp_qty <=45 then
      set temp_salary=10000;
    end if;
  end if;
  
-- 	RETURN temp_salary;
  return 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_sale_qty_year_and_month`(in_agent_id varchar(255),in_year int,in_month int) RETURNS double
    DETERMINISTIC
BEGIN
  declare temp_qty int;
  set temp_qty=0;
  select ifnull(sum(bill_details.qty),0) into temp_qty  from bill_master
      inner join bill_details on bill_details.bill_no = bill_master.bill_no
      inner join agent_to_customer on bill_master.cust_id = agent_to_customer.cust_id
      where 
      date(bill_master.tr_time)>=DATE(CONCAT_WS('-', in_year, in_month, 1)) 
      and 
      date(bill_master.tr_time)<=COALESCE(DATE(CONCAT_WS('-', in_year, in_month, 31)),DATE(CONCAT_WS('-', in_year, in_month, 30)), DATE(CONCAT_WS('-', in_year, in_month, 29)), DATE(CONCAT_WS('-', in_year, in_month, 28)))
      and agent_to_customer.agent_id=in_agent_id;
  
    

	RETURN temp_qty;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_sale_return_qty_year_and_month`(in_agent_id varchar(255),in_year int,in_month int) RETURNS double
    DETERMINISTIC
BEGIN
  declare temp_qty int;
  set temp_qty=0;
  select ifnull(sum(qty),0) into temp_qty from sale_returns where agent_id=in_agent_id and year_number=in_year and month_number=in_month;
  
    

	RETURN temp_qty;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_ta_year_and_month`(in_agent_id varchar(255),in_year int,in_month int) RETURNS double
    DETERMINISTIC
BEGIN
  DECLARE temp_ta int;
  DECLARE temp_agent_category_id int;
  declare temp_qty int;
  set temp_qty=0;
 set temp_ta=0;
  select agent_category_id into temp_agent_category_id  from agent_master where agent_id=in_agent_id;
  IF isnull(temp_agent_category_id) then
    set temp_ta=0;
    return temp_ta;
  END IF;
  
  -- calculating quantity
  select ifnull(sum(bill_details.qty),0) into temp_qty  from bill_master
      inner join bill_details on bill_details.bill_no = bill_master.bill_no
      inner join agent_to_customer on bill_master.cust_id = agent_to_customer.cust_id
      where 
      date(bill_master.tr_time)>=DATE(CONCAT_WS('-', in_year, in_month, 1)) 
      and 
      date(bill_master.tr_time)<=COALESCE(DATE(CONCAT_WS('-', in_year, in_month, 31)),DATE(CONCAT_WS('-', in_year, in_month, 30)), DATE(CONCAT_WS('-', in_year, in_month, 29)), DATE(CONCAT_WS('-', in_year, in_month, 28)))
      and agent_to_customer.agent_id=in_agent_id;
  
  -- when first category
  if temp_agent_category_id =2 then
    if temp_qty>=0 and temp_qty <=45 then
      set temp_ta=2000;
    end if;
  end if;
  -- special category
  if temp_agent_category_id =6 then
    if temp_qty>=0 and temp_qty <=45 then
      set temp_ta=2000;
    end if;
  end if;
  
-- 	RETURN temp_ta;
  return 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_agent_total_salary_withdraw_by_id_year_month`(in_agent_id varchar(255), in_year int, in_month int) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE total_withdraw_in_month int;
  set total_withdraw_in_month=0;
  select sum(amount) into total_withdraw_in_month from agent_salary_withdrawals where agent_id=in_agent_id and year_number=in_year and month_number=in_month;
  IF isnull(total_withdraw_in_month) then
    set total_withdraw_in_month=0;
  END IF;
	RETURN total_withdraw_in_month;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_billable_job_count_by_order_id`(input_order_id varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
                DECLARE total_billable_jobs int;
              set total_billable_jobs=0;
              select count(*) into total_billable_jobs from job_master where status=8 and order_id=input_order_id;
              IF isnull(total_billable_jobs) then
                set total_billable_jobs=0;
              END IF;
                RETURN total_billable_jobs;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_bill_fine_gold_by_bill_no`(in_bill_no varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE temp_fine double;
  select 
  sum(bill_details.fine_gold) into temp_fine
  from bill_master
  inner join bill_details
  on bill_details.bill_no = bill_master.bill_no
  where bill_master.bill_no=in_bill_no;
  IF isnull(temp_fine) then
    set temp_fine=0;
  END IF;
	RETURN temp_fine;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_bill_lc_by_bill_no`(in_bill_no varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE temp_lc integer;
  select 
  sum(bill_details.labour_charge) into temp_lc
  from bill_master
  inner join bill_details
  on bill_details.bill_no = bill_master.bill_no
  where bill_master.bill_no=in_bill_no;
  IF isnull(temp_lc) then
    set temp_lc=0;
  END IF;
	RETURN temp_lc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_bill_price_code_by_job_id`(input_job_id int) RETURNS varchar(10) CHARSET latin1
    DETERMINISTIC
BEGIN
	DECLARE temp_price_code varchar(10);
  set temp_price_code='-';
  select price_code into temp_price_code from bill_details where job_id=input_job_id;
	RETURN temp_price_code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_bill_qty_by_bill_no`(in_bill_no varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE temp_qty integer;
  select 
  sum(bill_details.qty) into temp_qty
  from bill_master
  inner join bill_details
  on bill_details.bill_no = bill_master.bill_no
  where bill_master.bill_no=in_bill_no;
  IF isnull(temp_qty) then
    set temp_qty=0;
  END IF;
	RETURN temp_qty;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_customer_by_order_id`(input_order_id varchar(255)) RETURNS varchar(255) CHARSET latin1
    DETERMINISTIC
BEGIN
                DECLARE temp_cust_name varchar(255);
                set temp_cust_name="";
                select cust_name into temp_cust_name from order_master inner join customer_master on order_master.cust_id = customer_master.cust_id where order_id=input_order_id;
                IF isnull(temp_cust_name) then
                    set temp_cust_name="not found";
                END IF;
                    RETURN temp_cust_name;
                END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_customer_gold_discount_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_gold_discount double;
  set total_gold_discount=0;
  select round(sum(gold),3) into total_gold_discount from customer_discount where cust_id=customer_id;
  IF isnull(total_gold_discount) then
    set total_gold_discount=0;
  END IF;
	RETURN total_gold_discount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_customer_gold_due`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
                DECLARE total_gold_due double;
                  set total_gold_due=0;
                  select (get_customer_opening_gold(cust_id)+get_customer_sale_gold_total(cust_id)-get_customer_gold_received_total(cust_id)) into total_gold_due from customer_master where cust_id = customer_id;
                  IF isnull(total_gold_due) then
                    set total_gold_due=0;
                  END IF;
	            RETURN total_gold_due;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_gold_received_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_gold_received double;
  set total_gold_received=0;
  select sum(gold_value) into total_gold_received from gold_receipt_master where cust_id=customer_id;
  IF isnull(total_gold_received) then
    set total_gold_received=0;
  END IF;
	RETURN total_gold_received;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_gold_received_total_by_date`(customer_id varchar(255),in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_gold_received double;
  set total_gold_received=0;
  select round(sum(gold_value),3) into total_gold_received from gold_receipt_master where cust_id=customer_id and date(gold_receipt_master.tr_date)>=in_start_date and date(gold_receipt_master.tr_date)<=in_end_date;
  IF isnull(total_gold_received) then
    set total_gold_received=0;
  END IF;
	RETURN total_gold_received;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_lc_discount_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_discount double;
  set total_lc_discount=0;
  select sum(amount) into total_lc_discount from customer_discount where cust_id=customer_id;
  IF isnull(total_lc_discount) then
    set total_lc_discount=0;
  END IF;
	RETURN total_lc_discount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_lc_due`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_due double;
  set total_lc_due=0;
  select (get_customer_opening_lc(cust_id) +get_customer_sale_lc_total(cust_id) - get_customer_lc_received_total(cust_id)) into total_lc_due  from customer_master where cust_id=customer_id;
  IF isnull(total_lc_due) then
    set total_lc_due=0;
  END IF;
	RETURN total_lc_due;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_lc_received_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_received double;
  set total_lc_received=0;
  select sum(amount) into total_lc_received  from lc_receipt_master where cust_id=customer_id;
  IF isnull(total_lc_received) then
    set total_lc_received=0;
  END IF;
	RETURN total_lc_received;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_lc_received_total_by_date`(customer_id varchar(255),in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_received double;
  set total_lc_received=0;
  select sum(amount) into total_lc_received  from lc_receipt_master where cust_id=customer_id and date(lc_receipt_master.lc_receipt_date)>=in_start_date and date(lc_receipt_master.lc_receipt_date)<=in_end_date;
  IF isnull(total_lc_received) then
    set total_lc_received=0;
  END IF;
	RETURN total_lc_received;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_opening_gold`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE op_gold double;
  set op_gold=0;
  select opening_gold into op_gold from customer_balance where cust_id=customer_id;
	RETURN op_gold;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_opening_lc`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE op_lc double;
  set op_lc=0;
  select opening_lc into op_lc from customer_balance where cust_id=customer_id;
	RETURN op_lc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_sale_gold_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_gold_sold double;
  set total_gold_sold=0;
  select sum(fine_gold) into total_gold_sold from bill_details
  inner join bill_master ON bill_master.bill_no = bill_details.bill_no
  where bill_master.cust_id=customer_id;
  IF isnull(total_gold_sold) then
    set total_gold_sold=0;
  END IF;
	RETURN total_gold_sold;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_sale_gold_total_by_date`(customer_id varchar(255), in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_gold_sold double;
  set total_gold_sold=0;
  select round(sum(fine_gold),3) into total_gold_sold from bill_details
  inner join bill_master ON bill_master.bill_no = bill_details.bill_no
  where bill_master.cust_id=customer_id and date(bill_master.tr_time)>=in_start_date and date(bill_master.tr_time)<=in_end_date;
  IF isnull(total_gold_sold) then
    set total_gold_sold=0;
  END IF;
	RETURN total_gold_sold;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_sale_lc_total`(customer_id varchar(255)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_sold double;
  DECLARE total_lc_discount double;
  select sum(labour_charge) into total_lc_sold from bill_details
  inner join bill_master ON bill_master.bill_no = bill_details.bill_no
  where bill_master.cust_id=customer_id;
  IF isnull(total_lc_sold) then
    set total_lc_sold=0;
  END IF;
  select sum(discount) into total_lc_discount  from bill_master  where bill_master.cust_id=customer_id;
  IF isnull(total_lc_discount) then
    set total_lc_discount=0;
  END IF;
	RETURN (total_lc_sold - total_lc_discount);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_sale_lc_total_by_date`(customer_id varchar(255),in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_lc_sold double;
  select sum(labour_charge) into total_lc_sold from bill_details
  inner join bill_master ON bill_master.bill_no = bill_details.bill_no
  where bill_master.cust_id=customer_id and date(bill_master.tr_time)>=in_start_date and date(bill_master.tr_time)<=in_end_date;
  IF isnull(total_lc_sold) then
    set total_lc_sold=0;
  END IF;
	RETURN total_lc_sold;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_customer_sale_qty_by_date`(in_customer_id varchar(255), in_start_date varchar(20),in_end_date varchar(20)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE total_qty double;
  set total_qty=0;
  select sum(qty) into total_qty from bill_details inner join bill_master ON bill_master.bill_no = bill_details.bill_no 
      where bill_master.cust_id=in_customer_id and date(bill_master.tr_time)>=in_start_date and date(bill_master.tr_time)<=in_end_date;
  IF isnull(total_qty) then
    set total_qty=0;
  END IF;
	RETURN total_qty;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_employee_material_balance`(in_emp_id int, in_rm_id int) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE temp_opening_gold double;
  DECLARE temp_material_send_to_job double;
  DECLARE temp_material_received_from_job double;
  
  
  
  select opening_balance into temp_opening_gold from material_to_employee_balance where emp_id=in_emp_id and rm_id=in_rm_id;
  IF isnull(temp_opening_gold) then
    set temp_opening_gold=0;
  END IF;
  
  -- this is negetive in nature        temp_material_send_to_job
  select sum(rm_value*transaction_type) into temp_material_send_to_job from inventory_day_book where employee_id=in_emp_id and rm_id=in_rm_id and transaction_type=-1;
  IF isnull(temp_material_send_to_job) then
    set temp_material_send_to_job=0;
  END IF;
  
  -- this is posetive in nature        temp_material_received_from_job
  select sum(rm_value*transaction_type) into temp_material_received_from_job from inventory_day_book where employee_id=in_emp_id and rm_id=in_rm_id and transaction_type=1;
  IF isnull(temp_material_received_from_job) then
    set temp_material_received_from_job=0;
  END IF;
  
	RETURN (temp_opening_gold + temp_material_send_to_job + temp_material_received_from_job);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_fine_by_job_id`(input_jobid int) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE gini double;
	DECLARE fine_percentange double;
  set gini=0;
  set fine_percentange=0;
  select rm_gold/100 into fine_percentange from rm_master where rm_ID = (select rm_id from job_master where job_id=input_jobid);
  select TRUNCATE(gold_send+(pan_send*.4)-gold_returned-nitrick_returned+(p_loss*pieces)+(markup_value*pieces),3) into gini from job_master where job_master.job_id = input_jobid;
	RETURN gini * fine_percentange;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_gini_by_job_id`(input_jobid int) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE op_lc double;
  set op_lc=0;
  select TRUNCATE(gold_send+(pan_send*.4)-gold_returned-nitrick_returned+(p_loss*pieces)+(markup_value*pieces),3) into op_lc from job_master where job_master.job_id = input_jobid;
	RETURN op_lc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_job_id_by_tag`(in_tag varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE temp_job_id integer;
  select job_id into temp_job_id from item_stock_ready_made where tag=in_tag;
  
	RETURN temp_job_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_order_count_by_order_id`(input_order_id varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
                DECLARE total_order_count int;
              set total_order_count=0;
              select count(*) into total_order_count from order_details where order_id=input_order_id;
              IF isnull(total_order_count) then
                set total_order_count=0;
              END IF;
                RETURN total_order_count;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_ploss_by_job_id`(in_job_id int) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE temp_ploss double;
  select p_loss into temp_ploss from job_master where job_id=in_job_id;
  
	RETURN temp_ploss;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_price_code_by_model`(input_model varchar(10)) RETURNS varchar(10) CHARSET latin1
    DETERMINISTIC
BEGIN
	DECLARE temp_price_code varchar(10);
  set temp_price_code='-';
  select price_code into temp_price_code from product_master where product_code=input_model;
	RETURN temp_price_code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_price_factor`(input_qty int) RETURNS int(11)
    DETERMINISTIC
BEGIN
	
	RETURN 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_rate_by_model`(input_model varchar(10), input_pcat int) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE temp_price int;
  set temp_price=0;
  select price into temp_price from product_master
  inner join price_master on product_master.price_code = price_master.price_code
  where price_master.price_cat=input_pcat and product_code=input_model;
	RETURN temp_price;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_total_fine_by_bill_number`(input_bill_number varchar(50)) RETURNS double
    DETERMINISTIC
BEGIN
	DECLARE temp_fine_gold double;
	select sum(fine_gold) into temp_fine_gold from bill_details where bill_details.bill_no = input_bill_number;
  return temp_fine_gold;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_total_lc_discount_by_date_id`(in_customer_id varchar(255),in_start_date date,in_end_date date, in_discount double) RETURNS int(11)
    DETERMINISTIC
BEGIN
                DECLARE total_lc_discount double;

                select sum(discount) into total_lc_discount from(select bill_master.tr_time,bill_master.bill_no
                ,get_bill_qty_by_bill_no(bill_no) as qty
                , get_bill_lc_by_bill_no(bill_no) as lc
                , get_bill_fine_gold_by_bill_no(bill_no) as fine
                ,is_date_between(tr_time,in_start_date,in_end_date) as is_dicountable
                ,if(is_date_between(tr_time,in_start_date,in_end_date),round(in_discount*get_bill_lc_by_bill_no(bill_no)/100,0),0) as discount
                
                from bill_master
                where bill_master.cust_id=in_customer_id) as table1;
                IF isnull(total_lc_discount) then
                  set total_lc_discount=0;
                END IF;
                return total_lc_discount;
         END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` FUNCTION `get_working_job_count_by_order_id`(input_order_id varchar(255)) RETURNS int(11)
    DETERMINISTIC
BEGIN
                DECLARE total_working_jobs int;
              set total_working_jobs=0;
              select count(*) into total_working_jobs from job_master where status not in(2,4,8,9) and order_id=input_order_id;
              IF isnull(total_working_jobs) then
                set total_working_jobs=0;
              END IF;
                RETURN total_working_jobs;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `initials`(str text, expr text) RETURNS text CHARSET utf8
    DETERMINISTIC
begin
    declare result text default '';
    declare buffer text default '';
    declare i int default 1;
    if(str is null) then
        return null;
    end if;
    set buffer = trim(str);
    while i <= length(buffer) do
        if substr(buffer, i, 1) regexp expr then
            set result = concat( result, substr( buffer, i, 1 ));
            set i = i + 1;
            while i <= length( buffer ) and substr(buffer, i, 1) regexp expr do
                set i = i + 1;
            end while;
            while i <= length( buffer ) and substr(buffer, i, 1) not regexp expr do
                set i = i + 1;
            end while;
        else
            set i = i + 1;
        end if;
    end while;
    return result;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `is_date_between`(in_date date,in_start_date date,in_end_date date) RETURNS int(11)
    DETERMINISTIC
BEGIN
	DECLARE temp double;
  set temp=0;
  IF date(in_date)>=in_start_date and date(in_date)<=in_end_date then
    set temp=1;
  END IF;
	RETURN temp;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_sale_by_date`(in start_date date, in end_date date)
BEGIN
	
  select customer_master.cust_name ,sum(bill_details.qty) as qty from bill_master 
inner join bill_details on bill_details.bill_no = bill_master.bill_no
inner join customer_master ON customer_master.cust_id = bill_master.cust_id 
where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<=end_date
group by customer_master.cust_name
order by qty desc;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_current_jobs`()
BEGIN
	select
              date_format(job_master.tr_time,'%d-%m-%y') as job_date
            , job_master.tr_time  
            , job_master.job_id
            , order_master.order_id
            , job_master.product_code
            , job_master.product_size
            , job_master.pieces
            , job_master.gold_send
            , job_master.dal_send
            , job_master.emp_id
            , job_master.pan_send
            , job_master.gold_returned
            , job_master.nitrick_returned
            , customer_master.cust_name
            , employees.emp_name
            , employees.nick_name
            , table_status.status_name
            , TIMESTAMPDIFF(MINUTE, job_master.tr_time, CURRENT_TIMESTAMP()) as minutes
            ,DATEDIFF(CURRENT_TIMESTAMP(), job_master.tr_time) as days_elapsed
            ,IF(DATEDIFF(CURRENT_TIMESTAMP(), job_master.tr_time)<1, if(TIMESTAMPDIFF(HOUR, job_master.tr_time, CURRENT_TIMESTAMP())<1,concat(TIMESTAMPDIFF(MINUTE, job_master.tr_time, CURRENT_TIMESTAMP()),' Minutes'),concat(TIMESTAMPDIFF(HOUR, job_master.tr_time, CURRENT_TIMESTAMP()),' Hours')), concat(DATEDIFF(CURRENT_TIMESTAMP(), job_master.tr_time),' Days')) as job_age
            from job_master 
            inner join order_master on order_master.order_id = job_master.order_id
            inner join customer_master on order_master.cust_id = customer_master.cust_id
            inner join rm_master on rm_master.rm_ID = job_master.rm_id
            inner join table_status on job_master.status=table_status.status_ID
            inner join employees on job_master.emp_id = employees.emp_id
            where job_master.status in(5,6,7,51,8) and  date(job_master.tr_time)>='2019-04-01'
            order by TIMESTAMPDIFF(MINUTE, job_master.tr_time, CURRENT_TIMESTAMP()),job_master.job_id desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_bill_and_receive_by_date`(in start_date date, in end_date date)
BEGIN
	select customer_master.cust_id
, customer_master.cust_name
, customer_master.city
, agent_to_customer.agent_id
, agent_master.short_name as agent
, ifnull(table1.qty,0) as qty
, ifnull(table1.bille_gold,0) as billed_gold
, ifnull(table1.billed_lc,0) as billed_lc 
, ifnull(table2.received_gold,0) as received_gold
, ifnull(table3.lc_received,0) as lc_received
, get_customer_gold_due(customer_master.cust_id) as current_gold_due
, get_customer_lc_due(customer_master.cust_id) as current_lc_due
from customer_master 
left outer join
(select 
bill_master.cust_id
,sum(bill_details.qty) as qty
,sum(bill_details.fine_gold) as bille_gold
,sum(bill_details.labour_charge) as billed_lc
from bill_master
inner join bill_details on bill_details.bill_no = bill_master.bill_no
where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<=end_date
group by bill_master.cust_id) as table1
on customer_master.cust_id = table1.cust_id
left outer join (select cust_id,sum(gold_value) as received_gold 
from gold_receipt_master 
where date(gold_receipt_master.tr_date)>=start_date and date(gold_receipt_master.tr_date)<=end_date
group by cust_id) as table2
on table1.cust_id = table2.cust_id
left outer join (select cust_id,sum(amount) as lc_received from lc_receipt_master 
where date(lc_receipt_date)>=start_date and date(lc_receipt_date)<=end_date
group by cust_id)as table3 on customer_master.cust_id = table3.cust_id
left outer join agent_to_customer on agent_to_customer.cust_id = customer_master.cust_id
left outer join agent_master ON agent_master.agent_id = agent_to_customer.agent_id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_bill_and_receive_by_date_by_agent`(in start_date date, in end_date date, in in_agent_id varchar(50))
BEGIN
	select customer_master.cust_id
, customer_master.cust_name
, customer_master.city
, agent_to_customer.agent_id
, agent_master.short_name as agent
, ifnull(table1.qty,0) as qty
, ifnull(table1.bille_gold,0) as billed_gold
, ifnull(table1.billed_lc,0) as billed_lc 
, ifnull(table2.received_gold,0) as received_gold
, ifnull(table3.lc_received,0) as lc_received
, get_customer_gold_due(customer_master.cust_id) as current_gold_due
, get_customer_lc_due(customer_master.cust_id) as current_lc_due
from customer_master 
left outer join
(select 
bill_master.cust_id
,sum(bill_details.qty) as qty
,sum(bill_details.fine_gold) as bille_gold
,sum(bill_details.labour_charge) as billed_lc
from bill_master
inner join bill_details on bill_details.bill_no = bill_master.bill_no
where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<=end_date
group by bill_master.cust_id) as table1
on customer_master.cust_id = table1.cust_id
left outer join (select cust_id,sum(gold_value) as received_gold 
from gold_receipt_master 
where date(gold_receipt_master.tr_date)>=start_date and date(gold_receipt_master.tr_date)<=end_date
group by cust_id) as table2
on table1.cust_id = table2.cust_id
left outer join (select cust_id,sum(amount) as lc_received from lc_receipt_master 
where date(lc_receipt_date)>=start_date and date(lc_receipt_date)<=end_date
group by cust_id)as table3 on customer_master.cust_id = table3.cust_id
left outer join agent_to_customer on agent_to_customer.cust_id = customer_master.cust_id
left outer join agent_master ON agent_master.agent_id = agent_to_customer.agent_id
where agent_master.agent_id=in_agent_id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_customer_due_by_agent`(in in_agent_id varchar(50))
BEGIN
	select cust_id,cust_name,round(get_customer_gold_due(cust_id),3) as gold_due, get_customer_lc_due(cust_id) as lc_due from customer_master where cust_id in(select cust_id from agent_to_customer where agent_id=in_agent_id);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_cutomer_discountable_bill_by_id_date`(in_customer_id varchar(50),in_start_date date,in_end_date date, in_discount double)
BEGIN
  select bill_master.tr_time,bill_master.bill_no
  ,get_bill_qty_by_bill_no(bill_no) as qty
  , get_bill_lc_by_bill_no(bill_no) as lc
  , get_bill_fine_gold_by_bill_no(bill_no) as fine
  ,is_date_between(tr_time,in_start_date,in_end_date) as is_dicountable
  ,if(is_date_between(tr_time,in_start_date,in_end_date),round(in_discount*get_bill_lc_by_bill_no(bill_no)/100,0),0) as discount
  
  from bill_master
  where bill_master.cust_id=in_customer_id
  order by tr_time desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_cutomer_recept_payment_by_id`(temp_customer_id varchar(50))
proc_label: BEGIN
 SET @current_gold_due:=0;
 SET @current_lc_due:=0;

select
tr_date
, DATE_FORMAT(tr_date, '%d/%m/%Y') as formated_tr_date
, particulars
, reference
, received_gold
, received_lc
, billed_qty
, billed_gold
, billed_lc
, op_gold_due
, op_lc_due
, comment
, account_type
,round((@current_gold_due := @current_gold_due +op_gold_due+billed_gold-received_gold),3) AS current_gold_due
,(@current_lc_due := @current_lc_due +op_lc_due+billed_lc-received_lc) AS current_lc_due
, transaction_code
from(
  select
  op_date as tr_date
  ,'Start' as particulars
  ,'opening' as reference
  ,0 as received_gold
  ,0 as received_lc
  ,0 as billed_qty
  ,0 as billed_gold
  ,0 as billed_lc
  ,round(opening_gold,3) as op_gold_due
  ,opening_lc as op_lc_due
  ,'opening' as comment
  ,1 as account_type
  ,0 as order_serial
  ,0 as transaction_code
  from customer_balance where cust_id=temp_customer_id
 
  union
 
  select
  max(bill_master.tr_time) as tr_date
  ,'Add: Bill' as particulars,bill_details.bill_no as reference
  ,0 as received_gold
  ,0 as received_lc
  ,sum(qty) as billed_qty
  ,round(sum(fine_gold),3) as billed_gold
  ,sum(labour_charge) as billed_lc
  ,0 as op_gold_due
  ,0 as op_lc_due
  ,max(if(bill_master.comments='NONE','Order','Readymade')) as comment
  ,1 as account_type
  ,1 as order_serial
  ,1 as transaction_code
  from bill_details
  inner join bill_master on bill_master.bill_no = bill_details.bill_no
  where bill_master.cust_id=temp_customer_id
  group by bill_details.bill_no

  union

  select
  tr_date
  ,'Less: Gold Received' as particulars
  ,gold_receipt_id as reference
  ,gold_value as received_gold
  ,0 as received_lc
  ,0 as billed_qty
  ,0 as billed_gold
  ,0 as billed_lc
  ,0 as op_gold_due
  ,0 as op_lc_due
  ,'gold received' as comment
  ,-1 as account_type
  , 1 as order_serial
  ,2 as transaction_code
  from gold_receipt_master
  where cust_id=temp_customer_id

  union

  select
  lc_receipt_date as tr_date
  ,'Less: Lc Received' as particulars
  , lc_receipt_no
  , 0 as received_gold
  , amount as received_lc
  , 0 as billed_qty
  , 0 as billed_gold
  , 0 as billed_lc
  , 0 as op_gold_due
  , 0 as op_lc_due
  , 'received lc ' as comment
  , -1 as account_type
  , 1 as order_serial
  , 3 as transaction_code
  from lc_receipt_master
  where cust_id=temp_customer_id
) as table1
order by order_serial,tr_date;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_cutomer_report_by_date`(in_start_date date, in_end_date date)
proc_label: BEGIN

 
select 
customer_master.cust_id,
customer_master.cust_name,
agent_master.short_name,
get_customer_sale_qty_by_date(customer_master.cust_id, in_start_date, in_end_date) as qty,
round(get_customer_sale_gold_total_by_date(customer_master.cust_id, in_start_date, in_end_date),3) as sale_gold,
get_customer_sale_lc_total_by_date(customer_master.cust_id, in_start_date, in_end_date) as sale_lc,
get_customer_gold_received_total_by_date(customer_master.cust_id, in_start_date, in_end_date) as gold_received,
get_customer_lc_received_total_by_date(customer_master.cust_id, in_start_date, in_end_date) as lc_received,
round(get_customer_gold_due(customer_master.cust_id),3) as current_gold_due,
get_customer_lc_due(customer_master.cust_id) as current_lc_ude
from customer_master
inner join agent_to_customer on agent_to_customer.cust_id = customer_master.cust_id
inner join agent_master ON agent_master.agent_id = agent_to_customer.agent_id;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_finished_jobs_by_date`(in start_date date, in end_date date)
BEGIN
	select * from job_master where date(tr_time)>=start_date and date(tr_time)<=end_date and (status=8 or status=9);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_jobs_by_date`(in start_date date, in end_date date)
BEGIN
	select * from job_master where date(tr_time)>=start_date and date(tr_time)<=end_date;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_modelwise_sale_by_date`(in in_start_date date, in in_end_date date, in in_limit int)
BEGIN
	select bill_details.model_no,sum(bill_details.qty) as sale_qty from bill_master
  inner join bill_details on bill_master.bill_no=bill_details.bill_no
  where date(bill_master.tr_time)>=in_start_date and date(bill_master.tr_time)<=in_end_date
  group by bill_details.model_no
  order by sale_qty desc limit in_limit;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_model_sale_to_customer_by_date`(in in_start_date date, in in_end_date date, in in_model varchar(10))
BEGIN
                select
                DATE_FORMAT(bill_master.tr_time,"%d/%m/%Y") as bill_date
              ,customer_master.cust_id
              ,customer_master.cust_name
              ,agent_master.short_name as agent
              ,bill_master.bill_no
              ,sum(bill_details.qty) as sale_qty
              from bill_master
              inner join bill_details on bill_details.bill_no = bill_master.bill_no
              inner join customer_master ON customer_master.cust_id = bill_master.cust_id
              inner join agent_to_customer on agent_to_customer.cust_id = customer_master.cust_id
              inner join agent_master ON agent_master.agent_id = agent_to_customer.agent_id
              where bill_details.model_no=in_model and date(bill_master.tr_time)>=in_start_date and  date(bill_master.tr_time)<=in_end_date
              group by customer_master.cust_id, customer_master.cust_name,agent_master.short_name, bill_master.bill_no,bill_master.tr_time;
            END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_non_recorded_stock`()
BEGIN
select y_table.bill_no, y_table.job_id, y_table.tr_time, y_table.job_qty, 
y_table.job_gold, 
round(y_table.job_gold * .92,3) as fine_gold, 
y_table.labour_charge, y_table.stock_qty, y_table.stock_gold, y_table.stock_lc from (select 
'Total' as bill_no, 
' ' as job_id, 
'' as tr_time, 
sum(job_qty) as job_qty, 
sum(job_gold) as job_gold,  
sum(labour_charge) as labour_charge, 
sum(stock_qty) as stock_qty, 
sum(stock_gold) as stock_gold, 
sum(stock_lc) as stock_lc 
from (select * from (select 
  bill_master.bill_no
  ,bill_details.job_id
  ,bill_master.tr_time
  ,bill_details.qty as job_qty
  ,bill_details.total_gold as job_gold
  ,bill_details.labour_charge
  ,ifnull(stock_item.qty,0) as stock_qty
  ,ifnull(stock_item.gold,0) as stock_gold
  ,ifnull(stock_item.lc,0) as stock_lc
  from bill_master 
  inner join bill_details on bill_details.bill_no = bill_master.bill_no
  left outer join (select job_id, sum(qty) as qty ,sum(gold) as gold, sum(labour_charge) as lc from item_stock_ready_made group by job_id) as stock_item on bill_details.job_id = stock_item.job_id
  where bill_master.cust_id='S287' and date(bill_master.tr_time)>='2022-10-27') as table1
  where job_qty<>stock_qty or labour_charge<>stock_lc) as total_table

union
 
select * from (select 
  bill_master.bill_no
  ,bill_details.job_id
  ,bill_master.tr_time
  ,bill_details.qty as job_qty
  ,bill_details.total_gold as job_gold
  ,bill_details.labour_charge
  ,ifnull(stock_item.qty,0) as stock_qty
  ,ifnull(stock_item.gold,0) as stock_gold
  ,ifnull(stock_item.lc,0) as stock_lc
  from bill_master 
  inner join bill_details on bill_details.bill_no = bill_master.bill_no
  left outer join (select job_id, sum(qty) as qty ,sum(gold) as gold, sum(labour_charge) as lc from item_stock_ready_made group by job_id) as stock_item on bill_details.job_id = stock_item.job_id
  where bill_master.cust_id='S287' and date(bill_master.tr_time)>='2022-10-27' ) as table1
  where job_qty<>stock_qty or labour_charge<>stock_lc) as y_table;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_sale_by_date`(in start_date date, in end_date date)
BEGIN
	
  select bill_master.bill_no, date(bill_master.tr_time) as bill_date ,sum(bill_details.qty) as qty from bill_master 
inner join bill_details on bill_details.bill_no = bill_master.bill_no
where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<=end_date and bill_master.cust_id<>'S287'
group by bill_master.bill_no;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_agent_salary_and_withdraw_report`()
proc_label: BEGIN
	select id, agent_salaries.agent_id
  , agent_master.agent_name
  , agent_master.short_name 
  , month_number,year_number
  , monthname(date(concat(year_number,'-',month_number,'-',1))) as month_name
  , salary 
  , ta 
  , commission
  , (salary + ta + commission) as total_salary
  , get_agent_total_salary_withdraw_by_id_year_month(agent_salaries.agent_id, year_number, month_number) as salary_withdraw 
  , (salary + ta + commission)-get_agent_total_salary_withdraw_by_id_year_month(agent_salaries.agent_id, year_number, month_number) as due_salary
  , created_at, updated_at FROM agent_salaries
  inner join agent_master on agent_master.agent_id=agent_salaries.agent_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_change_nitrick_to_job`(IN j_id double,IN temp_nitrick double)
proc_label: BEGIN
 
	declare job_status double;
  declare e_id double;
  declare current_nitrick double;
  declare old_closing_balance double;
  declare new_closing_balance double;
  
  IF j_id IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  IF temp_nitrick IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  
  select status into job_status from job_master where job_id=j_id;
  IF job_status IS NULL THEN
          select "wrong JOB ID";
          LEAVE proc_label;
  END IF;
  IF job_status=4 THEN
          select "Job Canceled cant modify now";
          LEAVE proc_label;
  END IF; 
  IF job_status=9 THEN
          select "Bill already created cant modify";
          LEAVE proc_label;
  END IF; 
  IF job_status=7 or job_status=8 THEN
          select "We can modify the nitrick";
          
          select employee_id into e_id from inventory_day_book where reference=j_id and rm_id=45 and transaction_type=1;
          
          select closing_balance into old_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=45; 
          select rm_value into current_nitrick  from inventory_day_book where reference=j_id and rm_id=45 and transaction_type=1;
          update job_master set nitrick_returned=round(temp_nitrick*0.96,3) where job_id=j_id;
          update inventory_day_book set rm_value=temp_nitrick where reference=j_id and rm_id=45 and transaction_type=1;
          update material_to_employee_balance set closing_balance=closing_balance+(temp_nitrick-current_nitrick) where emp_id=e_id and rm_id=45;
          select closing_balance into new_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=45; 
          insert into log_table (id,method,old_value,new_value,material_id,reference,emp_id,old_closing_balance,new_closing_balance) VALUES(NULL,'huitech_change_nitrick_to_job',current_nitrick,temp_nitrick,45,j_id,e_id,old_closing_balance,new_closing_balance);          
  ELSE
          select "Bill already created cant modify";
          LEAVE proc_label;
  END IF; 
  
  
  
  select "Successfully Updated";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`127.0.0.1` PROCEDURE `huitech_change_pan_to_job`(IN j_id double,IN temp_pan double)
proc_label: BEGIN
 
	declare job_status double;
  declare e_id double;
  declare current_pan double;
  declare old_closing_balance double;
  declare new_closing_balance double;
  
  IF j_id IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  IF temp_pan IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  
  select status into job_status from job_master where job_id=j_id;
  IF job_status IS NULL THEN
          select "wrong JOB ID";
          LEAVE proc_label;
  END IF;
  IF job_status=4 THEN
          select "Job Canceled cant modify now";
          LEAVE proc_label;
  END IF; 
  IF job_status=9 THEN
          select "Bill already created cant PAN";
          LEAVE proc_label;
  END IF; 
  IF job_status=7 or job_status=8 THEN
          select "We can modify the PAN";
          
          select employee_id into e_id from inventory_day_book where reference=j_id and rm_id=31 and transaction_type=-1;
          
          select closing_balance into old_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=31; 
          select rm_value into current_pan  from inventory_day_book where reference=j_id and rm_id=31 and transaction_type=-1;
          
          update job_master set pan_send=temp_pan where job_id=j_id;
          update inventory_day_book set rm_value=temp_pan where reference=j_id and rm_id=31 and transaction_type=-1;
          
          update material_to_employee_balance set closing_balance=closing_balance-(temp_pan-current_pan) where emp_id=e_id and rm_id=31;
          select closing_balance into new_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=31; 
          insert into log_table (id,method,old_value,new_value,material_id,reference,emp_id,old_closing_balance,new_closing_balance) VALUES(NULL,'huitech_change_pan_to_job',current_pan,temp_pan,31,j_id,e_id,old_closing_balance,new_closing_balance);          
  ELSE
          select "Bill already created cant modify";
          LEAVE proc_label;
  END IF; 
  
  
  
  select "Successfully Updated PAN";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_get_bill_and_receive_by_date`(in start_date date, in end_date date)
BEGIN
	select customer_master.cust_id
, customer_master.cust_name
, customer_master.city
, agent_to_customer.agent_id
, agent_master.short_name as agent
, ifnull(table1.qty,0) as qty
, ifnull(table1.bille_gold,0) as billed_gold
, ifnull(table1.billed_lc,0) as billed_lc 
, ifnull(table2.received_gold,0) as received_gold
, ifnull(table3.lc_received,0) as lc_received
, ( ifnull(table1.bille_gold,0)-ifnull(table2.received_gold,0)) as gold_overdue
, (ifnull(table1.billed_lc,0) - ifnull(table3.lc_received,0)) as lc_overdue
from customer_master 
left outer join
(select 
bill_master.cust_id
,sum(bill_details.qty) as qty
,sum(bill_details.fine_gold) as bille_gold
,sum(bill_details.labour_charge) as billed_lc
from bill_master
inner join bill_details on bill_details.bill_no = bill_master.bill_no
where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<=end_date
group by bill_master.cust_id) as table1
on customer_master.cust_id = table1.cust_id
left outer join (select cust_id,sum(gold_value) as received_gold 
from gold_receipt_master 
where date(gold_receipt_master.tr_date)>=start_date and date(gold_receipt_master.tr_date)<=end_date
group by cust_id) as table2
on table1.cust_id = table2.cust_id
left outer join (select cust_id,sum(amount) as lc_received from lc_receipt_master 
where date(lc_receipt_date)>=start_date and date(lc_receipt_date)<=end_date
group by cust_id)as table3 on customer_master.cust_id = table3.cust_id
left outer join agent_to_customer on agent_to_customer.cust_id = customer_master.cust_id
left outer join agent_master ON agent_master.agent_id = agent_to_customer.agent_id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_get_customer_report_by_date`(start_date date,end_date date)
proc_label: BEGIN
 
    	select 
        sales_table.cust_id
        ,customer_master.cust_name
        ,sales_table.billed_qty
        ,customer_balance.opening_gold
        ,customer_balance.opening_lc
        ,sales_table.billed_gold
        ,sales_table.billed_lc
    ,ifnull(gold_receipt,0) as gold_receipt
    ,ifnull(lc_receipt,0) as lc_receipt
    ,round(customer_balance.opening_gold+sales_table.billed_gold-ifnull(gold_receipt,0),3) as golde_due
    ,round(customer_balance.opening_lc+sales_table.billed_lc-ifnull(lc_receipt,0),2) as lc_due
    from(select 
        bill_master.cust_id
        ,sum(bill_details.qty) as billed_qty
        ,sum(bill_details.fine_gold) as billed_gold
        ,sum(bill_details.labour_charge) as billed_lc
        from bill_master 
    inner join bill_details on bill_details.bill_no = bill_master.bill_no
    where date(bill_master.tr_time)>=start_date and date(bill_master.tr_time)<end_date
    group by bill_master.cust_id) as sales_table

    inner join customer_master on customer_master.cust_id=sales_table.cust_id
    
    left outer join customer_balance on customer_master.cust_id=customer_balance.cust_id

    left outer join (select cust_id,sum(gold_value) as gold_receipt from gold_receipt_master
    where date(tr_date)>=start_date and date(tr_date)<end_date
    group by cust_id) as gold_receipt_table on sales_table.cust_id = gold_receipt_table.cust_id

    left outer join (select cust_id,sum(amount) as lc_receipt from lc_receipt_master
    where date(lc_receipt_date)>=start_date and date(lc_receipt_date)<end_date
    group by cust_id) as lc_receipt_table on lc_receipt_table.cust_id = sales_table.cust_id
    order by sales_table.billed_qty desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_remove_item_from_order_bill`(temp_bill_number varchar(50),temp_job_id varchar(50))
proc_label: BEGIN
 
	declare temp_bill_details_id varchar(50);
  declare temp_fine_gold double;
  declare temp_labour_charge double;
  declare temp_cust_id varchar(20);
  select bill_details_id into temp_bill_details_id from bill_details where bill_no=temp_bill_number and job_id=temp_job_id;
  
  IF temp_bill_details_id IS NULL THEN
          select "Bill Number or Tag is incorrect";
          LEAVE proc_label;
  END IF;   
  select fine_gold into temp_fine_gold from bill_details where bill_details_id=temp_bill_details_id;
  select labour_charge into temp_labour_charge from bill_details where bill_details_id=temp_bill_details_id;
  select cust_id into temp_cust_id from bill_master where bill_no=temp_bill_number;
  
  -- deleting item
  delete from bill_details where bill_details_id=temp_bill_details_id;
  update bill_master set 
       bill_gold=(select sum(fine_gold) from bill_details where bill_no=temp_bill_number)
      ,bill_labour_charge=(select sum(labour_charge) from bill_details where bill_no=temp_bill_number) 
      where bill_no=temp_bill_number;
      
  update customer_balance set 
      billed_gold=billed_gold-temp_fine_gold
      , billed_lc=billed_lc-temp_labour_charge where cust_id=temp_cust_id;
      update job_master set status=8 where job_id=temp_job_id;
  select "Successfully Updated";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_switch_bill_to`(IN bn varchar(50),IN actual_cust_id varchar(50))
proc_label: BEGIN
 
	declare c_id varchar(50);
  declare b_gold double;
  declare b_lc double;
  declare temp double;
  
  IF bn IS NULL THEN
          LEAVE proc_label;
  END IF;
  IF actual_cust_id IS NULL THEN
          LEAVE proc_label;
  END IF;
  
  select cust_id into c_id from bill_master where bill_no=bn;
  IF c_id IS NULL THEN
          select "wrong bill";
          LEAVE proc_label;
  END IF;
  select count(*) into temp from customer_master where cust_id=actual_cust_id;
   IF temp=0 THEN
          select "wrong Customer Id";
          LEAVE proc_label;
  END IF;
  IF c_id=actual_cust_id THEN
    select "No Change required";
          LEAVE proc_label;
  END IF;
  
  select sum(fine_gold) into b_gold  from bill_details where bill_no=bn;
  select sum(labour_charge) into b_lc  from bill_details where bill_no=bn;
  update bill_master set cust_id=actual_cust_id where bill_no=bn;
  update customer_balance set billed_gold=billed_gold-b_gold, billed_lc=billed_lc-b_lc where cust_id=cust_id;
  update customer_balance set billed_gold=billed_gold+b_gold, billed_lc=billed_lc+b_lc where cust_id=actual_cust_id;
  select "Successfully changed";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_topup_dal_to_job`(IN j_id double,IN new_dal_value double)
proc_label: BEGIN
 
	declare d_id double;
  declare job_status double;
  declare e_id int;
  declare old_dal_value double;
  declare new_closing_balance double;
  declare old_closing_balance double;
  declare j_id_varchar varchar(100);
  -- making number to string
  select CONCAT("", j_id) into j_id_varchar;
  IF j_id IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  IF new_dal_value IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  
  select dal_id into d_id from job_master where job_id=j_id;
  
  IF d_id IS NULL THEN
          select "wrong DAL ID";
          LEAVE proc_label;
  END IF;
  select status into job_status from job_master where job_id=j_id;
  IF job_status=9 THEN
          select "Job Completed cant modify now";
          LEAVE proc_label;
  END IF; 
  IF job_status=4 THEN
          select "Job canceled cant modify now";
          LEAVE proc_label;
  END IF; 
  -- after validation main process is started
  -- getting employee id from inventory_day_book
  select dal_send into old_dal_value from job_master where job_id=j_id;
  select employee_id into e_id from inventory_day_book where reference=j_id_varchar and rm_id=d_id and transaction_type=-1;
  update job_master set dal_send=dal_send+new_dal_value where job_id=j_id;
  
  update inventory_day_book set rm_value=rm_value+new_dal_value where reference=j_id_varchar and rm_id=d_id and transaction_type=-1;
  select closing_balance into old_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=d_id;
  update material_to_employee_balance set closing_balance=closing_balance-new_dal_value where emp_id=e_id and rm_id=d_id;
  select closing_balance into new_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=d_id; 
  insert into log_table (id
                        ,method
                        ,old_value
                        ,new_value
                        ,material_id
                        ,reference
                        ,emp_id
                        ,old_closing_balance
                        ,new_closing_balance) 
  VALUES(NULL
        ,'huitech_topup_dal_to_job'
        ,old_dal_value
        ,new_dal_value
        ,d_id
        ,j_id
        ,e_id
        ,old_closing_balance
        ,new_closing_balance);          
  select "Successfully Updated";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_topup_gold_to_job`(IN j_id double,IN new_gold_value double)
proc_label: BEGIN
 
	declare r_id double;
  declare job_status double;
  declare e_id int;
  declare old_gold_value double;
  declare new_closing_balance double;
  declare old_closing_balance double;
  declare j_id_varchar varchar(100);
  -- making number to string
  select CONCAT("", j_id) into j_id_varchar;
  IF j_id IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  IF new_gold_value IS NULL THEN
          select "Required Parameter is missing";
          LEAVE proc_label;
  END IF;
  
  select rm_id into r_id from job_master where job_id=j_id;
  
  IF r_id IS NULL THEN
          select "wrong JOB ID";
          LEAVE proc_label;
  END IF;
  select status into job_status from job_master where job_id=j_id;
  IF job_status=9 THEN
          select "Job Completed cant modify now";
          LEAVE proc_label;
  END IF; 
  IF job_status=4 THEN
          select "Job canceled cant modify now";
          LEAVE proc_label;
  END IF; 
  -- after validation main process is started
  -- getting employee id from inventory_day_book
  select gold_send into old_gold_value from job_master where job_id=j_id;
  select employee_id into e_id from inventory_day_book where reference=j_id_varchar and rm_id=r_id and transaction_type=-1;
  update job_master set gold_send=gold_send+new_gold_value where job_id=j_id;
  
  update inventory_day_book set rm_value=rm_value+new_gold_value where reference=j_id_varchar and rm_id=r_id and transaction_type=-1;
  select closing_balance into old_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=r_id;
  update material_to_employee_balance set closing_balance=closing_balance-new_gold_value where emp_id=e_id and rm_id=r_id;
  select closing_balance into new_closing_balance from material_to_employee_balance where emp_id=e_id and rm_id=r_id; 
  insert into log_table (id
                        ,method
                        ,old_value
                        ,new_value
                        ,material_id
                        ,reference
                        ,emp_id
                        ,old_closing_balance
                        ,new_closing_balance) 
  VALUES(NULL
        ,'huitech_topup_gold_to_job'
        ,old_gold_value
        ,new_gold_value
        ,r_id
        ,j_id
        ,e_id
        ,old_closing_balance
        ,new_closing_balance);          
  select "Successfully Updated";
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_update_all_bill_master_by_bill_details`()
proc_label: BEGIN 
update bill_master set 
bill_gold=(select sum(fine_gold)from bill_details where bill_no=bill_master.bill_no)
,bill_labour_charge=(select sum(labour_charge) from bill_details where bill_no=bill_master.bill_no);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_update_customer_balance_by_bill`()
proc_label: BEGIN
 -- this will update billed_gold and billed_lc
  update customer_balance
set 
  billed_gold=(select ifnull(sum(ifnull(fine_gold,0)),0) from bill_details where bill_no in(select bill_no from bill_master where cust_id=customer_balance.cust_id))
  ,billed_lc=(select ifnull(sum(ifnull(bill_details.labour_charge,0)),0) from bill_details where bill_no in(select bill_no from bill_master where cust_id=customer_balance.cust_id))
  where cust_id<>'s1217';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `huitech_update_stock_lc`()
proc_label: BEGIN
 -- this will update billed_gold and billed_lc
  update item_stock_ready_made set labour_charge=(get_rate_by_model(model_no, 1) * qty) where in_stock=1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `increase_bill_gold`(in input_bill_number varchar(50))
BEGIN
	
  update bill_details set total_gold=total_gold+(0.100*qty) where bill_no=input_bill_number;
  update bill_details set fine_gold=round(total_gold*92/100,3) where bill_no=input_bill_number;
  update bill_master set bill_gold=get_total_fine_by_bill_number(input_bill_number) where bill_no=input_bill_number;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `myTestProcedure`(IN bn varchar(20))
    COMMENT 'updating bill_master by gold and lc from bill_details'
BEGIN
      DECLARE cust VARCHAR(50);
      select cust_id into cust from bill_master where bill_no=bn;
      insert into customer_balance (
         cust_id
        ,opening_gold
        ,opening_lc
        ,billed_gold
        ,billed_lc
        ,received_gold
        ,received_lc
      ) VALUES (cust,0,0,12.34,100,0,0) on duplicate key UPDATE billed_gold=billed_gold+12.34,billed_lc=billed_lc+100;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `pr_update_bill_master`()
    COMMENT 'update bill_master'
BEGIN
    update bill_master
    set gold_due=bill_gold-gold_cleared,
    lc_due=bill_labour_charge-cash_cleared,
    gold_completed=if(bill_gold<=gold_cleared,1,0),
    cash_completed=if(bill_labour_charge<=cash_cleared,1,0);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `select_agents_income_year_month`(in_year int,in_month int)
BEGIN
	select agent_id, agent_name, agent_category_id
, get_agent_sale_qty_year_and_month(agent_id, in_year, in_month) as qty
, get_agent_sale_return_qty_year_and_month(agent_id, in_year, in_month) as return_qty
, get_agent_salary_year_and_month(agent_id, in_year, in_month) as salary
, get_agent_ta_year_and_month(agent_id, in_year, in_month) as ta
, get_agent_commission_year_and_month(agent_id, in_year, in_month) as commission
, get_agent_salary_year_and_month(agent_id, in_year, in_month)+get_agent_ta_year_and_month(agent_id, in_year, in_month)+get_agent_commission_year_and_month(agent_id, in_year, in_month) as total_income
from agent_master where show_in_commission=1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `set_order_deinforce`(in temp_cust_id varchar(50))
BEGIN
	update customer_master set order_inforce=0 where cust_id=temp_cust_id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `set_order_inforce`(in temp_cust_id varchar(50))
BEGIN
	update customer_master set order_inforce=1 where cust_id=temp_cust_id;
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `transfer_stock_to_counter_agent`()
BEGIN
      update item_stock_ready_made set agent_id='AG2018' where in_stock=1 and agent_id='AG2022';
      select 'stock transfer to counter agent';
      
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bill_master_by_bill_details`(IN bn varchar(20))
    COMMENT 'updating bill_master by gold and lc from bill_details'
BEGIN
      
      DECLARE g DOUBLE; 
      DECLARE lc DOUBLE;
      DECLARE cust VARCHAR(50);
      select cust_id into cust from bill_master where bill_no=bn;
      select round(SUM(fine_gold),3) into g from bill_details where bill_no=bn;
      select SUM(labour_charge) into lc from bill_details where bill_no=bn;
      update bill_master set bill_gold=g,bill_labour_charge=lc where bill_no=bn;
      IF  cust <> 'S1217' THEN 
      insert into customer_balance (
         cust_id
        ,opening_gold
        ,opening_lc
        ,billed_gold
        ,billed_lc
        ,received_gold
        ,received_lc
      ) VALUES (cust,0,0,g,lc,0,0) on duplicate key UPDATE billed_gold=billed_gold+g,billed_lc=billed_lc+lc;
      END IF;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_order_change_status_after_bill`(IN bn varchar(20))
    COMMENT 'updating order details after bill is created'
BEGIN
      update order_details set status=1
      where order_details.order_no in(
        select order_no from job_master where job_master.job_id in(
          select distinct job_id from bill_details where bill_details.bill_no=bn));
      
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_owner_password`(in input_password varchar(100))
BEGIN
  update user_master set md5_password=md5(input_password) where user_id='vivek';
  update employees set user_password=md5(input_password) where emp_id=28;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `zxcv`()
BEGIN
	update company_details set doc=DATE_ADD(doc, INTERVAL 40 DAY);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Current Database: `ses_gold`
--

USE `ses_gold`;

--
-- Final view structure for view `xyz_temp_view`
--

/*!50001 DROP VIEW IF EXISTS `xyz_temp_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `xyz_temp_view` AS select `bill_master`.`cust_id` AS `cust_id`,date_format(`bill_master`.`tr_time`,'%M') AS `bill_month`,sum(`bill_master`.`bill_labour_charge`) AS `lc` from `bill_master` group by `bill_master`.`cust_id`,`bill_master`.`tr_time` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-14  0:40:53
